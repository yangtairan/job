import copy, json, re
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt, Inches
from PIL import Image
SRC='CYB003-101_PKPD_Exploratory_ER_review_v0.4.docx'; OUT='CYB003-101_PKPD_Exploratory_ER_review_v0.4.docx'
AUTHOR='Tairan Yang'; DATE='2026-10-13T09:00:00Z'
doc=Document(SRC); body=doc.element.body; W=qn
_id=[20000]
def nid(): _id[0]+=1; return str(_id[0])
c20=json.load(open('cum20.json')); ron=__import__('pandas').read_csv('km_onset_table.csv'); roff=__import__('pandas').read_csv('km_resolution_table.csv')
# ---- helpers (same conventions as v0.4 edit) ----
def ptext(p): return ''.join(t.text or '' for t in p.iter(W('w:t')))
def PE(prefix):
    for p in body.iter(W('w:p')):
        if ptext(p).strip().startswith(prefix): return p
    raise KeyError(prefix)
TOK=re.compile(r'\*\*.*?\*\*|_\{.*?\}|\s+|[^\s_*]+|[_*]')
def base_rpr(p):
    for r in p.iter(W('w:r')):
        rpr=r.find(W('w:rPr'))
        if rpr is not None:
            c=copy.deepcopy(rpr)
            for tag in ['w:b','w:vertAlign']:
                for e in c.findall(W(tag)): c.remove(e)
            return c
    return OxmlElement('w:rPr')
def mk_run(txt,rpr0,bold=False,sub=False):
    r=OxmlElement('w:r'); rpr=copy.deepcopy(rpr0)
    if bold: rpr.insert(0,OxmlElement('w:b'))
    if sub: v=OxmlElement('w:vertAlign'); v.set(W('w:val'),'subscript'); rpr.append(v)
    r.append(rpr); t=OxmlElement('w:t'); t.text=txt; t.set('{http://www.w3.org/XML/1998/namespace}space','preserve'); r.append(t); return r
def runs(markup,rpr0):
    out=[]
    for tok in TOK.findall(markup):
        if tok.startswith('**') and tok.endswith('**') and len(tok)>4: out.append(mk_run(tok[2:-2],rpr0,bold=True))
        elif tok.startswith('_{') and tok.endswith('}'): out.append(mk_run(tok[2:-1],rpr0,sub=True))
        else: out.append(mk_run(tok,rpr0))
    return out
def wrap(tag,rs):
    e=OxmlElement(tag); e.set(W('w:id'),nid()); e.set(W('w:author'),AUTHOR); e.set(W('w:date'),DATE)
    for r in rs: e.append(r)
    return e
def mark_inserted(p):
    ppr=p.find(W('w:pPr'))
    if ppr is None: ppr=OxmlElement('w:pPr'); p.insert(0,ppr)
    rpr=ppr.find(W('w:rPr'))
    if rpr is None: rpr=OxmlElement('w:rPr'); ppr.append(rpr)
    for e in list(rpr):
        if e.tag in (W('w:ins'),W('w:del')): rpr.remove(e)
    ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); rpr.append(ins)
def replace_inserted_par(p,markup):
    """p was inserted in v0.4 (same author): rewrite its content as a fresh tracked insertion"""
    rpr0=base_rpr(p)
    for ch in list(p):
        if ch.tag!=W('w:pPr'): p.remove(ch)
    p.append(wrap('w:ins',runs(markup,rpr0))); mark_inserted(p)
def new_par_like(tpl,markup):
    p=copy.deepcopy(tpl)
    for ch in list(p):
        if ch.tag!=W('w:pPr'): p.remove(ch)
    p.append(wrap('w:ins',runs(markup,base_rpr(tpl)))); mark_inserted(p); return p
def set_pic(p_el,png):
    blip=p_el.find('.//'+W('a:blip')); rId=blip.get(qn('r:embed')); part=doc.part.rels[rId].target_part; part._blob=open(png,'rb').read()
    w,h=Image.open(png).size
    for ext in [p_el.find('.//'+W('wp:extent')),p_el.find('.//'+W('a:ext'))]:
        cx=int(ext.get('cx')); ext.set('cy',str(int(cx*h/w)))
def pic_after(p_el):
    e=p_el
    while e is not None:
        e=e.getnext()
        if e is not None and e.tag==W('w:p') and e.find('.//'+W('w:drawing')) is not None: return e
def add_row_after(t,tr_ref,vals):
    tr=copy.deepcopy(tr_ref)
    for tc,v in zip(tr.findall(W('w:tc')),vals):
        p=tc.find(W('w:p')); rpr0=base_rpr(p)
        for ch in list(p):
            if ch.tag!=W('w:pPr'): p.remove(ch)
        p.append(wrap('w:ins',runs(v,rpr0)))
    trPr=tr.find(W('w:trPr'))
    if trPr is None: trPr=OxmlElement('w:trPr'); tr.insert(0,trPr)
    for e in trPr.findall(W('w:ins')): trPr.remove(e)
    ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); trPr.append(ins)
    tr_ref.addnext(tr); return tr
def rows(t): return t.findall(W('w:tr'))
def rowtext(tr): return ' | '.join(''.join(x.text or '' for x in tc.iter(W('w:t'))) for tc in tr.findall(W('w:tc')))
def tbl_after(p_el):
    e=p_el
    while e is not None:
        e=e.getnext()
        if e is not None and e.tag==W('w:tbl'): return e
# ---- 1. renumber old Table 10 -> Table 11 (text + delText + LoT) ----
for t in list(body.iter(W('w:t')))+list(body.iter(W('w:delText'))):
    if t.text and 'Table 10' in t.text: t.text=t.text.replace('Table 10','Table 11')
# ---- 2. Figure 5: cumulative plot ----
cap5=PE('Figure 5.'); set_pic(pic_after(cap5),'newfig/Fig07_BP_return20.png')
replace_inserted_par(cap5,'Figure 5. Cumulative Percentage of Participants Returned to Within 20% of the Day 8 Baseline, Among Participants with an Increase of More Than 20% (0–8 h)')
# 5.1.4 text (inserted paragraph in v0.4) -> rewrite
p514=PE('An increase of more than 20% above the Day 8 baseline')
S=c20['SBP']; D=c20['DBP']; cr=lambda k,t:c20[k]['cum_returned_pct'][str(t)]
replace_inserted_par(p514,f'An increase of more than 20% above the Day 8 baseline was observed at least once in 14 of 34 participants (41%) for SBP and in 14 of 34 (41%) for DBP, with the maximum increase most often at 2 h post-dose (Table 7). Among these participants, the cumulative percentage returned to within 20% of baseline was {cr("SBP",2):.0f}% (SBP) and {cr("DBP",2):.0f}% (DBP) by 2 h, {cr("SBP",4):.0f}% and {cr("DBP",4):.0f}% by 4 h, {cr("SBP",6):.0f}% and {cr("DBP",6):.0f}% by 6 h, and 100% for both by 8 h (Figure 5); the median time of return was 4 h for both endpoints (range 2–8 h for SBP and 2–6 h for DBP). No participant was more than 20% above baseline at 8 h or later. Separately, values more than 20% below baseline were observed at 12 or 24 h in 3 participants (SBP) and 5 participants (DBP), consistent with the late decline below baseline seen in the mean profiles.')
# Table 7: add cumulative rows after 'Time by which all participants' row
t7=tbl_after(PE('Table 7.'))
for tr in rows(t7):
    if 'Time by which all participants' in rowtext(tr): ref=tr
r=add_row_after(t7,ref,['Cumulative % returned to ≤ 20% above baseline by 2 h (of participants exceeding)',f'{cr("SBP",2):.0f}',f'{cr("DBP",2):.0f}'])
r=add_row_after(t7,r,['Cumulative % returned by 4 h',f'{cr("SBP",4):.0f}',f'{cr("DBP",4):.0f}'])
r=add_row_after(t7,r,['Cumulative % returned by 6 h',f'{cr("SBP",6):.0f}',f'{cr("DBP",6):.0f}'])
r=add_row_after(t7,r,['Cumulative % returned by 8 h','100','100'])
# ---- 3. Figure 10: KM with at-risk tables + new Table 10 (event table) ----
cap10=PE('Figure 10.'); pic10=pic_after(cap10); set_pic(pic10,'newfig/Fig10_hall_KM.png')
replace_inserted_par(cap10,'Figure 10. Kaplan-Meier Estimates of Time to First Hallucination Onset (A) and Time to Final Resolution (B), with Numbers at Risk and Cumulative Events')
note10=pic10.getnext()   # existing note paragraph (inserted in v0.4)
replace_inserted_par(note10,'A: all 34 CYB003-dosed participants; the 4 participants without hallucination are censored at 48 h. B: the 30 participants with hallucination. Numbers at risk and cumulative events at each displayed timepoint are shown beneath the plots and in Table 10.')
TPL_TCAP=PE('Table 7.')
capT=new_par_like(TPL_TCAP,'Table 10. Numbers at Risk, Cumulative Events, and Kaplan-Meier Estimates for Time to First Hallucination Onset and Time to Final Resolution'); note10.addnext(capT)
# clone Table 8 (3 cols: Hour | ... ) as template -> need 4 cols; use Table 3 (3 cols) then add a column? simpler: clone Table 7 (3 cols) and use 3 cols: Time | At risk / events | KM estimate
tpl=tbl_after(PE('Table 7.')); t=copy.deepcopy(tpl); trs=rows(t); hdr=trs[0]; brow=trs[1]
for tr in trs[1:]: t.remove(tr)
def fill(tr,vals):
    for tc,v in zip(tr.findall(W('w:tc')),vals):
        p=tc.find(W('w:p')); rpr0=base_rpr(p)
        for ch in list(p):
            if ch.tag!=W('w:pPr'): p.remove(ch)
        p.append(wrap('w:ins',runs(v,rpr0)))
    trPr=tr.find(W('w:trPr'))
    if trPr is None: trPr=OxmlElement('w:trPr'); tr.insert(0,trPr)
    for e in trPr.findall(W('w:ins')): trPr.remove(e)
    ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); trPr.append(ins)
fill(hdr,['Time since dose (h)','At risk / cumulative events','Kaplan-Meier estimate'])
def addrow(vals): tr=copy.deepcopy(brow); fill(tr,vals); t.append(tr)
addrow(['**A. Time to first hallucination onset (N = 34)**','',''])
for _,x in ron.iterrows(): addrow([f'{x.time:g}',f'{int(x.at_risk)} / {int(x.cum_events)}',f'{x.KM_S:.2f} without onset'])
addrow(['**B. Time to final resolution (N = 30)**','',''])
for _,x in roff.iterrows(): addrow([f'{x.time:g}',f'{int(x.at_risk)} / {int(x.cum_events)}',f'{x.KM_S:.2f} ongoing'])
capT.addnext(t)
noteT=new_par_like(PE('A: all 34 CYB003-dosed participants'),'At risk = participants without the event and still under observation at the timepoint; cumulative events = events occurring at or before the timepoint. In A, the 4 participants without hallucination are censored at 48 h.'); t.addnext(noteT)
# ---- 4. List of Tables: rename old Table 10 row (already text-replaced to 'Table 11'), add Table 10 row ----
lot=doc.tables[1]._tbl
for tr in rows(lot)[1:]:
    if rowtext(tr).startswith('Table 11'):
        add_row_after(lot,tr,['Table 10','Numbers at Risk, Cumulative Events, and Kaplan-Meier Estimates for Hallucination Onset and Resolution'])
        # move new row before 'Table 11' row
        new=tr.getnext(); tr.addprevious(new); break
# LoF: update Figure 5 and Figure 10 titles
lof=doc.tables[2]._tbl
for tr in rows(lof)[1:]:
    tx=rowtext(tr)
    if tx.startswith('Figure 5'):
        tc=tr.findall(W('w:tc'))[1]; p=tc.find(W('w:p')); rpr0=base_rpr(p)
        old=''.join(x.text or '' for x in p.iter(W('w:t')))
        for ch in list(p):
            if ch.tag!=W('w:pPr'): p.remove(ch)
        d=wrap('w:del',[]); 
        rr=mk_run(old,rpr0); dt=rr.find(W('w:t')); dt.tag=W('w:delText'); d.append(rr); p.append(d)
        p.append(wrap('w:ins',runs('Cumulative Percentage of Participants Returned to Within 20% of the Day 8 Baseline (0–8 h)',rpr0)))
    if tx.startswith('Figure 10'):
        tc=tr.findall(W('w:tc'))[1]; p=tc.find(W('w:p')); rpr0=base_rpr(p)
        old=''.join(x.text or '' for x in p.iter(W('w:t')))
        for ch in list(p):
            if ch.tag!=W('w:pPr'): p.remove(ch)
        d=wrap('w:del',[]); rr=mk_run(old,rpr0); dt=rr.find(W('w:t')); dt.tag=W('w:delText'); d.append(rr); p.append(d)
        p.append(wrap('w:ins',runs('Kaplan-Meier Estimates of Time to First Hallucination Onset and Time to Final Resolution, with Numbers at Risk',rpr0)))
# ---- 5. version/date ----
for row in doc.tables[0].rows:
    for c in row.cells:
        if '06 October 2026' in ''.join(x.text or '' for x in c._tc.iter(W('w:t'))):
            for x in c._tc.iter(W('w:t')):
                if x.text and '06 October 2026' in x.text: x.text=x.text.replace('06 October 2026','13 October 2026')
for p in doc.sections[0].header.paragraphs:
    for r in p.runs: r.text=r.text.replace('06-Oct-2026','13-Oct-2026')
doc.save(OUT); print("saved",OUT)
