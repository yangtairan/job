import pandas as pd, numpy as np, json, warnings
import statsmodels.api as sm
from scipy import stats
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')
R=json.load(open('results_rev.json')); Z90=stats.norm.ppf(0.95)
gm,mx=R['cmax']['gm'],R['cmax']['max']
NAVY='#1F3864'; RED='#C0392B'; BLUE='#0072B2'; ORANGE='#E69F00'; TEAL='#0E7C7B'; PURPLE='#8E44AD'; GREEN='#2E7D32'; GREY='#9AA0A6'
plt.rcParams.update({'font.size':12,'axes.labelsize':13,'xtick.labelsize':11,'ytick.labelsize':11,'legend.fontsize':11,
  'axes.edgecolor':'#666','axes.linewidth':.8,'axes.grid':True,'grid.color':'#ececec','grid.linewidth':.5,'figure.dpi':150,'savefig.dpi':150})
def letter(ax,s): ax.text(-0.12,1.04,s,transform=ax.transAxes,fontsize=15,fontweight='bold',va='bottom')
XMAX=46
expo=pd.read_csv('expo.csv')

# ---------- Fig 1: dd SBP/DBP vs conc ----------
fig,axs=plt.subplots(1,2,figsize=(13,5.2))
for ax,k,L in [(axs[0],'SBP','A'),(axs[1],'DBP','B')]:
    m=pd.read_csv(f'dd_{k}.csv'); r=R['within'][k]
    xs=np.linspace(0,XMAX,120); V=np.array(r['V']); cb=r['cb']
    yy=r['b0']+r['slope']*(xs-cb); se=np.array([np.sqrt(np.array([1,x-cb])@V@np.array([1,x-cb])) for x in xs])
    # baseline-corrected fit (single delta) line
    d=m.copy(); d['xc']=d.CONC-cb
    import statsmodels.formula.api as smf
    f1=smf.mixedlm("d8~xc",d,groups=d.USUBJID).fit(method='powell',reml=True); y1=f1.fe_params['Intercept']+f1.fe_params['xc']*(xs-cb)
    ax.scatter(m.CONC,m.dd,s=16,alpha=.4,color=BLUE,edgecolors='none')
    ax.fill_between(xs,yy-Z90*se,yy+Z90*se,color=BLUE,alpha=.13); ax.plot(xs,yy,color=BLUE,lw=2.2,label='Day 1 corrected (ΔΔ)')
    ax.plot(xs,y1,color=ORANGE,lw=2,ls='--',label='Baseline corrected (Δ)')
    ax.axhline(0,ls=':',color='grey',lw=.8); ax.axvline(gm,ls='--',color='#aaa',lw=.9)
    ax.set_xlim(-1,XMAX); ax.set_xlabel('Time-matched CYB003 concentration (ng/mL)'); ax.set_ylabel(f'ΔΔ {k} (mmHg)')
    ax.text(0.02,0.97,f"ΔΔ slope {r['slope']:.3f} (90% CI {r['lo']:.3f}, {r['hi']:.3f})\nΔ slope {r['single_slope']:.3f} (90% CI {r['single_lo']:.3f}, {r['single_hi']:.3f})",
            transform=ax.transAxes,va='top',fontsize=10.5,bbox=dict(fc='white',ec='#ccc',alpha=.9))
    ax.legend(loc='lower right',frameon=True); letter(ax,L)
fig.tight_layout(); fig.savefig('newfig/Fig01_BP_within.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 2 / Fig 3: between-subject MAX change vs Cmax / AUC (SBP, DBP, HR) ----------
def between_fig(xv,xlab,fname,xlim):
    fig,axs=plt.subplots(1,3,figsize=(15,4.9))
    for ax,k,L,unit in [(axs[0],'SBP','A','mmHg'),(axs[1],'DBP','B','mmHg'),(axs[2],'HR','C','bpm')]:
        m=pd.read_csv(f'dd_{k}.csv'); s=m.groupby('USUBJID').dd.max().reset_index().merge(expo,on='USUBJID').dropna(subset=[xv])
        o=sm.OLS(s.dd,sm.add_constant(s[xv])).fit(); xs=np.linspace(s[xv].min(),s[xv].max(),60)
        pr=o.get_prediction(sm.add_constant(xs)).summary_frame(alpha=0.10)
        ax.fill_between(xs,pr['mean_ci_lower'],pr['mean_ci_upper'],color=RED,alpha=.12); ax.plot(xs,pr['mean'],color=RED,lw=2)
        ax.scatter(s[xv],s.dd,s=34,color=NAVY,alpha=.8,edgecolors='white',lw=.5); ax.axhline(0,ls=':',color='grey',lw=.8)
        rr=np.corrcoef(s.dd,s[xv])[0,1]
        ax.set_xlabel(xlab); ax.set_ylabel(f'Maximum ΔΔ {k} ({unit})'); ax.set_xlim(xlim)
        ax.text(0.02,0.97,f"slope {o.params[xv]:+.3f}\nr = {rr:+.2f}, p = {o.pvalues[xv]:.2f}, n = {len(s)}",transform=ax.transAxes,va='top',fontsize=10.5,bbox=dict(fc='white',ec='#ccc',alpha=.9))
        letter(ax,L)
    fig.tight_layout(); fig.savefig(fname,bbox_inches='tight'); plt.close(fig)
between_fig('CMAX','Individual CYB003 Cmax (ng/mL)','newfig/Fig02_between_Cmax.png',(14,46))
between_fig('AUC','Individual CYB003 AUC0–∞ (h·ng/mL)','newfig/Fig03_between_AUC.png',(90,320))

# ---------- Fig 4: between (subject means) vs within (individual slopes), SBP & DBP ----------
fig,axs=plt.subplots(2,2,figsize=(13,9.6))
for row,k in enumerate(['SBP','DBP']):
    m=pd.read_csv(f'dd_{k}.csv')
    # A/C: between-subject: subject-mean dd vs subject-mean conc
    s=m.groupby('USUBJID').agg(cb=('CONC','mean'),db=('dd','mean')).reset_index()
    o=sm.OLS(s.db,sm.add_constant(s.cb)).fit(); xs=np.linspace(s.cb.min(),s.cb.max(),60); pr=o.get_prediction(sm.add_constant(xs)).summary_frame(alpha=0.10)
    ax=axs[row,0]; ax.fill_between(xs,pr['mean_ci_lower'],pr['mean_ci_upper'],color=RED,alpha=.12); ax.plot(xs,pr['mean'],color=RED,lw=2)
    ax.scatter(s.cb,s.db,s=34,color=NAVY,alpha=.8,edgecolors='white',lw=.5); ax.axhline(0,ls=':',color='grey',lw=.8)
    ax.set_xlabel('Participant mean CYB003 concentration (ng/mL)'); ax.set_ylabel(f'Participant mean ΔΔ {k} (mmHg)')
    ci=o.conf_int(0.10).loc['cb']; ax.text(0.02,0.97,f"between-subject slope {o.params['cb']:+.3f}\n(90% CI {ci[0]:+.3f}, {ci[1]:+.3f}), n = {len(s)}",transform=ax.transAxes,va='top',fontsize=10.5,bbox=dict(fc='white',ec='#ccc',alpha=.9))
    letter(ax,'A' if row==0 else 'C')
    # B/D: within-subject individual lines + pooled within slope
    ax=axs[row,1]; wb=R['wb'][k]
    for sid,g in m.groupby('USUBJID'):
        if len(g)>=4 and g.CONC.std()>0:
            bb=np.polyfit(g.CONC,g.dd,1); xx=np.array([g.CONC.min(),g.CONC.max()]); ax.plot(xx,np.polyval(bb,xx),color=GREY,lw=.9,alpha=.8)
    cbar=m.CONC.mean(); b0=R['within'][k]['b0']; ax.plot([0,XMAX],[b0+wb['within']*(0-cbar),b0+wb['within']*(XMAX-cbar)],color=GREEN,lw=2.6)
    ax.axhline(0,ls=':',color='grey',lw=.8); ax.set_xlim(-1,XMAX); ax.set_xlabel('Time-matched CYB003 concentration (ng/mL)'); ax.set_ylabel(f'ΔΔ {k} (mmHg)')
    ax.text(0.02,0.97,f"within-subject slope {wb['within']:+.3f}\n(90% CI {wb['w_lo']:+.3f}, {wb['w_hi']:+.3f})\n{wb['npos']}/{wb['ntot']} individual slopes > 0",transform=ax.transAxes,va='top',fontsize=10.5,bbox=dict(fc='white',ec='#ccc',alpha=.9))
    letter(ax,'B' if row==0 else 'D')
fig.tight_layout(); fig.savefig('newfig/Fig04_between_within_SBP_DBP.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 5: hysteresis (arithmetic means, time-ordered) SBP, DBP, HR, hallucination ----------
fig,axs=plt.subplots(1,4,figsize=(18,4.7))
def loopplot(ax,g,ycol,ylab,col,L):
    ax.plot(g.CONC,g[ycol],'-',color=col,lw=1.5)
    for i in range(len(g)-1): ax.annotate('',xy=(g.CONC.iloc[i+1],g[ycol].iloc[i+1]),xytext=(g.CONC.iloc[i],g[ycol].iloc[i]),arrowprops=dict(arrowstyle='->',color=col,lw=1.5))
    ax.scatter(g.CONC,g[ycol],color=NAVY,s=34,zorder=5)
    for _,r in g.iterrows(): ax.annotate(f"{r.H:g} h",(r.CONC,r[ycol]),textcoords='offset points',xytext=(5,6),fontsize=9.5,color='#333')
    ax.axhline(0,ls=':',color='grey',lw=.8); ax.set_xlabel('Arithmetic mean CYB003 concentration (ng/mL)'); ax.set_ylabel(ylab); letter(ax,L)
for ax,k,L,ylab in [(axs[0],'SBP','A','Mean ΔΔ SBP (mmHg)'),(axs[1],'DBP','B','Mean ΔΔ DBP (mmHg)'),(axs[2],'HR','C','Mean ΔΔ pulse rate (bpm)')]:
    loopplot(ax,pd.read_csv(f'hyst_{k}.csv'),'dd',ylab,ORANGE,L)
pv=pd.read_csv('prev_hall.csv'); pv=pv[pv.H<=24]; pv['pct']=100*pv.hall
loopplot(axs[3],pv,'pct','Participants with hallucination (%)',PURPLE,'D')
fig.tight_layout(); fig.savefig('newfig/Fig05_hysteresis_all.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 6: HR dd vs conc ----------
fig,ax=plt.subplots(figsize=(7.2,5.2)); k='HR'; m=pd.read_csv('dd_HR.csv'); r=R['within'][k]
xs=np.linspace(0,XMAX,120); V=np.array(r['V']); cb=r['cb']; yy=r['b0']+r['slope']*(xs-cb); se=np.array([np.sqrt(np.array([1,x-cb])@V@np.array([1,x-cb])) for x in xs])
ax.scatter(m.CONC,m.dd,s=16,alpha=.4,color=TEAL,edgecolors='none'); ax.fill_between(xs,yy-Z90*se,yy+Z90*se,color=TEAL,alpha=.14); ax.plot(xs,yy,color=TEAL,lw=2.2)
ax.axhline(0,ls=':',color='grey',lw=.8); ax.axvline(gm,ls='--',color='#aaa',lw=.9); ax.set_xlim(-1,XMAX)
ax.set_xlabel('Time-matched CYB003 concentration (ng/mL)'); ax.set_ylabel('ΔΔ pulse rate (bpm)')
ax.text(0.02,0.97,f"ΔΔ slope {r['slope']:.3f} (90% CI {r['lo']:.3f}, {r['hi']:.3f})",transform=ax.transAxes,va='top',fontsize=10.5,bbox=dict(fc='white',ec='#ccc',alpha=.9))
fig.tight_layout(); fig.savefig('newfig/Fig06_HR_within.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 7: BP return to within 20% of baseline ----------
fig,ax=plt.subplots(figsize=(8,4.8))
for k,col in [('SBP',NAVY),('DBP','#3A7CA5')]:
    p=pd.read_csv(f'return20_prop_{k}.csv'); ax.plot(p.H,100*p.out,'-o',color=col,lw=2,label=k)
ax.set_xlabel('Time since CYB003 dose (h)'); ax.set_ylabel('Participants outside ±20% of Day 8 baseline (%)'); ax.set_xticks([0,1,2,4,6,8,12,24]); ax.legend(frameon=True)
fig.tight_layout(); fig.savefig('newfig/Fig07_BP_return20.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 8: hallucination timelines (A) + duration histogram (B) ----------
h=pd.read_csv('halluc_events.csv')
cat=h.AEDECOD.replace({'Hallucination, visual':'Visual hallucination','Hallucination, auditory':'Auditory hallucination','Hallucination, tactile':'Tactile hallucination','Hallucination':'Hallucination (unspecified)'})
h['evcat']=cat; order=h.groupby('USUBJID').onset.min().sort_values().index.tolist(); rowi={s:i for i,s in enumerate(order)}
fig,axs=plt.subplots(2,1,figsize=(11,9.5),gridspec_kw={'height_ratios':[1.5,1]})
cols={'Visual hallucination':'#A58BE2','Auditory hallucination':'#F08A8A','Tactile hallucination':'#4CB8E8','Somatic hallucination':'#2BB5A0','Hallucination (unspecified)':'#C9A227','Illusion':'#5CC45C','Visual processing disorder':'#F060C0'}
ax=axs[0]
for _,r in h.iterrows(): ax.plot([r.onset,r.offset],[rowi[r.USUBJID]]*2,lw=5,solid_capstyle='round',color=cols[r.evcat],alpha=.9)
ax.axvline(0,color=RED,lw=1.2); ax.text(0.15,len(order)-0.5,'CYB003 dose (t = 0)',color=RED,fontsize=10.5)
ax.set_yticks([]); ax.set_ylabel('Participants (one row each, ordered by onset)'); ax.set_xlabel('Time since CYB003 dose (h)'); ax.set_xlim(-0.5,12.5)
from matplotlib.lines import Line2D
ax.legend([Line2D([0],[0],color=c,lw=5) for c in cols.values()],list(cols.keys()),loc='lower right',fontsize=9.5,frameon=True); letter(ax,'A')
ax=axs[1]; ax.hist(h.dur,bins=np.arange(0,11.5,0.5),color=NAVY,edgecolor='white'); ax.axvline(h.dur.median(),color=ORANGE,ls='--',lw=2)
ax.text(h.dur.median()+0.15,ax.get_ylim()[1]*0.9,f"median {h.dur.median():.1f} h",color=ORANGE,fontsize=11); ax.set_xlabel('Episode duration (h)'); ax.set_ylabel('Episodes'); letter(ax,'B')
fig.tight_layout(); fig.savefig('newfig/Fig08_hall_timelines.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 9: boxplots A onset/dur/resolution, B subtype, C severity (all points visible) ----------
fig,axs=plt.subplots(1,3,figsize=(17,5.2),gridspec_kw={'width_ratios':[1,1.5,0.8]})
rng=np.random.default_rng(3)
ax=axs[0]; data=[h.onset,h.dur,h.offset]; ax.boxplot(data,labels=['Onset','Duration','Resolution'],widths=.5,showfliers=False,patch_artist=True,boxprops=dict(fc='#CFE0F3',ec=NAVY),medianprops=dict(color=NAVY,lw=2))
for i,d in enumerate(data,1): ax.scatter(i+rng.uniform(-.14,.14,len(d)),d,s=16,color=NAVY,alpha=.5)
ax.set_ylabel('Time since CYB003 dose (h)'); letter(ax,'A')
ax=axs[1]; grp=h.groupby('evcat').dur; keys=grp.median().sort_values().index.tolist(); data=[grp.get_group(k_).values for k_ in keys]
ax.boxplot(data,labels=[f"{k_} (n={len(d)})" for k_,d in zip(keys,data)],vert=False,widths=.55,showfliers=False,patch_artist=True,boxprops=dict(fc='#E3EAF5',ec=NAVY),medianprops=dict(color=NAVY,lw=2))
for i,d in enumerate(data,1): ax.scatter(d,i+rng.uniform(-.14,.14,len(d)),s=16,color=NAVY,alpha=.55)
ax.set_xlabel('Episode duration (h)'); letter(ax,'B')
ax=axs[2]; sev=['MILD','MODERATE']; data=[h[h.AESEV==s].dur.values for s in sev]
ax.boxplot(data,labels=[f"{s.title()} (n={len(d)})" for s,d in zip(sev,data)],widths=.5,showfliers=False,patch_artist=True,boxprops=dict(fc='#DDEEDD',ec=NAVY),medianprops=dict(color=NAVY,lw=2))
for i,d in enumerate(data,1): ax.scatter(i+rng.uniform(-.16,.16,len(d)),d,s=26,color=RED if i==2 else NAVY,alpha=.8,zorder=5)
ax.set_ylabel('Episode duration (h)'); letter(ax,'C')
fig.tight_layout(); fig.savefig('newfig/Fig09_hall_boxplots.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 10: KM onset / resolution ----------
fig,axs=plt.subplots(1,2,figsize=(13,4.9))
for ax,f,L,xl,yl in [(axs[0],'km_onset.csv','A','Time since CYB003 dose (h)','Proportion without hallucination onset'),(axs[1],'km_resolution.csv','B','Time since CYB003 dose (h)','Proportion with hallucination ongoing')]:
    k=pd.read_csv(f); ax.step(k.t,k.S,where='post',color=PURPLE,lw=2.2); ax.axhline(0.5,ls=':',color='grey',lw=.9)
    med=k[k.S<=0.5].t.iloc[0] if (k.S<=0.5).any() else None
    if med is not None: ax.axvline(med,ls='--',color=ORANGE,lw=1.4); ax.text(med+0.2,0.92,f"median {med:.1f} h",color=ORANGE,fontsize=11)
    ax.set_xlabel(xl); ax.set_ylabel(yl); ax.set_ylim(0,1.02); ax.set_xlim(0,14 if L=='B' else 6); letter(ax,L)
fig.tight_layout(); fig.savefig('newfig/Fig10_hall_KM.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 11: hallucination E-R (A prevalence+conc, B logistic w EC20/EC50, C duration vs t1/2, D duration vs AUC) ----------
tm=pd.read_csv('tm_hall.csv'); L_=R['hall']['logit']; ps=pd.read_csv('hall_persubj.csv')
fig,axs=plt.subplots(2,2,figsize=(13,9.4))
ax=axs[0,0]; pv=pd.read_csv('prev_hall.csv'); a2=ax.twinx()
ax.plot(pv.H,100*pv.hall,'-o',color=PURPLE,lw=2.2,label='% with hallucination'); a2.plot(pv.H,pv.CONC,'--s',color=RED,lw=1.6,ms=4,alpha=.85)
ax.set_xlabel('Time since CYB003 dose (h)'); ax.set_ylabel('Participants with hallucination (%)',color=PURPLE); a2.set_ylabel('Arithmetic mean CYB003 concentration (ng/mL)',color=RED); a2.grid(False); ax.set_xlim(-1,49); letter(ax,'A')
ax=axs[0,1]; xs=np.linspace(0,XMAX,200); pp_=1/(1+np.exp(-(L_['a']+L_['b']*xs)))
ax.scatter(tm.CONC,tm.hall+np.random.default_rng(2).uniform(-.03,.03,len(tm)),s=14,alpha=.3,color=NAVY,edgecolors='none'); ax.plot(xs,pp_,color=PURPLE,lw=2.4)
for ecv,lab,yv in [(L_['EC20'],'EC20',0.2),(L_['EC50'],'EC50',0.5)]:
    ax.plot([ecv,ecv],[0,yv],ls='--',color=ORANGE,lw=1.4); ax.plot([0,ecv],[yv,yv],ls='--',color=ORANGE,lw=1.4); ax.text(ecv+0.6,yv+0.03,f"{lab} = {ecv:.1f} ng/mL",color=ORANGE,fontsize=10.5)
ax.axvline(gm,ls='--',color='#aaa',lw=.9); ax.set_xlim(-1,XMAX); ax.set_xlabel('Time-matched CYB003 concentration (ng/mL)'); ax.set_ylabel('Probability of hallucination'); letter(ax,'B')
for ax,xv,xl,L in [(axs[1,0],'THALF','CYB003 terminal t½ (h)','C'),(axs[1,1],'AUC','CYB003 AUC0–∞ (h·ng/mL)','D')]:
    d=ps.dropna(subset=[xv,'total']); o=sm.OLS(d.total,sm.add_constant(d[xv])).fit(); xs2=np.linspace(d[xv].min(),d[xv].max(),50)
    ax.scatter(d[xv],d.total,s=34,color=NAVY,alpha=.8,edgecolors='white',lw=.5); ax.plot(xs2,o.params['const']+o.params[xv]*xs2,color=RED,lw=2)
    rho,p=stats.spearmanr(d[xv],d.total); ax.set_xlabel(xl); ax.set_ylabel('Total hallucination duration (h)')
    ax.text(0.02,0.97,f"Spearman ρ = {rho:+.2f}, p = {p:.3f}, n = {len(d)}",transform=ax.transAxes,va='top',fontsize=10.5,bbox=dict(fc='white',ec='#ccc',alpha=.9)); letter(ax,L)
fig.tight_layout(); fig.savefig('newfig/Fig11_hall_ER.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 12: participant 01-033 ----------
import re
def hrs(s):
    s=str(s).lower()
    if 'pre' in s: return 0.0
    m=re.search(r'([\d.]+)\s*hour',s); return float(m.group(1)) if m else np.nan
def load(n): return pd.read_sas(f'adam/ADaM/{n}.sas7bdat',format='sas7bdat',encoding='latin-1')
advs,adpc=load('advs'),load('adpc'); sid='CYB003-101-01-033'
def ser(param): d=advs[(advs.USUBJID==sid)&(advs.PARAMCD==param)&(advs.APERIODC=='PERIOD 2')].copy(); d['H']=d.ATPT.map(hrs); return d.groupby('H').AVAL.mean().reset_index()
sbp,dbp=ser('SYSBPSU'),ser('DIABPSU'); cc=adpc[(adpc.USUBJID==sid)&(adpc.PARAMCD=='CYB003')&(adpc.APERIODC=='PERIOD 2')].copy(); cc['H']=cc.ATPT.map(hrs); cc=cc.groupby('H').AVAL.mean().reset_index()
fig,ax=plt.subplots(figsize=(11,5.6)); a2=ax.twinx()
ax.axvspan(0.583,11.30,color=PURPLE,alpha=.08); ax.axvspan(1.92,3.92,color=ORANGE,alpha=.12)
ax.text(5.9,152,'Visual hallucination (0.6–11.3 h, mild)',color=PURPLE,fontsize=11,ha='center'); ax.text(2.9,42,'Euphoric mood\n(1.9–3.9 h, mild)',color=ORANGE,fontsize=10,ha='center')
ax.plot(sbp.H,sbp.AVAL,'-o',color=NAVY,lw=2,label='Supine SBP'); ax.plot(dbp.H,dbp.AVAL,'-o',color='#3A7CA5',lw=2,label='Supine DBP')
a2.plot(cc.H,cc.AVAL,'--s',color=RED,lw=1.6,ms=4,label='CYB003 concentration'); a2.set_ylabel('CYB003 concentration (ng/mL)',color=RED); a2.grid(False)
ax.set_xlabel('Time since CYB003 dose (h)'); ax.set_ylabel('Blood pressure (mmHg)'); ax.set_xticks([0,2,4,6,8,12,24]); ax.set_ylim(30,160)
h1,l1=ax.get_legend_handles_labels(); h2,l2=a2.get_legend_handles_labels(); ax.legend(h1+h2,l1+l2,loc='upper right',frameon=True)
fig.tight_layout(); fig.savefig('newfig/Fig12_subject033.png',bbox_inches='tight'); plt.close(fig)
import os; print(sorted(os.listdir('newfig')))
