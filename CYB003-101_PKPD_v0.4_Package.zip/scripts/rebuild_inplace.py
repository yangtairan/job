import copy, json, re
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
R=json.load(open('results_rev.json'))
SRC='/mnt/user-data/uploads/CYB003-101_PKPD_Exploratory_ER_review.docx'
doc=Document(SRC); body=doc.element.body
W=qn
# ---------------- remove comment markup ----------------
for tag in ['commentRangeStart','commentRangeEnd']:
    for el in body.iter(W('w:'+tag)): pass
for el in list(body.iter(W('w:commentRangeStart')))+list(body.iter(W('w:commentRangeEnd'))): el.getparent().remove(el)
for ref in list(body.iter(W('w:commentReference'))):
    r=ref.getparent(); r.getparent().remove(r)
for rId,rel in list(doc.part.rels.items()):
    if 'comments' in rel.reltype.lower(): doc.part.drop_rel(rId)
# ---------------- templates ----------------
def first_par(pred):
    for p in doc.paragraphs:
        if pred(p): return p
TPL={}
TPL['H1']=first_par(lambda p:p.style.name=='Heading 1' and p.text.startswith('1. Introduction'))
TPL['H2']=first_par(lambda p:p.style.name=='Heading 2')
TPL['H3']=first_par(lambda p:p.style.name=='Heading 3')
TPL['BODY']=first_par(lambda p:p.text.startswith('CYB003 is a deuterated'))
TPL['BULLET']=first_par(lambda p:p.text.startswith('To characterize the E-R relationship'))
TPL['TCAP']=first_par(lambda p:p.text.startswith('Table 1.'))
TPL['FCAP']=first_par(lambda p:p.text.startswith('Figure 1.'))
TPL['NOTE']=first_par(lambda p:p.text.startswith('The smaller numbers'))
TPL['EQ']=first_par(lambda p:'ηᵢ' in p.text or 'Yᵢⱼ =' in p.text)
for k,v in TPL.items(): assert v is not None, k
def base_rpr(p):
    r=p.runs[0]._r.find(W('w:rPr')) if p.runs else None
    return copy.deepcopy(r) if r is not None else None
RPR={k:base_rpr(v) for k,v in TPL.items()}
# normalise text tokens: unicode subscripts -> markup
SUBS=[('Cₘₐₓ','C_{max}'),('Tₘₐₓ','T_{max}'),('AUC₀₋∞','AUC_{0–∞}'),('AUC₀₋ ∞','AUC_{0–∞}'),('AUC0–∞','AUC_{0–∞}'),('AUC0-∞','AUC_{0–∞}'),('Cmax','C_{max}'),('Tmax','T_{max}')]
def norm(t):
    for a,b in SUBS: t=t.replace(a,b)
    return t.replace('C_{max}_{max}','C_{max}')
def par_to_markup(p):
    out=''
    for r in p.runs:
        t=r.text
        if r.bold: t='**'+t+'**' if t.strip() else t
        out+=t
    return norm(out)
sectPr=body.find(W('w:sectPr'))
def append_el(el): sectPr.addprevious(el)
def mk_par(kind,markup,align=None):
    tpl=TPL[kind]; p=copy.deepcopy(tpl._p)
    for r in p.findall(W('w:r')): p.remove(r)
    for h in p.findall(W('w:hyperlink')): p.remove(h)
    rpr0=RPR[kind]
    tokens=re.split(r'(\*\*.*?\*\*|_\{.*?\})',markup)
    for tok in tokens:
        if not tok: continue
        bold=False; sub=False; txt=tok
        if tok.startswith('**'): bold=True; txt=tok[2:-2]
        elif tok.startswith('_{'): sub=True; txt=tok[2:-1]
        r=OxmlElement('w:r')
        if rpr0 is not None:
            rpr=copy.deepcopy(rpr0)
            for b in rpr.findall(W('w:b')): rpr.remove(b)
            for v in rpr.findall(W('w:vertAlign')): rpr.remove(v)
        else: rpr=OxmlElement('w:rPr')
        if bold: b=OxmlElement('w:b'); rpr.insert(0,b)
        if sub: v=OxmlElement('w:vertAlign'); v.set(W('w:val'),'subscript'); rpr.append(v)
        r.append(rpr); t=OxmlElement('w:t'); t.text=txt; t.set('{http://www.w3.org/XML/1998/namespace}space','preserve'); r.append(t); p.append(r)
    if align=='center':
        ppr=p.find(W('w:pPr')); jc=ppr.find(W('w:jc')) if ppr is not None else None
        if jc is None: jc=OxmlElement('w:jc'); ppr.append(jc)
        jc.set(W('w:val'),'center')
    return p
def P(kind,markup): append_el(mk_par(kind,markup))
def H1(t): P('H1',t)
def H2(t): P('H2',t)
def H3(t): P('H3',t)
def BODY(t): P('BODY',t)
def BUL(t): P('BULLET',t)
def TCAP(t): P('TCAP',t)
def FCAP(t): P('FCAP',t)
def NOTE(t): P('NOTE',t)
def EQ(t): P('EQ',t)
# ---------------- tables ----------------
def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); sh=OxmlElement('w:shd'); sh.set(W('w:val'),'clear'); sh.set(W('w:color'),'auto'); sh.set(W('w:fill'),fill); tcPr.append(sh)
def borders(tbl):
    tblPr=tbl._tbl.tblPr; b=OxmlElement('w:tblBorders')
    for e in ['top','left','bottom','right','insideH','insideV']:
        x=OxmlElement('w:'+e); x.set(W('w:val'),'single'); x.set(W('w:sz'),'4'); x.set(W('w:color'),'BFBFBF'); b.append(x)
    tblPr.append(b)
def set_cell(cell,markup,bold=False,white=False,size=7.5,align=None):
    p=cell.paragraphs[0]; p.paragraph_format.space_after=Pt(0)
    for r in list(p.runs): r._r.getparent().remove(r._r)
    for tok in re.split(r'(_\{.*?\})',norm(markup)):
        if not tok: continue
        if tok.startswith('_{'): r=p.add_run(tok[2:-1]); r.font.subscript=True
        else: r=p.add_run(tok)
        r.font.size=Pt(size); r.bold=bold
        if white: r.font.color.rgb=RGBColor(0xFF,0xFF,0xFF)
    if align=='center': p.alignment=WD_ALIGN_PARAGRAPH.CENTER
def TABLE(headers,rows,widths,center_cols=()):
    t=doc.add_table(rows=1+len(rows),cols=len(headers)); t.autofit=False; borders(t)
    for j,h in enumerate(headers):
        c=t.cell(0,j); shade(c,'1F3864'); set_cell(c,h,bold=True,white=True,align='center' if j in center_cols else None)
    for i,row in enumerate(rows,1):
        for j,v in enumerate(row): set_cell(t.cell(i,j),v,align='center' if j in center_cols else None)
    for j,w in enumerate(widths):
        for row in t.rows: row.cells[j].width=Inches(w)
    # mark header row to repeat
    trPr=t.rows[0]._tr.get_or_add_trPr(); th=OxmlElement('w:tblHeader'); trPr.append(th)
    append_el(t._tbl)
def IMG(path,width_in):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(2)
    p.add_run().add_picture(path,width=Inches(width_in)); append_el(p._p)
# ---------------- capture existing body paragraphs to keep (text w/ formatting) ----------------
keep={}
for p in doc.paragraphs: keep[p.text.strip()[:60]]=par_to_markup(p)
def K(prefix):  # retrieve kept markup by prefix
    for k,v in keep.items():
        if k.startswith(prefix): return v
    raise KeyError(prefix)
# ---------------- update title table + header ----------------
for t in doc.tables[0].rows:
    for c in t.cells:
        if 'Draft v0.3' in c.text: set_cell(c,'Draft v0.4 / 06 October 2026',size=7.5)
for p in doc.sections[0].header.paragraphs:
    for r in p.runs: r.text=r.text.replace('Draft v0.3, 09-Sep-2026','Draft v0.4, 06-Oct-2026')
# ---------------- delete body from '1. Introduction' onward (keep front matter) ----------------
start=TPL['H1']._p; el=start; todel=[]
while el is not None and el is not sectPr:
    todel.append(el); el=el.getnext()
for el in todel: body.remove(el)
# ---------------- numbering maps ----------------
T={'disp':1,'dataset':2,'tp':3,'bp_lme':4,'between':5,'bw':6,'ret20':7,'hr_lme':8,'hall_inc':9,'hall_er':10}
F={'bp_within':1,'bet_cmax':2,'bet_auc':3,'bw':4,'ret20':5,'hr_within':6,'hyst':7,'hall_tl':8,'hall_box':9,'km':10,'hall_er':11,'s033':12}
Tn=lambda k:f"Table {T[k]}"; Fn=lambda k:f"Figure {F[k]}"
w=R['within']; b=R['between']; wb=R['wb']; r20=R['return20']; H=R['hall']; L=H['logit']; s33=R['s033']
f3=lambda x:f"{x:.3f}"; f1=lambda x:f"{x:.1f}"
# ================= 1 INTRODUCTION =================
H1('1. Introduction')
BODY(K('CYB003 is a deuterated'))
BODY(K('In addition to the primary DDI'))
# ================= 2 OBJECTIVES =================
H1('2. Objectives'); BODY('The objectives of this analysis were:')
BUL('To characterize the E-R relationship between CYB003 plasma concentration and reference-corrected change in supine systolic (SBP) and diastolic (DBP) blood pressure, and to estimate the time at which blood pressure returned to within 20% of baseline.')
BUL('To characterize the E-R relationship between CYB003 plasma concentration and reference-corrected change in supine pulse rate.')
BUL('To assess graphically whether the hemodynamic effects and the occurrence of hallucination lag the plasma concentration (hysteresis).')
BUL('To characterize the relationship between CYB003 exposure and the incidence, probability, timing, and duration of hallucination/perceptual AEs, including the concentrations associated with 20% and 50% probability of hallucination (EC20, EC50).')
BUL('To evaluate and contrast between-subject (individual C_{max} and AUC_{0–∞}) and within-subject (time-matched concentration) exposure dependence.')
# ================= 3 DATA =================
H1('3. Data'); H2('3.1 Source Data and Analysis Populations')
BODY(K('Analyses were based on the ADaM'))
TCAP(f'{Tn("disp")}. Participant Disposition and Analysis Populations')
TABLE(['Population','N'],[['Safety Population (≥ 1 dose of any study intervention)','36'],['Dosed in Period 1 (probe cocktail alone, Day 1)','36'],['Dosed in Period 2 (CYB003 16 mg + probe cocktail, Day 8)','34'],['PK Population','35'],['DDI PK Population','33'],['Completed study','34'],['Evaluable CYB003 PK parameters (C_{max}, AUC_{0–∞}, t½)','33']],[4.6,1.1],center_cols=(1,))
H2('3.2 Data Handling')
BUL(K('Timepoint matching'))
BUL(K('Duplicate records'))
BUL('**Baseline and reference correction.** Baseline was the pre-dose measurement obtained on the morning of the dosing day in each period (Day 1 for Period 1 and Day 8 for Period 2), before administration of the probe cocktail and, on Day 8, before CYB003. Hemodynamic responses were analyzed as the reference-corrected change, ΔΔ = (Day 8 change from baseline) − (Day 1 change from baseline) at the same nominal time. This correction removes circadian variation and the intrinsic hemodynamic effects of the probe cocktail.')
BUL('**Concentrations.** Pre-dose (0 h) CYB003 concentrations were set to 0 ng/mL and retained as the zero-concentration reference. Post-dose concentrations below the lower limit of quantification (BLQ) were handled as in the CSR PK analysis: BLQ values before the first quantifiable concentration were set to zero, and BLQ values after the first quantifiable concentration were treated as missing; time-matched records with a missing concentration were excluded.')
BUL(K('Missing data'))
BUL('**Adverse events.** Hallucination/perceptual events were identified by MedDRA preferred term (hallucination; hallucination, visual; hallucination, auditory; hallucination, tactile; somatic hallucination; illusion; visual processing disorder). Event onset and resolution date-times were expressed relative to the Day 8 CYB003 dosing date-time. Two duration measures were derived for each participant: the longest duration of any single episode, and the total hallucination duration, defined as the time from the onset of the first episode to the resolution of the last episode across all perceptual event types. The time to final resolution (time from dose to resolution of the last episode) was also derived.')
H2('3.3 Analysis Datasets')
BODY(f'The composition of the analysis datasets and the number of participants contributing data at each nominal timepoint are summarized in {Tn("dataset")} and {Tn("tp")}, respectively.')
TCAP(f'{Tn("dataset")}. Analysis Dataset Composition')
TABLE(['Analysis','Observations','Participants','Nominal timepoints (h)'],[
 ['ΔΔ SBP/DBP versus concentration','222','34','0, 1, 2, 4, 6, 8, 12, 24'],
 ['ΔΔ pulse rate versus concentration','222','34','0, 1, 2, 4, 6, 8, 12, 24'],
 ['Hallucination status versus concentration','390','34','All PK sampling times, 0–48'],
 ['Between-subject (maximum ΔΔ versus C_{max} or AUC_{0–∞})','33','33','—'],
 ['Return of blood pressure to within 20% of baseline','34','34','1, 2, 4, 6, 8, 12, 24'],
 ['Time to hallucination onset / final resolution','34 / 30','34 / 30','—'],
 ['Hallucination episodes (timing and duration)','47 episodes','30','—']],[2.6,1.0,1.0,1.9],center_cols=(1,2))
TCAP(f'{Tn("tp")}. Number of Participants with Data by Nominal Timepoint (Day 8 unless noted)')
TABLE(['Hour','CYB003 concentration','SBP/DBP (Day 1 / Day 8)'],[['0 (pre-dose)','34','36 / 34'],['1','34','36 / 33'],['2','34','36 / 31'],['3','33','—'],['4','31','36 / 30'],['6','33','36 / 34'],['8','34','36 / 34'],['12','34','36 / 34'],['16','33','—'],['24','34','36 / 34'],['48','34','—']],[1.3,2.0,2.4],center_cols=(0,1,2))
NOTE(K('The smaller numbers'))
# ================= 4 METHODS =================
H1('4. Methods'); H2('4.1 Software')
BODY('Analyses were performed in R (version 4.3.3; nlme 3.1 for mixed-effects models) and in Python (version 3.12; statsmodels 0.14 and matplotlib for graphics). Fixed-effect estimates agreed to three decimal places between the two implementations.')
H2('4.2 Exposure Metrics')
BODY('Two exposure metrics were used. First, the **time-matched CYB003 plasma concentration** at each response timepoint was used for within-subject E-R analyses; this metric spans each participant’s full concentration range, from 0 ng/mL through C_{max} to the elimination phase. Second, **individual summary exposure metrics** from non-compartmental analysis (C_{max}, AUC_{0–∞}, and terminal t½) were used for between-subject E-R analyses.')
GM=f"{R['cmax']['gm']:.1f}"; MX=f"{R['cmax']['max']:.1f}"
BODY('Model predictions are reported at two reference exposures: the **geometric mean C_{max}** ('+GM+' ng/mL), which represents the typical peak concentration after a 16 mg dose, and the **maximum observed C_{max}** ('+MX+' ng/mL), which represents the upper bound of exposure observed in this study. Predictions at the geometric mean C_{max} describe the expected effect in a typical participant; predictions at the maximum C_{max} describe the effect at the highest exposure encountered.')
H2('4.3 Pharmacodynamic Endpoints')
BUL('**Hemodynamic endpoints:** supine SBP, DBP, and pulse rate (ADVS), analyzed as ΔΔ (Section 3.2); and, for SBP and DBP, the time at which the Day 8 value returned to within 20% of the Day 8 baseline (Section 4.4.6).')
BUL('**Hallucination endpoints:** (a) incidence of any hallucination/perceptual AE; (b) hallucination status (present or absent) at each PK sampling time, defined as present when the nominal time fell within an episode’s onset–resolution interval; (c) time to first hallucination onset and time to final resolution; and (d) duration, expressed as the longest single episode and as the total hallucination duration (Section 3.2).')
H2('4.4 Statistical Analysis'); H3('4.4.1 Within-Subject Concentration-Response (Continuous Endpoints)')
BODY(K('For each continuous endpoint'))
EQ(K('Yᵢⱼ ='))
BODY(K('where Yᵢⱼ is').replace('C̄ is the  mean concentration','C̄ is the arithmetic mean of all time-matched concentrations').replace('C̄ is the mean concentration','C̄ is the arithmetic mean of all time-matched concentrations'))
H3('4.4.2 Between-Subject Exposure-Response')
BODY('For each participant, the maximum ΔΔ (the largest reference-corrected increase observed at any post-dose timepoint) was regressed on individual C_{max} and, separately, on individual AUC_{0–∞} by ordinary least squares (OLS); Pearson correlation coefficients (r) and p-values are presented. The participant mean ΔΔ was also examined as an alternative summary and gave similar results (not shown).')
H3('4.4.3 Separate Estimation of Between-Subject and Within-Subject Slopes')
BODY('The between-subject slope was estimated by OLS regression of each participant’s mean ΔΔ on that participant’s mean time-matched concentration (one point per participant). The within-subject slope was estimated from the mixed-effects model of Section 4.4.1 with the participant’s mean concentration included as an additional covariate, so that the concentration term reflects only changes in concentration within a participant over time. In addition, a separate linear regression of ΔΔ on concentration was fitted for each participant with at least four matched observations, and the number of participants whose fitted slope was positive was counted.')
H3('4.4.4 Assessment of Hysteresis')
BODY('A possible delay between concentration and effect (hysteresis) was assessed graphically for SBP, DBP, pulse rate, and the proportion of participants with hallucination, by plotting the arithmetic mean effect against the arithmetic mean concentration at each nominal timepoint and connecting the points in time order. A wide counter-clockwise loop indicates that the effect lags the concentration, whereas a narrow loop with the peak effect occurring near the peak concentration indicates no appreciable delay. This assessment was descriptive; no delayed-effect model was fitted.')
H3('4.4.5 Hallucination')
BODY('Incidence was analyzed by logistic regression on individual C_{max} and AUC_{0–∞}. The probability of hallucination at each PK sampling time was analyzed by logistic regression on the time-matched concentration (pooled across participants). From this model the concentrations associated with 20% and 50% probability of hallucination (EC20 and EC50) were derived, with 90% CIs obtained by cluster bootstrap (400 resamples of participants); the times at which the arithmetic mean and 90th percentile concentration fell below EC20 and EC50 were read from the concentration-time data. Time to first hallucination onset (all CYB003-dosed participants; participants without hallucination censored at 48 h) and time to final resolution (participants with hallucination) were summarized by the Kaplan-Meier method. The relationships between duration (longest single episode, total hallucination duration, and time to final resolution) and C_{max}, AUC_{0–∞}, and terminal t½ were evaluated by Spearman rank correlation; because t½ and AUC_{0–∞} are themselves correlated, Spearman partial correlations of duration with t½ adjusted for AUC_{0–∞}, and with AUC_{0–∞} adjusted for t½, were also computed. Episode onset, duration, and resolution were summarized descriptively (median and IQR) overall and by preferred term and severity.')
H3('4.4.6 Return of Blood Pressure to Within 20% of Baseline')
BODY('For each participant, Day 8 SBP and DBP at each post-dose timepoint were compared with the Day 8 pre-dose baseline. A participant was classified as exceeding the criterion if any post-dose value was more than 20% above baseline. For these participants, the time of return was defined as the first scheduled timepoint after the maximum increase at which the value was no more than 20% above baseline. The proportion of participants more than 20% above baseline was summarized by timepoint. Decreases of more than 20% below baseline were tabulated separately.')
H2('4.5 Model Evaluation and Sensitivity Analyses')
BODY('Model adequacy was assessed by visual inspection of fitted lines and 90% confidence bands against the observed data and against observed means by concentration quantile; by comparison of reference-corrected (ΔΔ) and baseline-corrected (single Δ) fits; by evaluation of optimizer sensitivity (estimates for ΔΔ endpoints were robust across optimizers); and by reproducing the estimates in both R and Python. All analyses were exploratory and no adjustment for multiplicity was applied.')
# ================= 5 RESULTS =================
H1('5. Results'); H2('5.1 Blood Pressure'); H3('5.1.1 Within-Subject Concentration-Response')
BODY(f'Reference-corrected SBP and DBP increased with time-matched CYB003 concentration ({Tn("bp_lme")}, {Fn("bp_within")}). The positive slope persisted after Day 1 reference correction and, for SBP, was steeper than the baseline-corrected (single Δ) slope, indicating a concentration-dependent effect that is not attributable to circadian variation or to the probe cocktail. The largest observed mean ΔΔ occurred at 2 h post-dose (SBP {w["SBP"]["obs_max_mean"]:.1f} mmHg; DBP {w["DBP"]["obs_max_mean"]:.1f} mmHg), close to the median T_{{max}} of CYB003.')
TCAP(f'{Tn("bp_lme")}. Linear Mixed-Effects Model Estimates: ΔΔ Blood Pressure versus CYB003 Concentration')
def predrow(k,lab,unit):
    r=w[k]; return [[f'ΔΔ {lab}','Slope (mmHg per ng/mL)' if unit=='mmHg' else 'Slope (bpm per ng/mL)',f3(r['slope']),f"{f3(r['lo'])}, {f3(r['hi'])}",'< 0.001'],
      ['',f'Predicted ΔΔ at geometric mean C_{{max}} ({unit})',f1(r['pred_gm'][0]),f"{f1(r['pred_gm'][1])}, {f1(r['pred_gm'][2])}",'—'],
      ['',f'Predicted ΔΔ at maximum C_{{max}} ({unit})',f1(r['pred_max'][0]),f"{f1(r['pred_max'][1])}, {f1(r['pred_max'][2])}",'—'],
      ['',f'Observed maximum mean ΔΔ ({unit}), at {r["obs_max_mean_h"]:.0f} h',f1(r['obs_max_mean']),'—','—'],
      ['','Baseline-corrected (single Δ) slope, for reference',f3(r['single_slope']),f"{f3(r['single_lo'])}, {f3(r['single_hi'])}",'< 0.001']]
TABLE(['Endpoint','Parameter','Estimate','90% CI','p-value'],predrow('SBP','SBP','mmHg')+predrow('DBP','DBP','mmHg'),[0.9,2.9,0.9,1.2,0.7],center_cols=(2,3,4))
NOTE(f'N = 222 observations from 34 participants. REML estimation; participant-specific random intercept; concentration centered at the arithmetic mean. CIs by the delta method. Geometric mean C_{{max}} = {R["cmax"]["gm"]:.1f} ng/mL (typical peak concentration after 16 mg); maximum observed C_{{max}} = {R["cmax"]["max"]:.1f} ng/mL (upper bound of observed exposure).')
FCAP(f'{Fn("bp_within")}. ΔΔ SBP (A) and ΔΔ DBP (B) versus Time-Matched CYB003 Concentration')
IMG('newfig/Fig01_BP_within.png',6.4)
NOTE('Points: individual ΔΔ observations. Solid line and shaded band: Day 1 reference-corrected mixed-effects fit with 90% CI. Dashed line: baseline-corrected (single Δ) fit. Vertical dashed line: geometric mean C_{max}.')
H3('5.1.2 Between-Subject Exposure-Response')
bS,bD,bH=b['SBP'],b['DBP'],b['HR']
BODY(f'The maximum ΔΔ for each participant was regressed on individual C_{{max}} ({Fn("bet_cmax")}) and on individual AUC_{{0–∞}} ({Fn("bet_auc")}); results for SBP, DBP, and pulse rate are summarized in {Tn("between")}. No statistically significant relationship with C_{{max}} was identified for any endpoint, and point estimates were of opposite sign for SBP and DBP. Against AUC_{{0–∞}}, the maximum ΔΔ DBP showed a positive correlation (r = {bD["max_AUC"]["r"]:.2f}, p = {bD["max_AUC"]["p"]:.2f}), whereas SBP and pulse rate did not. The participant mean ΔΔ gave similar results for all endpoints (not shown).')
TCAP(f'{Tn("between")}. Between-Subject Regression of Maximum ΔΔ on Individual C_{{max}} and AUC_{{0–∞}}')
rows=[]
for k,lab,u in [('SBP','ΔΔ SBP (mmHg)','mmHg'),('DBP','ΔΔ DBP (mmHg)','mmHg'),('HR','ΔΔ pulse rate (bpm)','bpm')]:
    for xv,xl in [('CMAX','C_{max}'),('AUC','AUC_{0–∞}')]:
        q=b[k][f'max_{xv}']; rows.append([lab if xv=='CMAX' else '',xl,f3(q['slope']),f"{q['r']:+.2f}",f"{q['p']:.2f}",str(q['n'])])
TABLE(['Endpoint','Exposure metric','Slope (per unit)','r','p-value','N'],rows,[1.6,1.2,1.2,0.8,0.9,0.6],center_cols=(2,3,4,5))
NOTE('Slope per ng/mL for C_{max} and per h·ng/mL for AUC_{0–∞}. Response = maximum reference-corrected increase at any post-dose timepoint.')
FCAP(f'{Fn("bet_cmax")}. Maximum ΔΔ SBP (A), DBP (B), and Pulse Rate (C) versus Individual CYB003 C_{{max}}')
IMG('newfig/Fig02_between_Cmax.png',6.5)
FCAP(f'{Fn("bet_auc")}. Maximum ΔΔ SBP (A), DBP (B), and Pulse Rate (C) versus Individual CYB003 AUC_{{0–∞}}')
IMG('newfig/Fig03_between_AUC.png',6.5)
H3('5.1.3 Between-Subject and Within-Subject Slopes')
BODY(f'When the between-subject and within-subject slopes were estimated separately ({Tn("bw")}, {Fn("bw")}), the within-subject slopes were precisely estimated and clearly positive. The between-subject slopes, based on one point per participant, were similar in magnitude but considerably less precise, with confidence intervals approximately five- to six-fold wider; the SBP interval included zero and the DBP interval did not. Of the 33 participants with an estimable individual slope, {wb["SBP"]["npos"]} (SBP) and {wb["DBP"]["npos"]} (DBP) had a positive slope.')
TCAP(f'{Tn("bw")}. Between-Subject and Within-Subject Slope Estimates for ΔΔ Blood Pressure versus CYB003 Concentration')
TABLE(['Endpoint','Slope','Estimate (mmHg per ng/mL)','90% CI','Participants with slope > 0'],[
 ['ΔΔ SBP','Between-subject','0.839','−0.083, 1.761','—'],['','Within-subject',f3(wb['SBP']['within']),f"{f3(wb['SBP']['w_lo'])}, {f3(wb['SBP']['w_hi'])}",f"{wb['SBP']['npos']} / {wb['SBP']['ntot']}"],
 ['ΔΔ DBP','Between-subject','0.699','0.137, 1.261','—'],['','Within-subject',f3(wb['DBP']['within']),f"{f3(wb['DBP']['w_lo'])}, {f3(wb['DBP']['w_hi'])}",f"{wb['DBP']['npos']} / {wb['DBP']['ntot']}"]],[1.0,1.3,1.6,1.4,1.3],center_cols=(2,3,4))
NOTE('Between-subject slope: OLS of participant mean ΔΔ on participant mean time-matched concentration (n = 34). Within-subject slope: mixed-effects model with participant mean concentration as an additional covariate (222 observations).')
FCAP(f'{Fn("bw")}. Between-Subject (A, C) and Within-Subject (B, D) Concentration-ΔΔ Relationships for SBP (A, B) and DBP (C, D)')
IMG('newfig/Fig04_between_within_SBP_DBP.png',6.2)
NOTE('A, C: one point per participant (mean ΔΔ versus mean concentration) with OLS fit and 90% CI. B, D: grey lines are individual participant regression fits (5–8 observations each); green line is the pooled within-subject slope.')
H3('5.1.4 Return of Blood Pressure to Within 20% of Baseline')
rS,rD=r20['SBP'],r20['DBP']
BODY(f'An increase of more than 20% above the Day 8 baseline was observed at least once in {rS["n_exceed"]} of {rS["n"]} participants ({rS["pct_exceed"]:.0f}%) for SBP and in {rD["n_exceed"]} of {rD["n"]} ({rD["pct_exceed"]:.0f}%) for DBP, with the maximum increase most often at 2 h post-dose ({Tn("ret20")}, {Fn("ret20")}). All of these participants had returned to within 20% of baseline by {rS["all_within_by"]:.0f} h (SBP) and {rD["all_within_by"]:.0f} h (DBP); the median time of return was {rS["t_return_median"]:.0f} h for both endpoints (range {rS["t_return_min"]:.0f}–{rS["t_return_max"]:.0f} h for SBP and {rD["t_return_min"]:.0f}–{rD["t_return_max"]:.0f} h for DBP). No participant was more than 20% above baseline at 8 h or later. Separately, values more than 20% below baseline were observed at 12 or 24 h in {rS["late_below_n"]} participants (SBP) and {rD["late_below_n"]} participants (DBP), consistent with the late decline below baseline seen in the mean profiles.')
TCAP(f'{Tn("ret20")}. Return of Blood Pressure to Within 20% of the Day 8 Baseline')
TABLE(['Parameter','SBP','DBP'],[
 ['Participants > 20% above baseline at any post-dose time, n/N (%)',f'{rS["n_exceed"]}/{rS["n"]} ({rS["pct_exceed"]:.0f}%)',f'{rD["n_exceed"]}/{rD["n"]} ({rD["pct_exceed"]:.0f}%)'],
 ['Time of maximum increase, median (h)',f'{rS["t_peak_median"]:.0f}',f'{rD["t_peak_median"]:.0f}'],
 ['Time of return to ≤ 20% above baseline, median (range) (h)',f'{rS["t_return_median"]:.0f} ({rS["t_return_min"]:.0f}–{rS["t_return_max"]:.0f})',f'{rD["t_return_median"]:.0f} ({rD["t_return_min"]:.0f}–{rD["t_return_max"]:.0f})'],
 ['Time by which all participants were ≤ 20% above baseline (h)',f'{rS["all_within_by"]:.0f}',f'{rD["all_within_by"]:.0f}'],
 ['Participants > 20% above baseline at 2 h, %',f'{rS["prop_by_time"]["2.0"]:.0f}',f'{rD["prop_by_time"]["2.0"]:.0f}'],
 ['Participants > 20% below baseline at 12 or 24 h, n',f'{rS["late_below_n"]}',f'{rD["late_below_n"]}']],[3.9,1.3,1.3],center_cols=(1,2))
FCAP(f'{Fn("ret20")}. Proportion of Participants More Than 20% Above the Day 8 Baseline by Timepoint')
IMG('newfig/Fig07_BP_return20.png',5.2)
# ---- 5.2 HR ----
H2('5.2 Heart Rate'); hr=w['HR']
BODY(f'Reference-corrected pulse rate increased with CYB003 concentration ({Tn("hr_lme")}, {Fn("hr_within")}). Because the Day 1 reference correction accounts for the heart-rate-lowering effect of the probe cocktail (metoprolol), the ΔΔ slope was larger than the baseline-corrected slope. The largest observed mean ΔΔ ({hr["obs_max_mean"]:.1f} bpm) occurred at {hr["obs_max_mean_h"]:.0f} h. The between-subject relationships of maximum ΔΔ pulse rate with individual C_{{max}} and AUC_{{0–∞}} were not statistically significant ({Tn("between")}; {Fn("bet_cmax")}C and {Fn("bet_auc")}C).')
TCAP(f'{Tn("hr_lme")}. Linear Mixed-Effects Model Estimates: ΔΔ Pulse Rate versus CYB003 Concentration')
TABLE(['Parameter','Estimate','90% CI','p-value'],[
 ['Within-subject slope (bpm per ng/mL)',f3(hr['slope']),f"{f3(hr['lo'])}, {f3(hr['hi'])}",'< 0.001'],
 ['Predicted ΔΔ at geometric mean C_{max} (bpm)',f1(hr['pred_gm'][0]),f"{f1(hr['pred_gm'][1])}, {f1(hr['pred_gm'][2])}",'—'],
 ['Predicted ΔΔ at maximum C_{max} (bpm)',f1(hr['pred_max'][0]),f"{f1(hr['pred_max'][1])}, {f1(hr['pred_max'][2])}",'—'],
 [f'Observed maximum mean ΔΔ (bpm), at {hr["obs_max_mean_h"]:.0f} h',f1(hr['obs_max_mean']),'—','—'],
 ['Baseline-corrected (single Δ) slope, for reference',f3(hr['single_slope']),f"{f3(hr['single_lo'])}, {f3(hr['single_hi'])}",'< 0.001']],[3.3,1.0,1.4,0.8],center_cols=(1,2,3))
NOTE('N = 222 observations from 34 participants. Geometric mean and maximum C_{max} as defined in Section 4.2.')
FCAP(f'{Fn("hr_within")}. ΔΔ Pulse Rate versus Time-Matched CYB003 Concentration')
IMG('newfig/Fig06_HR_within.png',4.9)
# ---- 5.3 Hysteresis ----
H2('5.3 Assessment of Hysteresis')
BODY(f'Time-ordered plots of mean effect versus mean concentration are shown for SBP, DBP, pulse rate, and the proportion of participants with hallucination in {Fn("hyst")}. For all three hemodynamic endpoints the loop was narrow and the maximum mean effect occurred at or near the time of maximum mean concentration (2–4 h), indicating no appreciable delay between concentration and effect. For hallucination, the proportion of participants with hallucination rose with concentration during absorption and declined with concentration during elimination; at a given concentration the proportion was somewhat lower during the elimination phase than during absorption (a modest clockwise loop), so that hallucination did not outlast the decline in concentration. Delayed-effect modeling was therefore not pursued for any endpoint.')
FCAP(f'{Fn("hyst")}. Time-Ordered Mean Effect versus Mean CYB003 Concentration: ΔΔ SBP (A), ΔΔ DBP (B), ΔΔ Pulse Rate (C), and Proportion of Participants with Hallucination (D)')
IMG('newfig/Fig05_hysteresis_all.png',6.6)
NOTE('Points are arithmetic means at each nominal timepoint (labeled in hours), connected in time order.')
# ---- 5.4 Hallucination ----
H2('5.4 Hallucination'); H3('5.4.1 Incidence, Timing, and Severity')
nh=H['nonhall']
BODY(f'Hallucination/perceptual AEs were reported by {H["inc_n"]} of {H["inc_N"]} participants dosed with CYB003 ({100*H["inc_n"]/H["inc_N"]:.0f}%), comprising {H["episodes"]} episodes; the most frequent preferred term was ‘Hallucination, visual’ (24 episodes in 24 participants). Onset was early, episodes were transient, and resolution occurred within the dosing day in all but one participant ({Tn("hall_inc")}, {Fn("hall_tl")}, {Fn("hall_box")}). By Kaplan-Meier estimation, the median time to first onset was {H["km"]["median_onset"]:.1f} h and the median time to final resolution was {H["km"]["median_resolution"]:.1f} h after dosing ({Fn("km")}). All events were mild or moderate in severity ({H["sev"].get("MILD",0)} mild, {H["sev"].get("MODERATE",0)} moderate) and resolved without intervention; duration did not differ meaningfully by severity.')
BODY(f'The four participants without a hallucination/perceptual AE had C_{{max}} values of {", ".join(f"{x:.1f}" for x in sorted(nh["cmax"]))} ng/mL (median {nh["cmax_med_nh"]:.1f} ng/mL, compared with {nh["cmax_med_h"]:.1f} ng/mL in participants with an event; p = {nh["p_cmax"]:.2f}) and AUC_{{0–∞}} median {nh["auc_med_nh"]:.0f} h·ng/mL (compared with {nh["auc_med_h"]:.0f} h·ng/mL; p = {nh["p_auc"]:.2f}). Three of the four had C_{{max}} values among the lowest observed, but the fourth had above-average exposure; exposure alone therefore does not account for the absence of hallucination in these participants.')
TCAP(f'{Tn("hall_inc")}. Hallucination/Perceptual Adverse Events: Incidence and Timing Relative to CYB003 Dose')
TABLE(['Parameter','Value'],[
 ['Participants with ≥ 1 event, n (%)',f'{H["inc_n"]} / {H["inc_N"]} ({100*H["inc_n"]/H["inc_N"]:.0f}%)'],
 ['Episodes, n',f'{H["episodes"]}'],['Hallucination, visual: episodes, n (participants)','24 (24)'],
 ['Onset, h post-dose, median (IQR)',f'{H["onset_med"]:.2f} ({H["onset_iqr"][0]:.2f}, {H["onset_iqr"][1]:.2f})'],
 ['Time to first onset, Kaplan-Meier median (h)',f'{H["km"]["median_onset"]:.1f}'],
 ['Single-episode duration, h, median (IQR)',f'{H["dur_med"]:.2f} ({H["dur_iqr"][0]:.2f}, {H["dur_iqr"][1]:.2f})'],
 ['Longest single episode per participant, h, median',f'{H["longest_med"]:.1f}'],
 ['Total hallucination duration (first onset to last resolution), h, median (IQR)',f'{H["total_med"]:.1f} ({H["total_iqr"][0]:.1f}, {H["total_iqr"][1]:.1f})'],
 ['Time to final resolution, h post-dose, median (IQR); maximum',f'{H["off_med"]:.2f} ({H["off_iqr"][0]:.2f}, {H["off_iqr"][1]:.2f}); {H["off_max"]:.1f}'],
 ['Time to final resolution, Kaplan-Meier median (h)',f'{H["km"]["median_resolution"]:.1f}'],
 ['Severity, n: mild / moderate / severe',f'{H["sev"].get("MILD",0)} / {H["sev"].get("MODERATE",0)} / 0']],[3.9,2.6])
FCAP(f'{Fn("hall_tl")}. Hallucination/Perceptual Episodes Relative to Time of CYB003 Dose: Episode Timelines by Participant (A) and Distribution of Single-Episode Duration (B)')
IMG('newfig/Fig08_hall_timelines.png',5.8)
NOTE('A: each bar is one episode from onset to resolution; vertical red line marks the CYB003 dose. B: dashed line marks the median single-episode duration.')
FCAP(f'{Fn("hall_box")}. Hallucination Onset, Duration, and Resolution (A), Single-Episode Duration by Preferred Term (B), and by Severity (C)')
IMG('newfig/Fig09_hall_boxplots.png',6.6)
NOTE('Boxes show median and interquartile range; all individual episodes are plotted. In C, the four moderate events are shown in red.')
FCAP(f'{Fn("km")}. Kaplan-Meier Estimates of Time to First Hallucination Onset (A) and Time to Final Resolution (B)')
IMG('newfig/Fig10_hall_KM.png',6.2)
NOTE('A: all 34 CYB003-dosed participants; the 4 participants without hallucination are censored at 48 h. B: the 30 participants with hallucination.')
H3('5.4.2 Exposure-Response')
dur=H['dur']; tb=H['t_below']; pc=H['partial']
BODY(f'Because hallucination occurred in nearly all participants at the 16 mg dose, there was little scope for incidence to vary with exposure, and no significant relationship between incidence and individual C_{{max}} or AUC_{{0–∞}} was identified ({Tn("hall_er")}). The time-matched analysis addresses a different question: whether a participant is more likely to be hallucinating at times when their concentration is higher. This relationship was strong ({Fn("hall_er")}B): the model-predicted probability of hallucination was {L["p0"]:.2f} at 0 ng/mL and {L["pgm"]:.2f} at the geometric mean C_{{max}}, with EC20 = {L["EC20"]:.1f} ng/mL (90% CI {L["EC20_ci"][0]:.1f}, {L["EC20_ci"][1]:.1f}) and EC50 = {L["EC50"]:.1f} ng/mL (90% CI {L["EC50_ci"][0]:.1f}, {L["EC50_ci"][1]:.1f}). The proportion of participants with hallucination over time followed the mean concentration-time profile ({Fn("hall_er")}A), peaking at {100*H["prev_peak"]:.0f}% at {H["prev_peak_h"]:.0f} h and returning to 0% by 12 h. The arithmetic mean concentration fell below EC50 by {tb["EC50_mean"]:.0f} h and below EC20 by {tb["EC20_mean"]:.0f} h post-dose; the 90th percentile concentration fell below EC20 by {tb["EC20_p90"]:.0f} h. On this basis, concentrations below approximately 7 ng/mL (EC20) were associated with a low probability of hallucination, and essentially all participants were below this level by 12–16 h after dosing, consistent with the observed absence of hallucination after 12 h.')
BODY(f'Duration of the perceptual experience was related to the rate of elimination rather than to peak or total exposure. Time to final resolution correlated with terminal t½ (Spearman ρ = {H["dur"]["total_THALF"]["rho"]:.2f}; see note) and the total hallucination duration and longest single episode showed similar trends (ρ = {dur["total_THALF"]["rho"]:.2f}, p = {dur["total_THALF"]["p"]:.3f}; ρ = {dur["longest_THALF"]["rho"]:.2f}, p = {dur["longest_THALF"]["p"]:.3f}), whereas none of the duration measures correlated with C_{{max}} or AUC_{{0–∞}} ({Fn("hall_er")}C, D). Terminal t½ and AUC_{{0–∞}} were themselves correlated (ρ = {H["thalf_auc_rho"]:.2f}). After adjustment for AUC_{{0–∞}}, the partial correlation of total duration with t½ was {pc["total_thalf_given_auc"][0]:.2f} (p = {pc["total_thalf_given_auc"][1]:.2f}), whereas after adjustment for t½ the partial correlation with AUC_{{0–∞}} was {pc["total_auc_given_thalf"][0]:.2f} (p = {pc["total_auc_given_thalf"][1]:.2f}), indicating that the association with duration is carried by the elimination half-life rather than by total exposure.'.replace('(Spearman ρ = 0.34; see note)','(Spearman ρ = 0.40, p = 0.031)'))
TCAP(f'{Tn("hall_er")}. Hallucination Exposure-Response Analyses')
TABLE(['Analysis','Estimate','p-value','N'],[
 ['Incidence versus C_{max} (logistic), OR per 10 ng/mL',f'{H["inc_CMAX"]["or10"]:.1f}' if H["inc_CMAX"]["or10"] else 'n.e.',f'{H["inc_CMAX"]["p"]:.2f}' if H["inc_CMAX"]["p"] else '—','33'],
 ['Incidence versus AUC_{0–∞} (logistic)','Not significant',f'{H["inc_AUC"]["p"]:.2f}' if H["inc_AUC"]["p"] else '—','33'],
 ['Probability of hallucination versus time-matched concentration, OR per 10 ng/mL',f'{L["or10"]:.2f}','< 0.001',f'{L["n"]}'],
 ['EC20 (concentration at 20% probability), ng/mL (90% CI)',f'{L["EC20"]:.1f} ({L["EC20_ci"][0]:.1f}, {L["EC20_ci"][1]:.1f})','—','—'],
 ['EC50 (concentration at 50% probability), ng/mL (90% CI)',f'{L["EC50"]:.1f} ({L["EC50_ci"][0]:.1f}, {L["EC50_ci"][1]:.1f})','—','—'],
 ['Predicted probability: 0 ng/mL → geometric mean C_{max}',f'{L["p0"]:.2f} → {L["pgm"]:.2f}','—','—'],
 ['Proportion with hallucination: peak; return to 0%',f'{100*H["prev_peak"]:.0f}% at {H["prev_peak_h"]:.0f} h; 0% by 12 h','—','—'],
 ['Time at which mean concentration fell below EC50 / EC20 (h)',f'{tb["EC50_mean"]:.0f} / {tb["EC20_mean"]:.0f}','—','—'],
 ['Time at which 90th percentile concentration fell below EC50 / EC20 (h)',f'{tb["EC50_p90"]:.0f} / {tb["EC20_p90"]:.0f}','—','—'],
 ['Time to final resolution versus terminal t½, Spearman ρ','0.40','0.031','29'],
 ['Total hallucination duration versus terminal t½, Spearman ρ',f'{dur["total_THALF"]["rho"]:.2f}',f'{dur["total_THALF"]["p"]:.3f}','29'],
 ['Longest single episode versus terminal t½, Spearman ρ',f'{dur["longest_THALF"]["rho"]:.2f}',f'{dur["longest_THALF"]["p"]:.3f}','29'],
 ['Duration measures versus C_{max} or AUC_{0–∞}','Not significant','> 0.4','29'],
 ['Partial ρ: total duration with t½, adjusted for AUC_{0–∞}',f'{pc["total_thalf_given_auc"][0]:.2f}',f'{pc["total_thalf_given_auc"][1]:.2f}','29'],
 ['Partial ρ: total duration with AUC_{0–∞}, adjusted for t½',f'{pc["total_auc_given_thalf"][0]:.2f}',f'{pc["total_auc_given_thalf"][1]:.2f}','29']],[3.9,1.5,0.7,0.5],center_cols=(1,2,3))
NOTE('OR = odds ratio. EC20/EC50 and their 90% CIs from the pooled logistic model (cluster bootstrap by participant). Duration measures as defined in Section 3.2.')
FCAP(f'{Fn("hall_er")}. Proportion of Participants with Hallucination versus Time with Mean Concentration (A), Probability of Hallucination versus Concentration with EC20 and EC50 (B), and Total Hallucination Duration versus Terminal t½ (C) and AUC_{{0–∞}} (D)')
IMG('newfig/Fig11_hall_ER.png',6.2)
# ---- 5.5 individual ----
H2('5.5 Illustrative Individual Profile')
BODY(f'Participant 01-033 (55-year-old male, 63.1 kg) experienced the longest visual hallucination in the study (10.7 h; mild; resolved without intervention) together with a concurrent mild euphoric mood (approximately 1.9–3.9 h post-dose). The participant’s C_{{max}} (26.8 ng/mL) was close to the population geometric mean, whereas T_{{max}} (4.0 h) was later than the population median (approximately {R["tmax_median"]:.1f} h) and terminal t½ (5.9 h) was longer than the population mean (approximately {R["thalf_mean"]:.1f} h). His concentrations during the later part of the episode were not higher than those of other participants: {s33["c8"]["val"]:.1f} ng/mL at 8 h and {s33["c12"]["val"]:.1f} ng/mL at 12 h, compared with population medians of {s33["c8"]["pop_median"]:.1f} and {s33["c12"]["pop_median"]:.1f} ng/mL, respectively. The prolonged effect in this participant is therefore not explained by higher late exposure; hallucination persisted at concentrations (around 5–6 ng/mL at 12 h) at which most participants no longer reported hallucination, suggesting greater individual sensitivity or a slower offset of effect. Concurrent hemodynamic changes (SBP +28 mmHg and DBP +11 mmHg near T_{{max}}, returning to baseline by 24 h) followed the exposure profile; on Day 1 (probe cocktail alone), blood pressure was essentially unchanged ({Fn("s033")}).')
FCAP(f'{Fn("s033")}. Participant 01-033: Day 8 Blood Pressure and CYB003 Concentration-Time Profile with Adverse Event Windows')
IMG('newfig/Fig12_subject033.png',5.9)
# ================= 6 DISCUSSION =================
H1('6. Discussion')
BODY('Following a single 16 mg dose, CYB003 produced concentration-dependent PD effects comprising increases in blood pressure and pulse rate and a perceptual (hallucinogenic) effect, each following the plasma concentration-time course. The blood pressure effect was transient: among participants whose SBP or DBP rose more than 20% above baseline (41% for each), the median time of return to within 20% of baseline was 4 h, and no participant exceeded this criterion at 8 h or later. Hallucination had a median single-episode duration of 4.8 h and a median time to final resolution of 6.5 h.')
BODY('The Day 1 (probe cocktail alone) period served as a within-subject, time-matched reference for the hemodynamic endpoints, removing circadian variation and the intrinsic effects of the cocktail, notably metoprolol. The positive concentration-response slopes persisted after this correction and were steeper for SBP and pulse rate, supporting a drug-related rather than procedural origin. No appreciable hysteresis was observed for any endpoint on the time-ordered plots.')
BODY('A consistent feature across the hemodynamic endpoints was the difference in precision between the within-subject and between-subject E-R estimates. The within-subject slopes were precisely estimated and clearly positive (31 of 33 individual SBP slopes positive). Between-subject estimates, whether based on maximum ΔΔ against C_{max} or AUC_{0–∞} or on participant means against mean concentration, were imprecise: confidence intervals were several-fold wider, most included zero, and only the maximum ΔΔ DBP against AUC_{0–∞} reached statistical significance. Three factors account for this difference.')
BODY('First, the two analyses differ in the contrast in exposure available to detect a slope. Within a participant, concentration traverses the complete profile from 0 ng/mL through C_{max} and back toward zero during elimination, providing a wide span over which the response can be related to concentration. Between participants, exposure varies only to the extent that individual C_{max} or AUC_{0–∞} values differ, which at a single 16 mg dose spanned approximately 2.6-fold for C_{max}; this limited spread provides little ability to detect a between-subject slope.')
BODY('Second, the two analyses are subject to different sources of variability. In the within-subject analysis each participant serves as their own control, so that stable inter-individual differences (in baseline blood pressure, body size, autonomic tone, and response to the study procedures) do not enter the residual variance. The between-subject analysis compares participants with one another, and these same inter-individual differences become the dominant source of variability, obscuring any modest exposure-related component.')
BODY('Third, the two analyses use different amounts of information. The within-subject analysis draws on 222 serial time-matched observations (5 to 8 per participant) that capture both the rise and the decline of the response in relation to concentration. The between-subject analysis reduces each participant to a single summary value, and a single peak concentration is an incomplete descriptor of the exposure profile to which the hemodynamic response relates.')
BODY('Consequently, the absence of a clear between-subject relationship does not constitute evidence against a drug effect. The within-subject concentration-response, which uses the full exposure profile and is unaffected by stable inter-individual differences, is the appropriate basis for E-R characterization and for projection across doses.')
BODY('A related point concerns the interpretation of the concentration-time relationship within a single-dose study. Because all participants received the same dose at the same clock time, plasma concentration rose and fell on a fixed schedule, and any other quantity that also changes with time of day (for example, the circadian blood pressure rhythm, posture, meals, or study procedures) would appear to be related to concentration. The Day 1 reference correction removes those components that were the same on both study days, but it cannot remove anything that occurred only on Day 8 and coincided with the rise and fall of concentration. This residual possibility is a limitation of the design rather than of the analysis.')
BODY('The hallucination analyses indicated that the determinants of effect intensity and effect duration differ. The probability of hallucination at a given time was strongly concentration-dependent, with EC20 and EC50 of approximately 7 and 15 ng/mL, whereas the duration of the experience was associated with terminal t½ rather than with peak or total exposure. Although t½ and AUC_{0–∞} are correlated (slower elimination increases AUC_{0–∞} for a given C_{max}), the partial correlations show that the association with duration is carried by t½ and not by AUC_{0–∞}: for a given total exposure, participants who eliminated CYB003 more slowly had longer perceptual effects. These findings suggest that the concentration attained primarily determines the magnitude and likelihood of the effect, whereas the rate of elimination determines its duration. The EC20 provides a practical reference: once concentrations fall below approximately 7 ng/mL, which occurred in essentially all participants by 12–16 h after dosing, the probability of hallucination is low, consistent with the observed absence of hallucination after 12 h.')
BODY('**Limitations.** The analysis is based on a single dose level (16 mg) and therefore characterizes exposure-response rather than dose-response; extrapolation to other doses requires linkage through population PK and confirmation with additional dose levels. The population comprised healthy adult males (n = 34). The hallucination endpoint is categorical (AE preferred term) with no continuous measure of intensity; logistic models were pooled across participants without a random effect given the exploratory scope, and the EC20/EC50 estimates should be regarded as approximate. Some Day 8 vital-sign observations at 2–4 h (the highest concentrations) were missing. Only parent CYB003 was quantified. All analyses were exploratory and unadjusted for multiplicity.')
# ================= 7 CONCLUSIONS =================
H1('7. Conclusions')
BUL(f'A single 16 mg oral dose of CYB003 produced transient, concentration-dependent increases in supine blood pressure (model-predicted ΔΔ SBP +{w["SBP"]["pred_gm"][0]:.1f} mmHg and ΔΔ DBP +{w["DBP"]["pred_gm"][0]:.1f} mmHg at the geometric mean C_{{max}}) and pulse rate (+{hr["pred_gm"][0]:.1f} bpm). Blood pressure increases of more than 20% above baseline occurred in 41% of participants and resolved with a median time of 4 h; all participants were within 20% of baseline by 8 h.')
BUL(f'Hallucination/perceptual AEs occurred in {100*H["inc_n"]/H["inc_N"]:.0f}% of participants, with a median single-episode duration of {H["dur_med"]:.1f} h and a Kaplan-Meier median time to final resolution of {H["km"]["median_resolution"]:.1f} h. The probability of hallucination increased steeply with concentration (EC20 approximately {L["EC20"]:.0f} ng/mL, EC50 approximately {L["EC50"]:.0f} ng/mL), and the duration of the experience was associated with terminal t½ rather than with peak or total exposure.')
BUL('E-R relationships were precisely characterized within-subject; between-subject estimates over the narrow single-dose exposure range were imprecise. The within-subject concentration-response is the appropriate basis for characterization and dose projection.')
BUL('The findings are exploratory. The hemodynamic and perceptual effects were transient and resolved within the observation period. Confirmation of the exposure-response relationships across dose levels is recommended.')
# ================= FRONT MATTER TABLES =================
def refill(tbl_idx,headers,rows,widths):
    old=doc.tables[tbl_idx]._tbl; new=doc.add_table(rows=1+len(rows),cols=len(headers)); new.autofit=False; borders(new)
    for j,h in enumerate(headers): c=new.cell(0,j); shade(c,'1F3864'); set_cell(c,h,bold=True,white=True)
    for i,row in enumerate(rows,1):
        for j,v in enumerate(row): set_cell(new.cell(i,j),v)
    for j,wd in enumerate(widths):
        for row in new.rows: row.cells[j].width=Inches(wd)
    old.addprevious(new._tbl); old.getparent().remove(old)
LoT=[[f'Table {T["disp"]}','Participant Disposition and Analysis Populations'],[f'Table {T["dataset"]}','Analysis Dataset Composition'],[f'Table {T["tp"]}','Number of Participants with Data by Nominal Timepoint'],
 [f'Table {T["bp_lme"]}','Linear Mixed-Effects Model Estimates: ΔΔ Blood Pressure versus CYB003 Concentration'],[f'Table {T["between"]}','Between-Subject Regression of Maximum ΔΔ on Individual C_{max} and AUC_{0–∞}'],
 [f'Table {T["bw"]}','Between-Subject and Within-Subject Slope Estimates for ΔΔ Blood Pressure'],[f'Table {T["ret20"]}','Return of Blood Pressure to Within 20% of the Day 8 Baseline'],
 [f'Table {T["hr_lme"]}','Linear Mixed-Effects Model Estimates: ΔΔ Pulse Rate versus CYB003 Concentration'],[f'Table {T["hall_inc"]}','Hallucination/Perceptual Adverse Events: Incidence and Timing'],[f'Table {T["hall_er"]}','Hallucination Exposure-Response Analyses']]
LoF=[[f'Figure {F["bp_within"]}','ΔΔ SBP and ΔΔ DBP versus Time-Matched CYB003 Concentration'],[f'Figure {F["bet_cmax"]}','Maximum ΔΔ SBP, DBP, and Pulse Rate versus Individual CYB003 C_{max}'],[f'Figure {F["bet_auc"]}','Maximum ΔΔ SBP, DBP, and Pulse Rate versus Individual CYB003 AUC_{0–∞}'],
 [f'Figure {F["bw"]}','Between-Subject and Within-Subject Concentration-ΔΔ Relationships for SBP and DBP'],[f'Figure {F["ret20"]}','Proportion of Participants More Than 20% Above the Day 8 Baseline by Timepoint'],[f'Figure {F["hr_within"]}','ΔΔ Pulse Rate versus Time-Matched CYB003 Concentration'],
 [f'Figure {F["hyst"]}','Time-Ordered Mean Effect versus Mean CYB003 Concentration (SBP, DBP, Pulse Rate, Hallucination)'],[f'Figure {F["hall_tl"]}','Hallucination/Perceptual Episodes Relative to Time of CYB003 Dose'],[f'Figure {F["hall_box"]}','Hallucination Onset, Duration, and Resolution by Preferred Term and Severity'],
 [f'Figure {F["km"]}','Kaplan-Meier Estimates of Time to First Hallucination Onset and Time to Final Resolution'],[f'Figure {F["hall_er"]}','Hallucination Exposure-Response'],[f'Figure {F["s033"]}','Participant 01-033: Day 8 Blood Pressure and CYB003 Concentration-Time Profile']]
ABB=[['ADaM','Analysis Data Model'],['AE / TEAE','Adverse event / treatment-emergent adverse event'],['AUC_{0–∞}','Area under the plasma concentration-time curve from time zero extrapolated to infinity'],['BLQ','Below the lower limit of quantification'],['BP','Blood pressure'],['CI','Confidence interval'],['C_{max}','Maximum observed plasma concentration'],['CSR','Clinical Study Report'],['CYP','Cytochrome P450'],['DBP / SBP','Diastolic / systolic blood pressure'],['DDI','Drug-drug interaction'],['Δ / ΔΔ','Change from baseline / reference-corrected change (Day 8 Δ minus Day 1 Δ)'],['EC20 / EC50','Concentration associated with 20% / 50% probability of hallucination'],['E-R','Exposure-response'],['IQR','Interquartile range'],['LME','Linear mixed-effects'],['MedDRA','Medical Dictionary for Regulatory Activities'],['NCA','Non-compartmental analysis'],['OLS','Ordinary least squares'],['OR','Odds ratio'],['PD / PK','Pharmacodynamic / pharmacokinetic'],['REML','Restricted maximum likelihood'],['t½','Terminal elimination half-life'],['T_{max}','Time of maximum observed plasma concentration']]
# refill from last to first so indices stay valid (LoT=1, LoF=2, Abbrev=3)
refill(3,['Abbreviation','Definition'],ABB,[1.4,5.2]); refill(2,['Figure','Title'],LoF,[0.9,5.7]); refill(1,['Table','Title'],LoT,[0.9,5.7])
OUT='CYB003-101_PKPD_Exploratory_ER_v0.4.docx'; doc.save(OUT); print("saved",OUT)
