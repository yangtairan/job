import pandas as pd, numpy as np, re, json, warnings
import statsmodels.formula.api as smf, statsmodels.api as sm
from scipy import stats
warnings.filterwarnings('ignore')
Z90=stats.norm.ppf(0.95)
def load(n): return pd.read_sas(f'adam/ADaM/{n}.sas7bdat',format='sas7bdat',encoding='latin-1')
adpc,advs,adpp,adae,adsl=[load(x) for x in ['adpc','advs','adpp','adae','adsl']]
def hrs(s):
    s=str(s).lower()
    if 'pre' in s: return 0.0
    m=re.search(r'([\d.]+)\s*hour',s); return float(m.group(1)) if m else np.nan
R={}
# ---------- exposure ----------
cyb=adpc[(adpc.PARAMCD=='CYB003')&(adpc.APERIODC=='PERIOD 2')].copy(); cyb['H']=cyb['ATPT'].map(hrs)
cyb=cyb.groupby(['USUBJID','H'],as_index=False).AVAL.mean().rename(columns={'AVAL':'CONC'}).dropna(subset=['CONC','H'])
pp=adpp[adpp.PPCAT=='CYB003 Concentration']
def pk(code,name): return pp[pp.PARAMCD==code][['USUBJID','AVAL']].rename(columns={'AVAL':name})
expo=pk('CMAX','CMAX').merge(pk('AUCIFO','AUC'),on='USUBJID',how='outer').merge(pk('LAMZHL','THALF'),on='USUBJID',how='outer').merge(pk('TMAX','TMAX'),on='USUBJID',how='outer')
gm=float(np.exp(np.log(expo.CMAX.dropna()).mean())); mx=float(expo.CMAX.max())
gmA=float(np.exp(np.log(expo.AUC.dropna()).mean())); mxA=float(expo.AUC.max())
R['cmax']={'gm':gm,'max':mx,'n':int(expo.CMAX.notna().sum())}; R['auc']={'gm':gmA,'max':mxA}
R['tmax_median']=float(expo.TMAX.median()); R['thalf_mean']=float(expo.THALF.mean()); R['thalf_median']=float(expo.THALF.median())
print(f"Cmax gm {gm:.2f} max {mx:.2f} | AUC gm {gmA:.1f} max {mxA:.1f} | Tmax median {R['tmax_median']:.2f} | t1/2 mean {R['thalf_mean']:.2f}")

# ---------- delta-delta datasets ----------
def dd(param):
    d8=advs[(advs.PARAMCD==param)&(advs.APERIODC=='PERIOD 2')].copy(); d8['H']=d8['ATPT'].map(hrs)
    d1=advs[(advs.PARAMCD==param)&(advs.APERIODC=='PERIOD 1')].copy(); d1['H']=d1['ATPT'].map(hrs)
    d8=d8.groupby(['USUBJID','H'],as_index=False).agg(d8=('CHG','mean'),aval8=('AVAL','mean'),base8=('BASE','mean'))
    d1=d1.groupby(['USUBJID','H'],as_index=False).CHG.mean().rename(columns={'CHG':'d1'})
    return d8.merge(d1,on=['USUBJID','H']).assign(dd=lambda t:t.d8-t.d1).merge(cyb,on=['USUBJID','H']).dropna(subset=['dd','CONC'])
def lme(m,y):
    d=m.copy(); cb=d.CONC.mean(); d['xc']=d.CONC-cb; d['Y']=d[y]
    f=smf.mixedlm("Y~xc",d,groups=d.USUBJID).fit(method='powell',reml=True)
    b=f.fe_params; V=f.cov_params().loc[['Intercept','xc'],['Intercept','xc']]; se=float(np.sqrt(V.loc['xc','xc']))
    def pr(c): x=np.array([1,c-cb]); s=np.sqrt(x@V.values@x); p=b['Intercept']+b['xc']*(c-cb); return [float(p),float(p-Z90*s),float(p+Z90*s)]
    return dict(slope=float(b['xc']),lo=float(b['xc']-Z90*se),hi=float(b['xc']+Z90*se),p=float(f.pvalues['xc']),
                pred_gm=pr(gm),pred_max=pr(mx),b0=float(b['Intercept']),cb=float(cb),V=V.values.tolist(),n=int(len(d)),ns=int(d.USUBJID.nunique()))
ENDS={'SBP':'SYSBPSU','DBP':'DIABPSU','HR':'PULSESU'}
M={k:dd(v) for k,v in ENDS.items()}
R['within']={}
for k,m in M.items():
    r=lme(m,'dd'); r1=lme(m,'d8')
    tc=m.groupby('H').dd.mean(); r['obs_max_mean']=float(tc.max()); r['obs_max_mean_h']=float(tc.idxmax())
    r['single_slope']=r1['slope']; r['single_lo']=r1['lo']; r['single_hi']=r1['hi']
    R['within'][k]=r
    print(f"{k}: dd slope {r['slope']:.3f} ({r['lo']:.3f},{r['hi']:.3f}) pred gm {r['pred_gm'][0]:.1f} max {r['pred_max'][0]:.1f}; single {r1['slope']:.3f}; obs max mean dd {r['obs_max_mean']:.1f} @ {r['obs_max_mean_h']:.0f}h")

# ---------- between-subject: MAX change vs Cmax and AUC (mean examined too) ----------
R['between']={}
for k,m in M.items():
    s=m.groupby('USUBJID').agg(mx=('dd','max'),mn=('dd','mean')).reset_index().merge(expo,on='USUBJID')
    out={}
    for yv,yl in [('mx','max'),('mn','mean')]:
        for xv in ['CMAX','AUC']:
            d=s.dropna(subset=[xv,yv]); o=sm.OLS(d[yv],sm.add_constant(d[xv])).fit()
            out[f'{yl}_{xv}']=dict(slope=float(o.params[xv]),r=float(np.corrcoef(d[yv],d[xv])[0,1]),p=float(o.pvalues[xv]),n=int(len(d)))
    R['between'][k]=out
    print(f"{k} between: max~Cmax slope {out['max_CMAX']['slope']:+.3f} r {out['max_CMAX']['r']:+.2f} p {out['max_CMAX']['p']:.2f} | max~AUC r {out['max_AUC']['r']:+.2f} p {out['max_AUC']['p']:.2f} | mean~Cmax r {out['mean_CMAX']['r']:+.2f} | mean~AUC r {out['mean_AUC']['r']:+.2f}")

# ---------- within/between slopes (separate estimation) + individual slopes ----------
R['wb']={}
for k in ['SBP','DBP']:
    m=M[k].copy(); m['cbar']=m.groupby('USUBJID').CONC.transform('mean'); m['cw']=m.CONC-m.cbar; m['Y']=m.dd
    f=smf.mixedlm("Y~cw+cbar",m,groups=m.USUBJID).fit(method='powell',reml=True)
    V=f.cov_params(); sew=float(np.sqrt(V.loc['cw','cw'])); seb=float(np.sqrt(V.loc['cbar','cbar'])) if np.isfinite(V.loc['cbar','cbar']) else np.nan
    sl=[np.polyfit(g.CONC,g.dd,1)[0] for _,g in m.groupby('USUBJID') if len(g)>=4 and g.CONC.std()>0]
    R['wb'][k]=dict(within=float(f.fe_params['cw']),w_lo=float(f.fe_params['cw']-Z90*sew),w_hi=float(f.fe_params['cw']+Z90*sew),
                    between=float(f.fe_params['cbar']),b_se=seb,npos=int(sum(np.array(sl)>0)),ntot=len(sl))
    print(f"{k} w/b: within {R['wb'][k]['within']:.3f} between {R['wb'][k]['between']:.3f}; {R['wb'][k]['npos']}/{R['wb'][k]['ntot']} positive")

# ---------- BP return to within 20% of baseline (Day 8 absolute vs Day 8 pre-dose) ----------
R['return20']={}
for k,param in [('SBP','SYSBPSU'),('DBP','DIABPSU')]:
    d=advs[(advs.PARAMCD==param)&(advs.APERIODC=='PERIOD 2')].copy(); d['H']=d['ATPT'].map(hrs)
    d=d.groupby(['USUBJID','H'],as_index=False).agg(v=('AVAL','mean'),base=('BASE','mean')).dropna(subset=['H','v','base'])
    rows=[]
    for sid,g in d.groupby('USUBJID'):
        g=g.sort_values('H'); b=g.base.iloc[0]; post=g[g.H>0]
        dev=(post.v-b)/b
        exceeded=bool((dev.abs()>0.20).any())
        t_ret=np.nan
        if exceeded:
            tpk=post.loc[(post.v-b).abs().idxmax(),'H']
            after=post[(post.H>tpk)&((post.v-b).abs()/b<=0.20)]
            t_ret=float(after.H.iloc[0]) if len(after) else np.nan
        rows.append((sid,b,float(dev.max()*100),exceeded,t_ret))
    rt=pd.DataFrame(rows,columns=['USUBJID','base','maxdev_pct','exceeded','t_return'])
    ex=rt[rt.exceeded]
    R['return20'][k]=dict(n=int(len(rt)),n_exceed=int(rt.exceeded.sum()),pct_exceed=float(100*rt.exceeded.mean()),
        t_return_median=float(ex.t_return.median()) if len(ex) else None,t_return_min=float(ex.t_return.min()) if len(ex) else None,
        t_return_max=float(ex.t_return.max()) if len(ex) else None,n_not_returned=int(ex.t_return.isna().sum()),
        maxdev_median=float(rt.maxdev_pct.median()))
    rt.to_csv(f'return20_{k}.csv',index=False)
    print(f"{k} >20%: {R['return20'][k]['n_exceed']}/{R['return20'][k]['n']} ; return median {R['return20'][k]['t_return_median']} h (range {R['return20'][k]['t_return_min']}-{R['return20'][k]['t_return_max']}); not returned {R['return20'][k]['n_not_returned']}; median max dev {R['return20'][k]['maxdev_median']:.1f}%")
    # proportion outside 20% by time (for figure)
    prop=d.assign(out=lambda t:((t.v-t.base).abs()/t.base>0.20)).groupby('H').out.mean().reset_index()
    prop.to_csv(f'return20_prop_{k}.csv',index=False)

# ---------- hysteresis time-ordered means (arithmetic) ----------
hyst={}
concT=cyb.groupby('H').CONC.mean()
for k,m in M.items():
    g=m.groupby('H').dd.mean().reset_index().merge(concT.reset_index(),on='H').sort_values('H'); hyst[k]=g; g.to_csv(f'hyst_{k}.csv',index=False)

# ---------- hallucination ----------
hp=['Hallucination','Hallucination, auditory','Hallucination, tactile','Hallucination, visual','Somatic hallucination','Illusion','Visual processing disorder']
h=adae[adae.AEDECOD.isin(hp)].copy()
h['start']=pd.to_datetime(h['ASTDTM']); h['end']=pd.to_datetime(h['AEENDTC'],errors='coerce'); h['dose']=pd.to_datetime(h['AP02SDTM'])
h['onset']=(h['start']-h['dose']).dt.total_seconds()/3600; h['offset']=(h['end']-h['dose']).dt.total_seconds()/3600; h['dur']=(h['end']-h['start']).dt.total_seconds()/3600
h=h.dropna(subset=['onset','offset']); h.to_csv('halluc_events.csv',index=False)
dosed=sorted(set(adsl[adsl['AP02SDTM'].notna()].USUBJID))
subj=pd.DataFrame({'USUBJID':dosed}); subj['hall']=subj.USUBJID.isin(set(h.USUBJID)).astype(int); subj=subj.merge(expo,on='USUBJID',how='left')
ps=h.groupby('USUBJID').agg(first_on=('onset','min'),last_off=('offset','max'),longest=('dur','max'),nev=('dur','size')).reset_index()
ps['total']=ps.last_off-ps.first_on; ps=ps.merge(expo,on='USUBJID',how='left')
R['hall']={'inc_n':int(subj.hall.sum()),'inc_N':int(len(subj)),'episodes':int(len(h)),'subj_with':int(h.USUBJID.nunique()),
  'onset_med':float(h.onset.median()),'onset_iqr':[float(h.onset.quantile(.25)),float(h.onset.quantile(.75))],
  'dur_med':float(h.dur.median()),'dur_iqr':[float(h.dur.quantile(.25)),float(h.dur.quantile(.75))],
  'off_med':float(h.offset.median()),'off_iqr':[float(h.offset.quantile(.25)),float(h.offset.quantile(.75))],'off_max':float(h.offset.max()),
  'total_med':float(ps.total.median()),'total_iqr':[float(ps.total.quantile(.25)),float(ps.total.quantile(.75))],
  'longest_med':float(ps.longest.median()),'sev':h.AESEV.value_counts().to_dict()}
# incidence logistic
for xv in ['CMAX','AUC']:
    d=subj.dropna(subset=[xv])
    try:
        lr=sm.Logit(d.hall,sm.add_constant(d[xv])).fit(disp=0); R['hall'][f'inc_{xv}']=dict(or10=float(np.exp(10*lr.params[xv])) if xv=='CMAX' else float(np.exp(100*lr.params[xv])),p=float(lr.pvalues[xv]))
    except Exception as e: R['hall'][f'inc_{xv}']=dict(or10=None,p=None)
# non-hallucinating participants exposure
nh=subj[subj.hall==0]; yh=subj[subj.hall==1]
R['hall']['nonhall']=dict(ids=nh.USUBJID.tolist(),cmax=nh.CMAX.round(1).tolist(),auc=nh.AUC.round(0).tolist(),thalf=nh.THALF.round(1).tolist(),
   cmax_med_nh=float(nh.CMAX.median()),cmax_med_h=float(yh.CMAX.median()),auc_med_nh=float(nh.AUC.median()),auc_med_h=float(yh.AUC.median()),
   p_cmax=float(stats.mannwhitneyu(nh.CMAX.dropna(),yh.CMAX.dropna()).pvalue),p_auc=float(stats.mannwhitneyu(nh.AUC.dropna(),yh.AUC.dropna()).pvalue))
print("non-hallucinators:",R['hall']['nonhall'])
# time-matched probability (no 'active' wording) 
rows=[]; hby=h.groupby('USUBJID')
for _,r in cyb.iterrows():
    sid,H=r.USUBJID,r.H; on=0
    if sid in hby.groups:
        g=hby.get_group(sid); on=int(((g.onset<=H)&(g.offset>=H)).any())
    rows.append((sid,H,r.CONC,on))
tm=pd.DataFrame(rows,columns=['USUBJID','H','CONC','hall']); tm.to_csv('tm_hall.csv',index=False)
lr=sm.Logit(tm.hall,sm.add_constant(tm.CONC)).fit(disp=0); a,b=lr.params['const'],lr.params['CONC']
def ecx(p): return (np.log(p/(1-p))-a)/b
R['hall']['logit']=dict(a=float(a),b=float(b),or10=float(np.exp(10*b)),p=float(lr.pvalues['CONC']),n=int(len(tm)),
   p0=float(1/(1+np.exp(-a))),pgm=float(1/(1+np.exp(-(a+b*gm)))),EC50=float(ecx(.5)),EC20=float(ecx(.2)),EC10=float(ecx(.1)))
# cluster bootstrap CI for EC50/EC20
rng=np.random.default_rng(1); ids=tm.USUBJID.unique(); bs={'EC50':[],'EC20':[]}
for _ in range(400):
    samp=rng.choice(ids,len(ids),replace=True); dbs=pd.concat([tm[tm.USUBJID==s] for s in samp])
    try:
        l=sm.Logit(dbs.hall,sm.add_constant(dbs.CONC)).fit(disp=0); aa,bb=l.params['const'],l.params['CONC']
        bs['EC50'].append(-aa/bb); bs['EC20'].append((np.log(.25)-aa)/bb)
    except: pass
for kx in bs: R['hall']['logit'][kx+'_ci']=[float(np.percentile(bs[kx],5)),float(np.percentile(bs[kx],95))]
# time when mean / 90th pct conc falls below EC20 and EC50
cT=cyb.groupby('H').CONC.agg(['mean',lambda s:s.quantile(.9)]).reset_index(); cT.columns=['H','mean','p90']
def tbelow(col,thr):
    after=cT[(cT.H>=4)&(cT[col]<thr)]; return float(after.H.iloc[0]) if len(after) else None
R['hall']['t_below']={'EC20_mean':tbelow('mean',R['hall']['logit']['EC20']),'EC20_p90':tbelow('p90',R['hall']['logit']['EC20']),'EC50_mean':tbelow('mean',R['hall']['logit']['EC50']),'EC50_p90':tbelow('p90',R['hall']['logit']['EC50'])}
# empirical: proportion with hallucination by time; max conc among 'no hallucination' obs after 4h
prev=tm.groupby('H').hall.mean().reset_index().merge(concT.reset_index(),on='H').sort_values('H'); prev.to_csv('prev_hall.csv',index=False)
R['hall']['prev_peak']=float(prev.hall.max()); R['hall']['prev_peak_h']=float(prev.loc[prev.hall.idxmax(),'H'])
# duration vs exposure (Spearman) + t1/2 vs AUC correlation + partial
R['hall']['dur']={}
for yv in ['total','longest']:
    for xv in ['CMAX','AUC','THALF']:
        d=ps.dropna(subset=[xv,yv]); rho,p=stats.spearmanr(d[xv],d[yv]); R['hall']['dur'][f'{yv}_{xv}']=dict(rho=float(rho),p=float(p),n=int(len(d)))
d=ps.dropna(subset=['AUC','THALF','total','CMAX'])
R['hall']['thalf_auc_rho']=float(stats.spearmanr(d.THALF,d.AUC)[0]); R['hall']['thalf_cmax_rho']=float(stats.spearmanr(d.THALF,d.CMAX)[0])
def partial(y,x,z):
    rx=stats.rankdata(x); ry=stats.rankdata(y); rz=stats.rankdata(z)
    ex=rx-sm.OLS(rx,sm.add_constant(rz)).fit().fittedvalues; ey=ry-sm.OLS(ry,sm.add_constant(rz)).fit().fittedvalues
    return stats.pearsonr(ex,ey)
pr1=partial(d.total,d.THALF,d.AUC); pr2=partial(d.total,d.AUC,d.THALF)
R['hall']['partial']={'total_thalf_given_auc':[float(pr1[0]),float(pr1[1])],'total_auc_given_thalf':[float(pr2[0]),float(pr2[1])]}
print("logit:",{k:(round(v,3) if isinstance(v,float) else v) for k,v in R['hall']['logit'].items()})
print("t_below:",R['hall']['t_below']); print("dur:",R['hall']['dur']); print("thalf~AUC rho",R['hall']['thalf_auc_rho'],"partial",R['hall']['partial'])
# KM: time to first onset (all dosed; censor non-hallucinators at 48h) and time to final resolution (among hallucinators)
def km(times,events):
    df=pd.DataFrame({'t':times,'e':events}).sort_values('t'); n=len(df); S=1.0; out=[(0.0,1.0)]
    for t,g in df.groupby('t'):
        d_=g.e.sum(); 
        if d_>0: S*= (1-d_/n)
        out.append((float(t),float(S))); n-=len(g)
    return pd.DataFrame(out,columns=['t','S'])
on=subj.merge(ps[['USUBJID','first_on','last_off']],on='USUBJID',how='left')
on['t_on']=on.first_on.fillna(48.0); on['e_on']=on.hall
kmon=km(on.t_on,on.e_on); kmon.to_csv('km_onset.csv',index=False)
kmoff=km(ps.last_off,np.ones(len(ps))); kmoff.to_csv('km_resolution.csv',index=False)
def medS(k): s=k[k.S<=0.5]; return float(s.t.iloc[0]) if len(s) else None
R['hall']['km']={'median_onset':medS(kmon),'median_resolution':medS(kmoff),'n_on':int(len(on)),'n_off':int(len(ps))}
print("KM medians:",R['hall']['km'])
# subject 01-033: conc at 12h and 8h vs population
s33='CYB003-101-01-033'
for H in [8.0,12.0]:
    v=cyb[(cyb.USUBJID==s33)&(cyb.H==H)].CONC.values; popv=cyb[cyb.H==H].CONC
    R.setdefault('s033',{})[f'c{int(H)}']=dict(val=float(v[0]) if len(v) else None,pop_median=float(popv.median()),pctile=float(stats.percentileofscore(popv,v[0])) if len(v) else None)
e=adae[(adae.USUBJID==s33)]; R['s033']['euphoria_sev']=e[e.AEDECOD=='Euphoric mood'].AESEV.iloc[0] if (e.AEDECOD=='Euphoric mood').any() else None
R['s033']['halluc_sev']=e[e.AEDECOD=='Hallucination, visual'].AESEV.iloc[0]
print("s033:",R['s033'])
ps.to_csv('hall_persubj.csv',index=False); subj.to_csv('hall_subj.csv',index=False); expo.to_csv('expo.csv',index=False)
for k,m in M.items(): m.to_csv(f'dd_{k}.csv',index=False)
json.dump(R,open('results_rev.json','w'),indent=1,default=float); print("\nsaved results_rev.json")
