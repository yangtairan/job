import copy, json, re, difflib
from docx import Document
from docx.shared import Pt, Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from PIL import Image
R=json.load(open('results_rev.json'))
SRC='/mnt/user-data/uploads/CYB003-101_PKPD_Exploratory_ER_review.docx'
OUT='CYB003-101_PKPD_Exploratory_ER_review_v0.4.docx'
AUTHOR='Tairan Yang'; DATE='2026-10-06T09:00:00Z'
doc=Document(SRC); body=doc.element.body; W=qn
_id=[9000]
def nid(): _id[0]+=1; return str(_id[0])
# ---------------- 1. strip comment markup ----------------
for el in list(body.iter(W('w:commentRangeStart')))+list(body.iter(W('w:commentRangeEnd'))): el.getparent().remove(el)
for ref in list(body.iter(W('w:commentReference'))): r=ref.getparent(); r.getparent().remove(r)
for rId,rel in list(doc.part.rels.items()):
    if 'comments' in rel.reltype.lower(): doc.part.drop_rel(rId)

import sys; sys.path.insert(0,'.')
from accept_tc import accept_all
accept_all(body)
# ---------------- 1b. merge adjacent runs with identical formatting (comment anchors split runs) ----------------
from lxml import etree
def merge_runs(p):
    runs=[r for r in p if r.tag==W('w:r')]
    i=0
    while i < len(runs)-1:
        a,b=runs[i],runs[i+1]
        if a.getnext() is b and a.find(W('w:t')) is not None and b.find(W('w:t')) is not None:
            ra=a.find(W('w:rPr')); rb=b.find(W('w:rPr'))
            same=(etree.tostring(ra) if ra is not None else b'')==(etree.tostring(rb) if rb is not None else b'')
            extra=lambda r:[c for c in r if c.tag not in (W('w:rPr'),W('w:t'),W('w:lastRenderedPageBreak'))]
            if same and not extra(a) and not extra(b):
                ta=a.find(W('w:t')); tb=b.find(W('w:t')); ta.text=(ta.text or '')+(tb.text or ''); ta.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
                for c in list(a):
                    if c.tag==W('w:lastRenderedPageBreak'): a.remove(c)
                p.remove(b); runs.pop(i+1); continue
        i+=1
for p in body.iter(W('w:p')): merge_runs(p)
def join_infinity(p):
    runs=[r for r in p if r.tag==W('w:r')]
    for i in range(len(runs)-1):
        ta=runs[i].find(W('w:t')); tb=runs[i+1].find(W('w:t'))
        if ta is not None and tb is not None and (ta.text or '').endswith('AUC₀₋') and (tb.text or '').startswith('∞'):
            ta.text=ta.text+'∞'; tb.text=tb.text[1:]
            if not tb.text: p.remove(runs[i+1])
for p in body.iter(W('w:p')): join_infinity(p)
# ---------------- 2. untracked formatting pass: unicode subscripts -> real subscript runs ----------------
SUBMAP={'Cₘₐₓ':('C','max'),'Tₘₐₓ':('T','max'),'AUC₀₋∞':('AUC','0–∞')}
def fix_subscripts_in_par(p):
    for r in list(p.findall(W('w:r'))):
        t=r.find(W('w:t'))
        if t is None or not t.text: continue
        if not any(k in t.text for k in SUBMAP): continue
        parts=re.split(r'(Cₘₐₓ|Tₘₐₓ|AUC₀₋∞)',t.text); prev=r
        for part in parts:
            if not part: continue
            if part in SUBMAP:
                base,sub=SUBMAP[part]
                for txt,issub in [(base,False),(sub,True)]:
                    nr=copy.deepcopy(r); nt=nr.find(W('w:t')); nt.text=txt; nt.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
                    rpr=nr.find(W('w:rPr'))
                    if rpr is None: rpr=OxmlElement('w:rPr'); nr.insert(0,rpr)
                    for v in rpr.findall(W('w:vertAlign')): rpr.remove(v)
                    if issub: v=OxmlElement('w:vertAlign'); v.set(W('w:val'),'subscript'); rpr.append(v)
                    prev.addnext(nr); prev=nr
            else:
                nr=copy.deepcopy(r); nt=nr.find(W('w:t')); nt.text=part; nt.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
                rpr=nr.find(W('w:rPr'))
                if rpr is not None:
                    for v in rpr.findall(W('w:vertAlign')): rpr.remove(v)
                prev.addnext(nr); prev=nr
        r.getparent().remove(r)
for p in body.iter(W('w:p')): fix_subscripts_in_par(p)
for sec in doc.sections:
    for p in sec.header.paragraphs+sec.footer.paragraphs: fix_subscripts_in_par(p._p)
# ---------------- 3. tokenize existing figure/table references (untracked) ----------------
def tokenize_refs(p):
    for t in p.iter(W('w:t')):
        if t.text and re.search(r'\b(Figure|Table) \d+',t.text):
            t.text=re.sub(r'\b(Figure|Table) (\d+)',lambda m:f"⟦{m.group(1)[0]}{m.group(2)}⟧",t.text)
for p in body.iter(W('w:p')): tokenize_refs(p)
# ---------------- helpers: markup <-> runs, tracked diff ----------------
def run_markup(r):
    t=r.find(W('w:t')); 
    if t is None: return ''
    txt=t.text or ''; rpr=r.find(W('w:rPr'))
    bold=rpr is not None and rpr.find(W('w:b')) is not None and rpr.find(W('w:b')).get(W('w:val')) not in ('0','false')
    sub=rpr is not None and rpr.find(W('w:vertAlign')) is not None and rpr.find(W('w:vertAlign')).get(W('w:val'))=='subscript'
    if sub: return '_{'+txt+'}'
    if bold and txt.strip(): return '**'+txt+'**'
    return txt
def par_markup(p):
    s=''.join(run_markup(r) for r in p.findall(W('w:r')))
    s=s.replace('**_{','_{').replace('}**','}')  # tolerate bold-subscript combos
    s=re.sub(r'\*\*(\s*)\*\*',r'\1',s)
    return s
TOK=re.compile(r'\*\*.*?\*\*|_\{.*?\}|\s+|[^\s_*]+|[_*]')
def tokens(m): return TOK.findall(m)
def base_rpr(p):
    for r in p.findall(W('w:r')):
        rpr=r.find(W('w:rPr'))
        if rpr is not None:
            c=copy.deepcopy(rpr)
            for tag in ['w:b','w:vertAlign']:
                for e in c.findall(W(tag)): c.remove(e)
            return c
    return OxmlElement('w:rPr')
def mk_run(txt,rpr0,bold=False,sub=False,deleted=False):
    r=OxmlElement('w:r'); rpr=copy.deepcopy(rpr0)
    if bold: rpr.insert(0,OxmlElement('w:b'))
    if sub: v=OxmlElement('w:vertAlign'); v.set(W('w:val'),'subscript'); rpr.append(v)
    r.append(rpr); t=OxmlElement('w:delText' if deleted else 'w:t'); t.text=txt; t.set('{http://www.w3.org/XML/1998/namespace}space','preserve'); r.append(t); return r
def runs_from_tokens(toks,rpr0,deleted=False):
    out=[]
    for tok in toks:
        if tok.startswith('**') and tok.endswith('**') and len(tok)>4: out.append(mk_run(tok[2:-2],rpr0,bold=True,deleted=deleted))
        elif tok.startswith('_{') and tok.endswith('}'): out.append(mk_run(tok[2:-1],rpr0,sub=True,deleted=deleted))
        else: out.append(mk_run(tok,rpr0,deleted=deleted))
    return out
def wrap(tag,runs):
    e=OxmlElement(tag); e.set(W('w:id'),nid()); e.set(W('w:author'),AUTHOR); e.set(W('w:date'),DATE)
    for r in runs: e.append(r)
    return e
def tracked_set(p,new_markup):
    old=par_markup(p); rpr0=base_rpr(p)
    for r in list(p.findall(W('w:r'))): p.remove(r)
    for h in list(p.findall(W('w:hyperlink'))): p.remove(h)
    a,b=tokens(old),tokens(new_markup); sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
    for op,i1,i2,j1,j2 in sm.get_opcodes():
        if op=='equal':
            for r in runs_from_tokens(a[i1:i2],rpr0): p.append(r)
        if op in ('delete','replace'): p.append(wrap('w:del',runs_from_tokens(a[i1:i2],rpr0,deleted=True)))
        if op in ('insert','replace'): p.append(wrap('w:ins',runs_from_tokens(b[j1:j2],rpr0)))
def mark_par_inserted(p):
    ppr=p.find(W('w:pPr'))
    if ppr is None: ppr=OxmlElement('w:pPr'); p.insert(0,ppr)
    rpr=ppr.find(W('w:rPr'))
    if rpr is None: rpr=OxmlElement('w:rPr'); ppr.append(rpr)
    ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); rpr.append(ins)
def new_par_like(tpl_p,markup):
    p=copy.deepcopy(tpl_p)
    for ch in list(p):
        if ch.tag!=W('w:pPr'): p.remove(ch)
    ppr=p.find(W('w:pPr'))
    if ppr is not None:
        rpr=ppr.find(W('w:rPr'))
        if rpr is not None:
            for e in list(rpr):
                if e.tag in (W('w:ins'),W('w:del')): rpr.remove(e)
    p.append(wrap('w:ins',runs_from_tokens(tokens(markup),base_rpr(tpl_p)))); mark_par_inserted(p); return p
def tracked_delete_par(p):
    rpr0=base_rpr(p); old=par_markup(p)
    for r in list(p.findall(W('w:r'))): p.remove(r)
    p.append(wrap('w:del',runs_from_tokens(tokens(old),rpr0,deleted=True)))
    ppr=p.find(W('w:pPr')); rpr=ppr.find(W('w:rPr')) if ppr is not None else None
    if rpr is None: rpr=OxmlElement('w:rPr'); ppr.append(rpr)
    d=OxmlElement('w:del'); d.set(W('w:id'),nid()); d.set(W('w:author'),AUTHOR); d.set(W('w:date'),DATE); rpr.append(d)
# ---------------- locate paragraphs ----------------
def ptext(p_el): return ''.join(t.text or '' for t in p_el.iter(W('w:t')))
def PE(prefix):
    for p_el in body.iter(W('w:p')):
        if ptext(p_el).strip().startswith(prefix): return p_el
    raise KeyError(prefix)
class _PW:
    def __init__(self,el): self._p=el
def P(prefix): return _PW(PE(prefix))
def pic_par_after(p_el):
    e=p_el
    while e is not None:
        e=e.getnext()
        if e is not None and e.tag==W('w:p') and e.find('.//'+W('w:drawing')) is not None: return e
    return None
# templates
TPL_H2=PE('3.1 Source Data'); TPL_H3=PE('4.4.1 Within-Subject'); TPL_BODY=PE('Analyses were based on'); TPL_BUL=PE('To characterize the E-R relationship between CYB003 plasma concentration and reference-corrected change in supine systolic')
TPL_TCAP=PE('⟦T1⟧. Participant'); TPL_FCAP=PE('⟦F1⟧. ΔΔ SBP'); TPL_NOTE=PE('The smaller numbers')
# ---------------- figures: replace blobs, move captions above, insert new ----------------
def set_pic(p_el,png):
    blip=p_el.find('.//'+W('a:blip')); rId=blip.get(qn('r:embed')); part=doc.part.rels[rId].target_part
    data=open(png,'rb').read(); part._blob=data
    w,h=Image.open(png).size
    for ext in [p_el.find('.//'+W('wp:extent')),p_el.find('.//'+W('a:ext'))]:
        cx=int(ext.get('cx')); ext.set('cy',str(int(cx*h/w)))
def new_pic_par(png,width_in):
    p=doc.add_paragraph(); p.alignment=1; p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(2)
    p.add_run().add_picture(png,width=Inches(width_in)); el=p._p; body.remove(el); mark_par_inserted(el); return el
def set_width(p_el,width_in):
    w_emu=int(width_in*914400); blip=p_el.find('.//'+W('a:blip')); 
    ext=p_el.find('.//'+W('wp:extent')); cx,cy=int(ext.get('cx')),int(ext.get('cy')); 
    for e in [ext,p_el.find('.//'+W('a:ext'))]: e.set('cx',str(w_emu)); e.set('cy',str(int(w_emu*cy/cx)))
FIGS={'F1':('newfig/Fig01_BP_within.png',6.4),'F2':('newfig/Fig02_between_Cmax.png',6.5),'F3':('newfig/Fig04_between_within_SBP_DBP.png',6.2),'F4':('newfig/Fig06_HR_within.png',4.9),'F5':('newfig/Fig08_hall_timelines.png',5.8),'F6':('newfig/Fig09_hall_boxplots.png',6.6),'F7':('newfig/Fig11_hall_ER.png',6.2),'F8':('newfig/Fig12_subject033.png',5.9)}
PICS={}
for key,(png,wid) in FIGS.items():
    cap=PE(f'⟦{key}⟧.'); pic=pic_par_after(cap) if pic_par_after(cap) is not None else None
    # in original, picture precedes caption: search backwards
    e=cap.getprevious()
    while e is not None and not (e.tag==W('w:p') and e.find('.//'+W('w:drawing')) is not None): e=e.getprevious()
    pic=e; set_pic(pic,png); set_width(pic,wid); PICS[key]=pic
    pic.addprevious(cap)   # caption above graph (comment 21)
# ---------------- 4. TRACKED TEXT EDITS ----------------
GM=f"{R['cmax']['gm']:.1f}"; MX=f"{R['cmax']['max']:.1f}"; w=R['within']; b=R['between']; wb=R['wb']; r20=R['return20']; H=R['hall']; L=H['logit']; s33=R['s033']; dur=H['dur']; tb=H['t_below']; pc=H['partial']
f3=lambda x:f"{x:.3f}"; f1=lambda x:f"{x:.1f}"
# Title table / header
for row in doc.tables[0].rows:
    for c in row.cells:
        if 'Draft v0.3' in c.text: tracked_set(c.paragraphs[0]._p,'Draft v0.4 / 06 October 2026')
for p in doc.sections[0].header.paragraphs:
    for r in p.runs: r.text=r.text.replace('Draft v0.3, 09-Sep-2026','Draft v0.4, 06-Oct-2026')
# Objectives
tracked_set(PE('To characterize the E-R relationship between CYB003 plasma concentration and reference-corrected change in supine systolic'),'To characterize the E-R relationship between CYB003 plasma concentration and reference-corrected change in supine systolic (SBP) and diastolic (DBP) blood pressure, and to estimate the time at which blood pressure returned to within 20% of baseline.')
p15=PE('To characterize the E-R relationship between CYB003 plasma concentration and reference-corrected change in supine pulse')
tracked_set(p15,'To characterize the E-R relationship between CYB003 plasma concentration and reference-corrected change in supine pulse rate.')
p15.addnext(new_par_like(TPL_BUL,'To assess graphically whether the hemodynamic effects and the occurrence of hallucination lag the plasma concentration (hysteresis).'))
tracked_set(PE('To characterize the relationship between CYB003 exposure'),'To characterize the relationship between CYB003 exposure and the incidence, probability, timing, and duration of hallucination/perceptual AEs, including the concentrations associated with 20% and 50% probability of hallucination (EC20, EC50).')
tracked_set(PE('To evaluate and contrast'),'To evaluate and contrast between-subject (individual C_{max} and AUC_{0–∞}) and within-subject (time-matched concentration) exposure dependence.')
# 3.2
tracked_set(PE('Reference correction.'),'**Reference correction.** Hemodynamic responses were analyzed as the reference-corrected change, ΔΔ = (Day 8 change from baseline) − (Day 1 change from baseline) at the same nominal time, where baseline is the pre-dose measurement obtained on the morning of the dosing day in each period (Day 1 for Period 1 and Day 8 for Period 2), before administration of the probe cocktail and, on Day 8, before CYB003. This correction removes circadian variation and the intrinsic hemodynamic effects of the probe cocktail.')
tracked_set(PE('Concentrations.'),'**Concentrations.** Pre-dose (0 h) CYB003 concentrations were set to 0 ng/mL and retained as the zero-concentration reference. Post-dose concentrations below the lower limit of quantification (BLQ) were handled as in the CSR PK analysis: BLQ values before the first quantifiable concentration were set to zero, and BLQ values after the first quantifiable concentration were treated as missing; time-matched records with a missing concentration were excluded.')
tracked_set(PE('Adverse events.'),'**Adverse events.** Hallucination/perceptual events were identified by MedDRA preferred term (hallucination; hallucination, visual; hallucination, auditory; hallucination, tactile; somatic hallucination; illusion; visual processing disorder). Event onset and resolution date-times were expressed relative to the Day 8 CYB003 dosing date-time. Two duration measures were derived for each participant: the longest duration of any single episode, and the total hallucination duration, defined as the time from the onset of the first episode to the resolution of the last episode across all perceptual event types. The time to final resolution (time from dose to resolution of the last episode) was also derived.')
# 4.1 / 4.2
tracked_set(PE('Analyses were performed in R'),'Analyses were performed in R version 4.3.3 (nlme 3.1 for mixed-effects models; ggplot2 for graphics and linear estimation) and in Python 3.12 (statsmodels 0.14; matplotlib for the figures in this version). Fixed-effect estimates agreed to three decimal places between the two implementations.')
tracked_set(PE('Two exposure metrics were used.'),'Two exposure metrics were used. First, the **time-matched CYB003 plasma concentration** at each response timepoint was used for within-subject E-R analyses; this metric spans each participant’s full concentration range over the dosing interval (from 0 ng/mL through C_{max} to the elimination phase). Second, **individual summary exposure metrics** from non-compartmental analysis (C_{max}, AUC_{0–∞}, and terminal t½) were used for between-subject E-R analyses. Model predictions are reported at two reference exposures: the geometric mean C_{max} ('+GM+' ng/mL), which represents the typical peak concentration after a 16 mg dose, and the maximum observed C_{max} ('+MX+' ng/mL), which represents the upper bound of exposure observed in this study. Predictions at the geometric mean C_{max} describe the expected effect in a typical participant, and predictions at the maximum C_{max} describe the effect at the highest exposure encountered.')
# 4.3
tracked_set(PE('Hemodynamic endpoints:'),'**Hemodynamic endpoints:** supine SBP, DBP, and pulse rate (ADVS), analyzed as ΔΔ (Section 3.2); and, for SBP and DBP, the time at which the Day 8 value returned to within 20% of the Day 8 baseline (Section 4.4.6).')
tracked_set(PE('Hallucination endpoints:'),'**Hallucination endpoints:** (a) incidence of any hallucination/perceptual AE; (b) hallucination status (present or absent) at each PK sampling time, defined as present when the nominal time fell within an episode’s onset-resolution interval; (c) time to first hallucination onset and time to final resolution; and (d) duration, expressed as the longest single episode and as the total hallucination duration (Section 3.2).')
# 4.4.1 centering
# 4.4.1 centering already 'arithmetic' in accepted text (author edit); no change
# 4.4.2
tracked_set(PE('Participant-level summary responses'),'For each participant, the maximum ΔΔ (the largest reference-corrected increase observed at any post-dose timepoint) was regressed on individual C_{max} and, separately, on individual AUC_{0–∞} by ordinary least squares (OLS); Pearson correlation coefficients (r) and p-values are presented. The participant mean ΔΔ was also examined as an alternative summary and gave similar results (not shown).')
# 4.4.3
tracked_set(PE('4.4.3 Separate Estimation'),'4.4.3 Separate Estimation of Between-Subject and Within-Subject Slopes')
tracked_set(PE('To estimate the within-subject and between-subject slopes'),'The between-subject slope was estimated by OLS regression of each participant’s mean ΔΔ on that participant’s mean time-matched concentration (one point per participant). The within-subject slope was estimated from the mixed-effects model of Section 4.4.1 with the participant’s mean concentration included as an additional covariate, so that the concentration term reflects only changes in concentration within a participant over time. In addition, a separate linear regression of ΔΔ on concentration was fitted for each participant with at least four matched observations, and the number of participants whose fitted slope was positive was counted.')
# 4.4.4
tracked_set(PE('A possible delay between concentration'),'A possible delay between concentration and effect (hysteresis) was assessed graphically for SBP, DBP, pulse rate, and the proportion of participants with hallucination, by plotting the arithmetic mean effect against the arithmetic mean concentration at each nominal timepoint and connecting the points in time order. A wide counter-clockwise loop indicates that the effect lags the concentration, whereas a narrow loop with the peak effect occurring near the peak concentration indicates no appreciable delay. This assessment was exploratory and descriptive; no delayed-effect (effect-compartment) model was fitted, and such modeling would be considered only if the graphical assessment indicated a meaningful delay.')
# 4.4.5
p54=PE('Incidence was analyzed by logistic regression')
tracked_set(p54,'Incidence was analyzed by logistic regression on individual C_{max} and AUC_{0–∞}. The probability of hallucination at each PK sampling time was analyzed by logistic regression on the time-matched concentration (pooled across participants; odds ratio per 10 ng/mL presented), and the model-predicted probability was evaluated at 0 ng/mL and at the geometric mean C_{max}. From this model the concentrations associated with 20% and 50% probability of hallucination (EC20 and EC50) were derived, with 90% CIs obtained by cluster bootstrap (400 resamples of participants); the times at which the arithmetic mean and 90th percentile concentration fell below EC20 and EC50 were read from the concentration-time data. Time to first hallucination onset (all CYB003-dosed participants; participants without hallucination censored at 48 h) and time to final resolution (participants with hallucination) were summarized by the Kaplan-Meier method. The relationship between exposure and duration was evaluated by Spearman rank correlation and OLS regression of the longest episode duration, the total hallucination duration, and the time to final resolution on C_{max}, AUC_{0–∞}, and terminal t½; because t½ and AUC_{0–∞} are themselves correlated, Spearman partial correlations of duration with t½ adjusted for AUC_{0–∞}, and with AUC_{0–∞} adjusted for t½, were also computed. Episode onset, duration, and resolution were summarized descriptively (median and IQR) overall and by preferred term and severity.')
h446=new_par_like(TPL_H3,'4.4.6 Return of Blood Pressure to Within 20% of Baseline'); p54.addnext(h446)
h446.addnext(new_par_like(TPL_BODY,'For each participant, Day 8 SBP and DBP at each post-dose timepoint were compared with the Day 8 pre-dose baseline. A participant was classified as exceeding the criterion if any post-dose value was more than 20% above baseline. For these participants, the time of return was defined as the first scheduled timepoint after the maximum increase at which the value was no more than 20% above baseline. The proportion of participants more than 20% above baseline was summarized by timepoint. Decreases of more than 20% below baseline were tabulated separately.'))
# 4.5
p56=PE('Model adequacy'); tracked_set(p56,par_markup(p56).replace('and by  the estimates in a second software implementation (Section 4.1).','and by reproducing the estimates in both R and Python.').replace('and by the estimates in a second software implementation (Section 4.1).','and by reproducing the estimates in both R and Python.'))
# ---------------- 5.1.1 ----------------
p60=PE('Reference-corrected SBP and DBP increased')
tracked_set(p60,par_markup(p60)+f' The largest observed mean ΔΔ occurred at 2 h post-dose (SBP {w["SBP"]["obs_max_mean"]:.1f} mmHg; DBP {w["DBP"]["obs_max_mean"]:.1f} mmHg), close to the median T_{{max}} of CYB003. Model predictions are given at both reference exposures defined in Section 4.2.')
p65=PE('N = 222 observations from 34 participants. REML'); tracked_set(p65,f'N = 222 observations from 34 participants. REML estimation; participant-specific random intercept; concentration centered at the arithmetic mean. CIs by the delta method. Geometric mean C_{{max}} = {GM} ng/mL (typical peak concentration after 16 mg); maximum observed C_{{max}} = {MX} ng/mL (upper bound of observed exposure).')
tracked_set(PE('⟦F1⟧.'),'⟦F1⟧. ΔΔ SBP (A) and ΔΔ DBP (B) versus Time-Matched CYB003 Concentration')
# ---------------- 5.1.2 ----------------
bS,bD,bH=b['SBP'],b['DBP'],b['HR']
tracked_set(PE('No statistically significant relationship was identified between individual'),f'The maximum ΔΔ for each participant was regressed on individual C_{{max}} (⟦F2⟧) and on individual AUC_{{0–∞}} (⟦Fauc⟧); results for SBP, DBP, and pulse rate are summarized in ⟦T5⟧. No statistically significant relationship with C_{{max}} was identified for any endpoint, and point estimates were of opposite sign for SBP and DBP. Against AUC_{{0–∞}}, the maximum ΔΔ DBP showed a positive correlation (r = {bD["max_AUC"]["r"]:.2f}, p = {bD["max_AUC"]["p"]:.2f}), whereas SBP and pulse rate did not. The participant mean ΔΔ gave similar results for all endpoints (not shown).')
tracked_set(PE('⟦T5⟧.'),'⟦T5⟧. Between-Subject Regression of Maximum ΔΔ on Individual C_{max} and AUC_{0–∞}')
tracked_set(PE('⟦F2⟧.'),'⟦F2⟧. Maximum ΔΔ SBP (A), DBP (B), and Pulse Rate (C) versus Individual CYB003 C_{max}')
capAUC=new_par_like(TPL_FCAP,'⟦Fauc⟧. Maximum ΔΔ SBP (A), DBP (B), and Pulse Rate (C) versus Individual CYB003 AUC_{0–∞}'); PICS['F2'].addnext(capAUC); capAUC.addnext(new_pic_par('newfig/Fig03_between_AUC.png',6.5))
# ---------------- 5.1.3 ----------------
tracked_set(PE('5.1.3 Within-Subject and Between-Subject'),'5.1.3 Between-Subject and Within-Subject Slopes')
tracked_set(PE('When the within-subject and between-subject slopes'),f'When the between-subject and within-subject slopes were estimated separately (⟦T6⟧, ⟦F3⟧), the within-subject slopes were precisely estimated and clearly positive. The between-subject slopes, based on one point per participant, were similar in magnitude but considerably less precise, with confidence intervals approximately five- to six-fold wider; the SBP interval included zero and the DBP interval did not. Of the 33 participants with an estimable individual slope, {wb["SBP"]["npos"]} (SBP) and {wb["DBP"]["npos"]} (DBP) had a positive slope (⟦F3⟧).')
tracked_set(PE('⟦T6⟧.'),'⟦T6⟧. Between-Subject and Within-Subject Slope Estimates for ΔΔ Blood Pressure versus CYB003 Concentration')
tracked_set(PE('⟦F3⟧.'),'⟦F3⟧. Between-Subject (A, C) and Within-Subject (B, D) Concentration-ΔΔ Relationships for SBP (A, B) and DBP (C, D)')
pnote3=PE('A: grey lines are individual'); tracked_set(pnote3,'A, C: one point per participant (mean ΔΔ versus mean concentration) with OLS fit and 90% CI. B, D: grey lines are individual participant OLS fits (5-8 observations each); green line is the pooled within-subject slope.')
# ---- new 5.1.4 after Fig 3 note ----
rS,rD=r20['SBP'],r20['DBP']
h514=new_par_like(TPL_H3,'5.1.4 Return of Blood Pressure to Within 20% of Baseline'); pnote3.addnext(h514)
t514=new_par_like(TPL_BODY,f'An increase of more than 20% above the Day 8 baseline was observed at least once in {rS["n_exceed"]} of {rS["n"]} participants ({rS["pct_exceed"]:.0f}%) for SBP and in {rD["n_exceed"]} of {rD["n"]} ({rD["pct_exceed"]:.0f}%) for DBP, with the maximum increase most often at 2 h post-dose (⟦Tret⟧, ⟦Fret⟧). All of these participants had returned to within 20% of baseline by {rS["all_within_by"]:.0f} h (SBP) and {rD["all_within_by"]:.0f} h (DBP); the median time of return was {rS["t_return_median"]:.0f} h for both endpoints (range {rS["t_return_min"]:.0f}–{rS["t_return_max"]:.0f} h for SBP and {rD["t_return_min"]:.0f}–{rD["t_return_max"]:.0f} h for DBP). No participant was more than 20% above baseline at 8 h or later. Separately, values more than 20% below baseline were observed at 12 or 24 h in {rS["late_below_n"]} participants (SBP) and {rD["late_below_n"]} participants (DBP), consistent with the late decline below baseline seen in the mean profiles.'); h514.addnext(t514)
c514=new_par_like(TPL_TCAP,'⟦Tret⟧. Return of Blood Pressure to Within 20% of the Day 8 Baseline'); t514.addnext(c514)
# new table cloned from Table 3 (3 columns)
def clone_table(tpl_idx,headers,rows):
    tpl=doc.tables[tpl_idx]._tbl; t=copy.deepcopy(tpl); trs=t.findall(W('w:tr')); hdr=trs[0]; bodyrow=trs[1]
    for tr in trs[1:]: t.remove(tr)
    def fill(tr,vals):
        for tc,v in zip(tr.findall(W('w:tc')),vals):
            p=tc.find(W('w:p')); rpr0=base_rpr(p)
            for r in list(p.findall(W('w:r'))): p.remove(r)
            p.append(wrap('w:ins',runs_from_tokens(tokens(v),rpr0)))
        trPr=tr.find(W('w:trPr'))
        if trPr is None: trPr=OxmlElement('w:trPr'); tr.insert(0,trPr)
        ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); trPr.append(ins)
    fill(hdr,headers)
    for vals in rows:
        tr=copy.deepcopy(bodyrow); fill(tr,vals); t.append(tr)
    return t
tret=clone_table(6,['Parameter','SBP','DBP'],[
 ['Participants > 20% above baseline at any post-dose time, n/N (%)',f'{rS["n_exceed"]}/{rS["n"]} ({rS["pct_exceed"]:.0f}%)',f'{rD["n_exceed"]}/{rD["n"]} ({rD["pct_exceed"]:.0f}%)'],
 ['Time of maximum increase, median (h)',f'{rS["t_peak_median"]:.0f}',f'{rD["t_peak_median"]:.0f}'],
 ['Time of return to ≤ 20% above baseline, median (range) (h)',f'{rS["t_return_median"]:.0f} ({rS["t_return_min"]:.0f}–{rS["t_return_max"]:.0f})',f'{rD["t_return_median"]:.0f} ({rD["t_return_min"]:.0f}–{rD["t_return_max"]:.0f})'],
 ['Time by which all participants were ≤ 20% above baseline (h)',f'{rS["all_within_by"]:.0f}',f'{rD["all_within_by"]:.0f}'],
 ['Participants > 20% above baseline at 2 h, %',f'{rS["prop_by_time"]["2.0"]:.0f}',f'{rD["prop_by_time"]["2.0"]:.0f}'],
 ['Participants > 20% below baseline at 12 or 24 h, n',f'{rS["late_below_n"]}',f'{rD["late_below_n"]}']])
c514.addnext(tret)
cfret=new_par_like(TPL_FCAP,'⟦Fret⟧. Proportion of Participants More Than 20% Above the Day 8 Baseline by Timepoint'); tret.addnext(cfret); cfret.addnext(new_pic_par('newfig/Fig07_BP_return20.png',5.2))
# ---------------- 5.2 HR ----------------
hr=w['HR']
tracked_set(PE('Reference-corrected pulse rate increased'),f'Reference-corrected pulse rate increased with CYB003 concentration (⟦T7⟧, ⟦F4⟧). Because the Day 1 reference correction accounts for the heart-rate-lowering effect of the probe cocktail (metoprolol), the ΔΔ slope exceeded the baseline-corrected slope. The largest observed mean ΔΔ ({hr["obs_max_mean"]:.1f} bpm) occurred at {hr["obs_max_mean_h"]:.0f} h. The between-subject relationships of maximum ΔΔ pulse rate with individual C_{{max}} and AUC_{{0–∞}} were not statistically significant (⟦T5⟧; ⟦F2⟧C and ⟦Fauc⟧C). Hysteresis is assessed for all endpoints in Section 5.3.')
tracked_set(PE('N = 222 observations from 34 participants (within-subject)'),'N = 222 observations from 34 participants. Geometric mean and maximum C_{max} as defined in Section 4.2.')
tracked_set(PE('⟦F4⟧.'),'⟦F4⟧. ΔΔ Pulse Rate versus Time-Matched CYB003 Concentration')
# ---- new 5.3 Hysteresis before '5.3 Hallucination' heading ----
h53=PE('5.3 Hallucination')
hh=new_par_like(TPL_H2,'5.3 Assessment of Hysteresis'); h53.addprevious(hh)
th=new_par_like(TPL_BODY,'Time-ordered plots of mean effect versus mean concentration are shown for SBP, DBP, pulse rate, and the proportion of participants with hallucination in ⟦Fhys⟧. For all three hemodynamic endpoints the loop was narrow and the maximum mean effect occurred at or near the time of maximum mean concentration (2–4 h), indicating no appreciable delay between concentration and effect. For hallucination, the proportion of participants with hallucination rose with concentration during absorption and declined with concentration during elimination; at a given concentration the proportion was somewhat lower during the elimination phase than during absorption (a modest clockwise loop), so that hallucination did not outlast the decline in concentration. Delayed-effect modeling was therefore not pursued for any endpoint.'); hh.addnext(th)
ch=new_par_like(TPL_FCAP,'⟦Fhys⟧. Time-Ordered Mean Effect versus Mean CYB003 Concentration: ΔΔ SBP (A), ΔΔ DBP (B), ΔΔ Pulse Rate (C), and Proportion of Participants with Hallucination (D)'); th.addnext(ch)
ph=new_pic_par('newfig/Fig05_hysteresis_all.png',6.6); ch.addnext(ph); ph.addnext(new_par_like(TPL_NOTE,'Points are arithmetic means at each nominal timepoint (labeled in hours), connected in time order.'))
tracked_set(h53,'5.4 Hallucination'); tracked_set(PE('5.3.1 Incidence'),'5.4.1 Incidence, Timing, and Severity'); tracked_set(PE('5.3.2 Exposure'),'5.4.2 Exposure-Response')
# ---------------- 5.4.1 ----------------
nh=H['nonhall']
p88=PE('Hallucination/perceptual AEs were reported by')
tracked_set(p88,f'Hallucination/perceptual AEs were reported by 30 of 34 participants dosed with CYB003 (88%), comprising 47 episodes; the most frequent preferred term was ‘Hallucination, visual’ (24 episodes in 24 participants). Onset was early and episodes were transient and self-limiting (⟦T8⟧, ⟦F5⟧, ⟦F6⟧). By Kaplan-Meier estimation, the median time to first onset was {H["km"]["median_onset"]:.1f} h and the median time to final resolution was {H["km"]["median_resolution"]:.1f} h after dosing (⟦Fkm⟧). All events were mild or moderate in severity ({H["sev"].get("MILD",0)} mild, {H["sev"].get("MODERATE",0)} moderate) and resolved without intervention; duration did not differ meaningfully by severity.')
p88.addnext(new_par_like(TPL_BODY,f'The four participants without a hallucination/perceptual AE had C_{{max}} values of {", ".join(f"{x:.1f}" for x in sorted(nh["cmax"]))} ng/mL (median {nh["cmax_med_nh"]:.1f} ng/mL, compared with {nh["cmax_med_h"]:.1f} ng/mL in participants with an event; p = {nh["p_cmax"]:.2f}) and AUC_{{0–∞}} median {nh["auc_med_nh"]:.0f} h·ng/mL (compared with {nh["auc_med_h"]:.0f} h·ng/mL; p = {nh["p_auc"]:.2f}). Three of the four had C_{{max}} values among the lowest observed, but the fourth had above-average exposure; exposure alone therefore does not account for the absence of hallucination in these participants.'))
tracked_set(PE('⟦F5⟧.'),'⟦F5⟧. Hallucination/Perceptual Episodes Relative to Time of CYB003 Dose: Episode Timelines by Participant (A) and Distribution of Single-Episode Duration (B)')
tracked_set(PE('⟦F6⟧.'),'⟦F6⟧. Hallucination Onset, Duration, and Resolution (A), Single-Episode Duration by Preferred Term (B), and by Severity (C)')
n6=new_par_like(TPL_NOTE,'Boxes show median and interquartile range; all individual episodes are plotted. In C, the four moderate events are shown in red.'); PICS['F6'].addnext(n6)
ckm=new_par_like(TPL_FCAP,'⟦Fkm⟧. Kaplan-Meier Estimates of Time to First Hallucination Onset (A) and Time to Final Resolution (B)'); n6.addnext(ckm); pkm=new_pic_par('newfig/Fig10_hall_KM.png',6.2); ckm.addnext(pkm); pkm.addnext(new_par_like(TPL_NOTE,'A: all 34 CYB003-dosed participants; the 4 participants without hallucination are censored at 48 h. B: the 30 participants with hallucination.'))
# ---------------- 5.4.2 ----------------
p95=PE('Incidence was not significantly related')
tracked_set(p95,f'Because hallucination occurred in nearly all participants at the 16 mg dose, there was little scope for incidence to vary with exposure, and no significant relationship between incidence and individual C_{{max}} or AUC_{{0–∞}} was identified (⟦T9⟧). The time-matched analysis addresses a different question: whether a participant is more likely to be hallucinating at times when their concentration is higher. This relationship was strong (⟦F7⟧B): the model-predicted probability of hallucination was {L["p0"]:.2f} at 0 ng/mL and {L["pgm"]:.2f} at the geometric mean C_{{max}}, with EC20 = {L["EC20"]:.1f} ng/mL (90% CI {L["EC20_ci"][0]:.1f}, {L["EC20_ci"][1]:.1f}) and EC50 = {L["EC50"]:.1f} ng/mL (90% CI {L["EC50_ci"][0]:.1f}, {L["EC50_ci"][1]:.1f}). The proportion of participants with hallucination over time followed the mean concentration-time profile (⟦F7⟧A), peaking at {100*H["prev_peak"]:.0f}% at {H["prev_peak_h"]:.0f} h and returning to 0% by 12 h. The arithmetic mean concentration fell below EC50 by {tb["EC50_mean"]:.0f} h and below EC20 by {tb["EC20_mean"]:.0f} h post-dose, and the 90th percentile concentration fell below EC20 by {tb["EC20_p90"]:.0f} h. Concentrations below approximately 7 ng/mL (EC20) were therefore associated with a low probability of hallucination, and essentially all participants were below this level by 12–16 h after dosing, consistent with the observed absence of hallucination after 12 h.')
p95.addnext(new_par_like(TPL_BODY,f'Duration of the perceptual experience was related to the rate of elimination rather than to peak or total exposure. Time to final resolution correlated with terminal t½ (Spearman ρ = 0.40, p = 0.031), and the total hallucination duration and the longest single episode showed similar trends (ρ = {dur["total_THALF"]["rho"]:.2f}, p = {dur["total_THALF"]["p"]:.3f}; ρ = {dur["longest_THALF"]["rho"]:.2f}, p = {dur["longest_THALF"]["p"]:.3f}), whereas none of the duration measures correlated with C_{{max}} or AUC_{{0–∞}} (⟦F7⟧C, D). Terminal t½ and AUC_{{0–∞}} were themselves correlated (ρ = {H["thalf_auc_rho"]:.2f}). After adjustment for AUC_{{0–∞}}, the partial correlation of total duration with t½ was {pc["total_thalf_given_auc"][0]:.2f} (p = {pc["total_thalf_given_auc"][1]:.2f}), whereas after adjustment for t½ the partial correlation with AUC_{{0–∞}} was {pc["total_auc_given_thalf"][0]:.2f} (p = {pc["total_auc_given_thalf"][1]:.2f}), indicating that the association with duration is carried by the elimination half-life rather than by total exposure.'))
tracked_set(PE('⟦F7⟧.'),'⟦F7⟧. Proportion of Participants with Hallucination versus Time with Mean Concentration (A), Probability of Hallucination versus Concentration with EC20 and EC50 (B), and Total Hallucination Duration versus Terminal t½ (C) and AUC_{0–∞} (D)')
# ---------------- 5.5 individual ----------------
tracked_set(PE('5.4 Case History'),'5.5 Case History for Participant with Longest Visual Hallucination')
tracked_set(PE('Participant 01-033 (55-year-old male'),f'Participant 01-033 (55-year-old male, 63.1 kg) experienced the longest visual hallucination in the study (10.7 h; mild; resolved without intervention) together with a concurrent mild euphoric mood (approximately 1.9–3.9 h post-dose). The participant’s C_{{max}} (26.8 ng/mL) was close to the population geometric mean, whereas T_{{max}} (4.0 h) was later than the population median (approximately 2.9 h) and terminal t½ (5.9 h) was longer than the population mean (approximately 4.5 h), consistent with more sustained exposure. His concentrations during the later part of the episode were not higher than those of other participants: {s33["c8"]["val"]:.1f} ng/mL at 8 h and {s33["c12"]["val"]:.1f} ng/mL at 12 h, compared with population medians of {s33["c8"]["pop_median"]:.1f} and {s33["c12"]["pop_median"]:.1f} ng/mL, respectively. The prolonged effect in this participant is therefore not explained by higher late exposure; hallucination persisted at concentrations (around 5–6 ng/mL at 12 h) at which most participants no longer reported hallucination, suggesting greater individual sensitivity or a slower offset of effect. Concurrent hemodynamic changes (SBP +28 mmHg and DBP +11 mmHg near T_{{max}}, returning to baseline by 24 h) followed the exposure profile; on Day 1 (probe cocktail alone), blood pressure was essentially unchanged (⟦F8⟧).')
# ---------------- 6 Discussion ----------------
tracked_set(PE('Following a single 16 mg dose, CYB003 produced'),'Following a single 16 mg dose, CYB003 produced concentration-dependent PD effects comprising a pressor response (SBP and DBP), an increase in pulse rate, and a perceptual (hallucinogenic) effect, each consistent with the plasma concentration-time course. The blood pressure effect was transient: among participants whose SBP or DBP rose more than 20% above baseline (41% for each), the median time of return to within 20% of baseline was 4 h, and no participant exceeded this criterion at 8 h or later. Hallucination had a median single-episode duration of 4.8 h and a Kaplan-Meier median time to final resolution of 6.5 h.')
p105=PE('A noteworth feature across the hemodynamic'); tracked_set(p105,'A noteworthy feature across the hemodynamic endpoints was the difference in precision between the within-subject and between-subject E-R estimates: the within-subject concentration-response was precisely estimated and clearly positive (31 of 33 individual SBP slopes positive), whereas the between-subject estimates (maximum ΔΔ against C_{max} or AUC_{0–∞}, or participant means against mean concentration) were imprecise: confidence intervals were several-fold wider, most included zero, and only the maximum ΔΔ DBP against AUC_{0–∞} reached statistical significance. Three factors account for this difference.')
tracked_set(PE('First, the two analyses differ'),'First, the two analyses differ in the exposure range available to detect a slope. Within a participant, concentration range covers the complete profile from 0 ng/mL through C_{max}, providing a wide span over which the response can be related to concentration. Between participants, exposure varies only to the extent that individual C_{max} or AUC_{0–∞} values differ, which at a single 16 mg dose spanned approximately 2.6-fold for C_{max}; this smaller spread provides limited ability to detect a between-subject slope.')
tracked_set(PE('Second, the two analyses are subject'),'Second, the two analyses are subject to different sources of variability. In the within-subject analysis each participant serves as their own control, so that stable inter-individual differences (in baseline blood pressure, body size, autonomic tone, and response to the study procedures) do not add to the residual variance. The between-subject analysis compares participants with one another, resulting in inter-individual differences becoming the dominant source of variability, obscuring any modest exposure-related component. This is reflected in the several-fold wider confidence intervals for the between-subject slopes relative to the within-subject slopes.')
p108=PE('Third, the two analyses use'); tracked_set(p108,par_markup(p108).replace('use of individual AUC_{0–∞} in place of C_{max} gave similar results.','individual AUC_{0–∞} gave similar results for SBP and pulse rate.'))
p109=PE('Consequently, the absence'); tracked_set(p109,'Consequently, the absence of a clear between-subject relationship does not constitute evidence against a drug effect. The within-subject concentration-response, which uses the full exposure profile and is unaffected by inter-individual differences, is the appropriate basis for E-R characterization and for projection across doses.')
pcol=new_par_like(TPL_BODY,'A related point concerns the interpretation of the concentration-time relationship within a single-dose study. Because all participants received the same dose at the same clock time, plasma concentration rose and fell on a fixed schedule, and any other quantity that also changes with time of day (for example, the circadian blood pressure rhythm, posture, meals, or study procedures) would appear to be related to concentration. The Day 1 reference correction removes those components that were the same on both study days, but it cannot remove anything that occurred only on Day 8 and coincided with the rise and fall of concentration. This residual possibility is a limitation of the design rather than of the analysis.'); p109.addnext(pcol)
# move Day-1 paragraph above hallucination paragraph (delete old, insert new)
p111=PE('The Day 1 (probe cocktail alone) period served'); p110=PE('The hallucination analyses indicated')
tracked_delete_par(p111)
pday=new_par_like(TPL_BODY,'The Day 1 (probe cocktail alone) period served as a within-subject, time-matched reference for the hemodynamic endpoints, removing circadian variation and the intrinsic effects of the cocktail, notably metoprolol. The positive concentration-response slopes persisted after this correction and were steeper for SBP and pulse rate, supporting a drug-related rather than procedural origin. No appreciable hysteresis was observed for any endpoint on the time-ordered plots.'); p110.addprevious(pday)
tracked_set(p110,'The hallucination analyses indicated that the determinants of effect intensity and effect duration differ. The probability of hallucination at a given time was strongly concentration-dependent, with EC20 and EC50 of approximately 7 and 15 ng/mL, whereas the duration of the experience was associated with terminal t½ rather than with peak or total exposure. Although t½ and AUC_{0–∞} are correlated (slower elimination increases AUC_{0–∞} for a given C_{max}), the partial correlations show that the association with duration is carried by t½ and not by AUC_{0–∞}: for a given total exposure, participants who eliminated CYB003 more slowly had longer perceptual effects. These findings suggest that the concentration attained primarily determines the magnitude and likelihood of the effect, whereas the rate of elimination determines its duration. The EC20 provides a practical reference: once concentrations fall below approximately 7 ng/mL, which occurred in essentially all participants by 12–16 h after dosing, the probability of hallucination is low, consistent with the observed absence of hallucination after 12 h.')
p112=PE('Limitations.'); tracked_set(p112,par_markup(p112).replace('Within a single-dose profile, concentration and time are partially collinear; the reference correction mitigates but does not eliminate this.','Within a single-dose profile, concentration and time are partially collinear (see above); the reference correction mitigates but does not eliminate this.').replace('without a random effect given the exploratory scope.','without a random effect given the exploratory scope, and the EC20/EC50 estimates should be regarded as approximate.'))
# ---------------- 7 Conclusions ----------------
tracked_set(PE('A single 16 mg oral dose of CYB003 produced transient'),f'A single 16 mg oral dose of CYB003 produced transient, concentration-dependent increases in supine blood pressure (model-predicted ΔΔ SBP +{w["SBP"]["pred_gm"][0]:.1f} mmHg and ΔΔ DBP +{w["DBP"]["pred_gm"][0]:.1f} mmHg at the geometric mean C_{{max}}) and pulse rate (+{hr["pred_gm"][0]:.1f} bpm), which resolved with drug elimination. Blood pressure increases of more than 20% above baseline occurred in 41% of participants and returned to within 20% of baseline with a median time of 4 h; all participants were within 20% of baseline by 8 h.')
tracked_set(PE('Hallucination/perceptual AEs occurred in 88%'),f'Hallucination/perceptual AEs occurred in 88% of participants, with a median single-episode duration of {H["dur_med"]:.1f} h and a Kaplan-Meier median time to final resolution of {H["km"]["median_resolution"]:.1f} h. The probability of hallucination increased steeply with concentration (EC20 approximately {L["EC20"]:.0f} ng/mL, EC50 approximately {L["EC50"]:.0f} ng/mL), and the duration of the experience was associated with terminal t½ rather than with peak or total exposure.')
tracked_set(PE('E-R relationships were evident'),'E-R relationships were precisely characterized within-subject; between-subject estimates over the narrow single-dose exposure range were imprecise. The within-subject concentration-response is the appropriate basis for characterization and dose projection.')
# ---------------- 5. TABLE CELL EDITS ----------------
def tbl_by_caption(tok):
    cap=PE(f'⟦{tok}⟧.'); e=cap
    while e is not None:
        e=e.getnext()
        if e is not None and e.tag==W('w:tbl'): return e
def cell_set(tr,j,markup):
    tc=tr.findall(W('w:tc'))[j]; tracked_set(tc.find(W('w:p')),markup)
def rows(t): return t.findall(W('w:tr'))
def rowtext(tr): return ' | '.join(''.join(x.text or '' for x in tc.iter(W('w:t'))) for tc in tr.findall(W('w:tc')))
def add_row_after(t,tr_ref,vals):
    tr=copy.deepcopy(tr_ref)
    for tc,v in zip(tr.findall(W('w:tc')),vals):
        p=tc.find(W('w:p')); rpr0=base_rpr(p)
        for r in list(p.findall(W('w:r'))): p.remove(r)
        for d in list(p.findall(W('w:del')))+list(p.findall(W('w:ins'))): p.remove(d)
        p.append(wrap('w:ins',runs_from_tokens(tokens(v),rpr0)))
    trPr=tr.find(W('w:trPr'))
    if trPr is None: trPr=OxmlElement('w:trPr'); tr.insert(0,trPr)
    for e in trPr.findall(W('w:ins')): trPr.remove(e)
    ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); trPr.append(ins)
    tr_ref.addnext(tr); return tr
def find_row(t,contains):
    for tr in rows(t):
        if contains in rowtext(tr): return tr
    raise KeyError(contains)
# Table 2
t2=tbl_by_caption('T2')
cell_set(find_row(t2,'hallucination versus concentration'),0,'Hallucination status versus concentration')
r_between=find_row(t2,'Between-subject'); cell_set(r_between,0,'Between-subject (maximum ΔΔ versus C_{max} or AUC_{0–∞})')
ra=add_row_after(t2,r_between,['Return of blood pressure to within 20% of baseline','34','34','1, 2, 4, 6, 8, 12, 24'])
add_row_after(t2,ra,['Time to hallucination onset / final resolution','34 / 30','34 / 30','—'])
# Table 4
t4=tbl_by_caption('T4')
def pr(k):
    r=w[k]; return [f3(r['slope']),f"{f3(r['lo'])}, {f3(r['hi'])}",f1(r['pred_gm'][0]),f"{f1(r['pred_gm'][1])}, {f1(r['pred_gm'][2])}",f1(r['pred_max'][0]),f"{f1(r['pred_max'][1])}, {f1(r['pred_max'][2])}",f3(r['single_slope']),f"{f3(r['single_lo'])}, {f3(r['single_hi'])}"]
S=pr('SBP'); D=pr('DBP'); trs=rows(t4)
# original order: hdr, SBP slope, SBP predGM, SBP predMax, SBP baseline, DBP slope, DBP predGM, DBP baseline
cell_set(trs[1],2,S[0]); cell_set(trs[1],3,S[1]); cell_set(trs[2],1,'Predicted ΔΔ at geometric mean C_{max} (26.9 ng/mL) (mmHg)'); cell_set(trs[2],2,S[2]); cell_set(trs[2],3,S[3]); cell_set(trs[3],1,'Predicted ΔΔ at maximum C_{max} (43.0 ng/mL) (mmHg)'); cell_set(trs[3],2,S[4]); cell_set(trs[3],3,S[5]); cell_set(trs[3],4,'—'); cell_set(trs[4],2,S[6]); cell_set(trs[4],3,S[7])
cell_set(trs[5],2,D[0]); cell_set(trs[5],3,D[1]); cell_set(trs[6],1,'Predicted ΔΔ at geometric mean C_{max} (26.9 ng/mL) (mmHg)'); cell_set(trs[6],2,D[2]); cell_set(trs[6],3,D[3]); cell_set(trs[7],2,D[6]); cell_set(trs[7],3,D[7])
add_row_after(t4,trs[3],['',f'Observed maximum mean ΔΔ (mmHg), at {w["SBP"]["obs_max_mean_h"]:.0f} h',f1(w['SBP']['obs_max_mean']),'—','—'])
rd=add_row_after(t4,trs[6],['','Predicted ΔΔ at maximum C_{max} (43.0 ng/mL) (mmHg)',D[4],D[5],'—'])
add_row_after(t4,rd,['',f'Observed maximum mean ΔΔ (mmHg), at {w["DBP"]["obs_max_mean_h"]:.0f} h',f1(w['DBP']['obs_max_mean']),'—','—'])
# Table 5 (6 cols): hdr + 4 rows -> restructure
t5=tbl_by_caption('T5'); trs=rows(t5); cell_set(trs[0],1,'Exposure metric'); cell_set(trs[0],2,'Slope (per unit)')
vals=[]
for k,lab in [('SBP','ΔΔ SBP (mmHg)'),('DBP','ΔΔ DBP (mmHg)'),('HR','ΔΔ pulse rate (bpm)')]:
    for xv,xl in [('CMAX','C_{max}'),('AUC','AUC_{0–∞}')]:
        q=b[k][f'max_{xv}']; vals.append([lab if xv=='CMAX' else '',xl,f3(q['slope']),f"{q['r']:+.2f}",f"{q['p']:.2f}",str(q['n'])])
for i in range(4):
    for j in range(6): cell_set(trs[1+i],j,vals[i][j])
last=trs[4]
for v in vals[4:]: last=add_row_after(t5,last,v)
# note under table 5 (new)
n5=new_par_like(TPL_NOTE,'Slope per ng/mL for C_{max} and per h·ng/mL for AUC_{0–∞}. Response = maximum reference-corrected increase at any post-dose timepoint.'); t5.addnext(n5)
# Table 6 (5 cols): hdr, SBP within, SBP between, DBP within, DBP between -> between first
t6=tbl_by_caption('T6'); trs=rows(t6)
cell_set(trs[0],1,'Slope'); cell_set(trs[0],2,'Estimate (mmHg per ng/mL)')
cell_set(trs[1],1,'Between-subject'); cell_set(trs[1],2,'0.839'); cell_set(trs[1],3,'−0.083, 1.761'); cell_set(trs[1],4,'—')
cell_set(trs[2],1,'Within-subject'); cell_set(trs[2],2,f3(wb['SBP']['within'])); cell_set(trs[2],3,f"{f3(wb['SBP']['w_lo'])}, {f3(wb['SBP']['w_hi'])}"); cell_set(trs[2],4,f"{wb['SBP']['npos']} / {wb['SBP']['ntot']}")
cell_set(trs[3],1,'Between-subject'); cell_set(trs[3],2,'0.699'); cell_set(trs[3],3,'0.137, 1.261'); cell_set(trs[3],4,'—')
cell_set(trs[4],1,'Within-subject'); cell_set(trs[4],2,f3(wb['DBP']['within'])); cell_set(trs[4],3,f"{f3(wb['DBP']['w_lo'])}, {f3(wb['DBP']['w_hi'])}"); cell_set(trs[4],4,f"{wb['DBP']['npos']} / {wb['DBP']['ntot']}")
t6.addnext(new_par_like(TPL_NOTE,'Between-subject slope: OLS of participant mean ΔΔ on participant mean time-matched concentration (n = 34). Within-subject slope: mixed-effects model with participant mean concentration as an additional covariate (222 observations).'))
# Table 7 (HR; 4 cols): rows: slope, predGM, predMax, obs max, between
t7=tbl_by_caption('T7'); trs=rows(t7)
cell_set(trs[1],1,f3(hr['slope'])); cell_set(trs[1],2,f"{f3(hr['lo'])}, {f3(hr['hi'])}"); cell_set(trs[2],0,'Predicted ΔΔ at geometric mean C_{max} (26.9 ng/mL) (bpm)'); cell_set(trs[3],0,'Predicted ΔΔ at maximum C_{max} (43.0 ng/mL) (bpm)')
cell_set(trs[2],1,f1(hr['pred_gm'][0])); cell_set(trs[2],2,f"{f1(hr['pred_gm'][1])}, {f1(hr['pred_gm'][2])}")
cell_set(trs[3],1,f1(hr['pred_max'][0])); cell_set(trs[3],2,f"{f1(hr['pred_max'][1])}, {f1(hr['pred_max'][2])}")
cell_set(trs[5],0,'Baseline-corrected (single Δ) slope, for reference'); cell_set(trs[5],1,f3(hr['single_slope'])); cell_set(trs[5],2,f"{f3(hr['single_lo'])}, {f3(hr['single_hi'])}"); cell_set(trs[5],3,'< 0.001')
# Table 8 (2 cols)
t8=tbl_by_caption('T8')
rw=find_row(t8,'total window'); cell_set(rw,0,'Total hallucination duration (first onset to last resolution), h, median (IQR)'); cell_set(rw,1,f'{H["total_med"]:.1f} ({H["total_iqr"][0]:.1f}, {H["total_iqr"][1]:.1f})')
ro=find_row(t8,'Onset, h post-dose'); add_row_after(t8,ro,['Time to first onset, Kaplan-Meier median (h)',f'{H["km"]["median_onset"]:.1f}'])
rdur=find_row(t8,'Episode duration'); cell_set(rdur,0,'Single-episode duration, h, median (IQR)'); add_row_after(t8,rdur,['Longest single episode per participant, h, median',f'{H["longest_med"]:.1f}'])
rres=find_row(t8,'Resolution, h post-dose'); cell_set(rres,0,'Time to final resolution, h post-dose, median (IQR); maximum'); add_row_after(t8,rres,['Time to final resolution, Kaplan-Meier median (h)',f'{H["km"]["median_resolution"]:.1f}'])
# Table 9 (4 cols) — accepted version has 3 rows: OR, predicted probability, resolution vs t1/2
t9=tbl_by_caption('T9')
rp=find_row(t9,'Probability of'); cell_set(rp,0,'Probability of hallucination versus time-matched concentration, OR per 10 ng/mL')
rpp=find_row(t9,'Predicted probability'); cell_set(rpp,0,'Predicted probability of hallucination: 0 ng/mL → geometric mean C_{max} (26.9 ng/mL)')
re1=add_row_after(t9,rpp,['EC20 (concentration at 20% probability), ng/mL (90% CI)',f'{L["EC20"]:.1f} ({L["EC20_ci"][0]:.1f}, {L["EC20_ci"][1]:.1f})','—','—'])
re2=add_row_after(t9,re1,['EC50 (concentration at 50% probability), ng/mL (90% CI)',f'{L["EC50"]:.1f} ({L["EC50_ci"][0]:.1f}, {L["EC50_ci"][1]:.1f})','—','—'])
re3=add_row_after(t9,re2,['Proportion with hallucination: peak; return to 0%',f'{100*H["prev_peak"]:.0f}% at {H["prev_peak_h"]:.0f} h; 0% by 12 h','—','—'])
re4=add_row_after(t9,re3,['Time at which mean concentration fell below EC50 / EC20 (h)',f'{tb["EC50_mean"]:.0f} / {tb["EC20_mean"]:.0f}','—','—'])
add_row_after(t9,re4,['Time at which 90th percentile concentration fell below EC50 / EC20 (h)',f'{tb["EC50_p90"]:.0f} / {tb["EC20_p90"]:.0f}','—','—'])
rtw=find_row(t9,'Total window versus'); cell_set(rtw,0,'Time to final resolution versus terminal t½, Spearman ρ')
rtd=add_row_after(t9,rtw,['Total hallucination duration versus terminal t½, Spearman ρ',f'{dur["total_THALF"]["rho"]:.2f}',f'{dur["total_THALF"]["p"]:.3f}','29'])
rtl=add_row_after(t9,rtd,['Longest single episode versus terminal t½, Spearman ρ',f'{dur["longest_THALF"]["rho"]:.2f}',f'{dur["longest_THALF"]["p"]:.3f}','29'])
rdm=add_row_after(t9,rtl,['Duration measures versus C_{max} or AUC_{0–∞}, Spearman ρ','Not significant','> 0.4','29'])
rp1=add_row_after(t9,rdm,['Partial ρ: total duration with t½, adjusted for AUC_{0–∞}',f'{pc["total_thalf_given_auc"][0]:.2f}',f'{pc["total_thalf_given_auc"][1]:.2f}','29'])
add_row_after(t9,rp1,['Partial ρ: total duration with AUC_{0–∞}, adjusted for t½',f'{pc["total_auc_given_thalf"][0]:.2f}',f'{pc["total_auc_given_thalf"][1]:.2f}','29'])
t9.addnext(new_par_like(TPL_NOTE,'OR = odds ratio. EC20/EC50 and their 90% CIs from the pooled logistic model (cluster bootstrap by participant). Duration measures as defined in Section 3.2.'))
# ---------------- 6. front matter lists ----------------
lot=doc.tables[1]._tbl; lof=doc.tables[2]._tbl; abb=doc.tables[3]._tbl
# LoT: edit titles and insert new row; LoF similarly
for tr in rows(lot)[1:]:
    txt=rowtext(tr)
    if txt.startswith('⟦T5⟧'): cell_set(tr,1,'Between-Subject Regression of Maximum ΔΔ on Individual C_{max} and AUC_{0–∞}')
    if txt.startswith('⟦T6⟧'): cell_set(tr,1,'Between-Subject and Within-Subject Slope Estimates for ΔΔ Blood Pressure'); add_row_after(lot,tr,['⟦Tret⟧','Return of Blood Pressure to Within 20% of the Day 8 Baseline'])
for tr in rows(lof)[1:]:
    txt=rowtext(tr)
    if txt.startswith('⟦F1⟧'): cell_set(tr,1,'ΔΔ SBP and ΔΔ DBP versus Time-Matched CYB003 Concentration')
    if txt.startswith('⟦F2⟧'): cell_set(tr,1,'Maximum ΔΔ SBP, DBP, and Pulse Rate versus Individual CYB003 C_{max}'); add_row_after(lof,tr,['⟦Fauc⟧','Maximum ΔΔ SBP, DBP, and Pulse Rate versus Individual CYB003 AUC_{0–∞}'])
    if txt.startswith('⟦F3⟧'): cell_set(tr,1,'Between-Subject and Within-Subject Concentration-ΔΔ Relationships for SBP and DBP'); add_row_after(lof,tr,['⟦Fret⟧','Proportion of Participants More Than 20% Above the Day 8 Baseline by Timepoint'])
    if txt.startswith('⟦F4⟧'): cell_set(tr,1,'ΔΔ Pulse Rate versus Time-Matched CYB003 Concentration'); add_row_after(lof,tr,['⟦Fhys⟧','Time-Ordered Mean Effect versus Mean CYB003 Concentration (SBP, DBP, Pulse Rate, Hallucination)'])
    if txt.startswith('⟦F5⟧'): cell_set(tr,1,'Hallucination/Perceptual Episodes Relative to Time of CYB003 Dose')
    if txt.startswith('⟦F6⟧'): add_row_after(lof,tr,['⟦Fkm⟧','Kaplan-Meier Estimates of Time to First Hallucination Onset and Time to Final Resolution'])
for tr in rows(abb)[1:]:
    txt=rowtext(tr)
    if txt.startswith('AE / TEAE'): pass
    if 'Area under' in txt: add_row_after(abb,tr,['BLQ','Below the lower limit of quantification'])
    if txt.startswith('DDI'): pass
    if txt.startswith('Δ / ΔΔ'): add_row_after(abb,tr,['EC20 / EC50','Concentration associated with 20% / 50% probability of hallucination'])
# ---------------- 7. resolve numbering tokens ----------------
order_T=['T1','T2','T3','T4','T5','T6','Tret','T7','T8','T9']; order_F=['F1','F2','Fauc','F3','Fret','F4','Fhys','F5','F6','Fkm','F7','F8']
MAP={f'⟦{k}⟧':f'Table {i+1}' for i,k in enumerate(order_T)}; MAP.update({f'⟦{k}⟧':f'Figure {i+1}' for i,k in enumerate(order_F)})
pat=re.compile('|'.join(re.escape(k) for k in MAP))
for t in list(body.iter(W('w:t')))+list(body.iter(W('w:delText'))):
    if t.text and '⟦' in t.text: t.text=pat.sub(lambda m:MAP[m.group(0)],t.text)
doc.save(OUT); print("saved",OUT)
