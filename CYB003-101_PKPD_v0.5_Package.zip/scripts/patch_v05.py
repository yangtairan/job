import copy, re, json
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from PIL import Image
SRC='CYB003-101_PKPD_Exploratory_ER_review_v0.4.docx'; OUT='CYB003-101_PKPD_Exploratory_ER_review_v0.5.docx'
AUTHOR='Tairan Yang'; DATE='2026-10-20T09:00:00Z'
doc=Document(SRC); body=doc.element.body; W=qn; _id=[40000]
def nid(): _id[0]+=1; return str(_id[0])
def ptext(p): return ''.join(t.text or '' for t in p.iter(W('w:t')))
def PE(prefix):
    for p in body.iter(W('w:p')):
        if ptext(p).strip().startswith(prefix): return p
    raise KeyError(prefix)
TOK=re.compile(r'\*\*.*?\*\*|_\{.*?\}|\s+|[^\s_*]+|[_*]')
def base_rpr(p):
    for r in p.iter(W('w:r')):
        rpr=r.find(W('w:rPr'))
        if rpr is not None:
            c=copy.deepcopy(rpr)
            for tag in ['w:b','w:vertAlign']:
                for e in c.findall(W(tag)): c.remove(e)
            return c
    return OxmlElement('w:rPr')
def mk_run(txt,rpr0,bold=False,sub=False,deleted=False):
    r=OxmlElement('w:r'); rpr=copy.deepcopy(rpr0)
    if bold: rpr.insert(0,OxmlElement('w:b'))
    if sub: v=OxmlElement('w:vertAlign'); v.set(W('w:val'),'subscript'); rpr.append(v)
    r.append(rpr); t=OxmlElement('w:delText' if deleted else 'w:t'); t.text=txt; t.set('{http://www.w3.org/XML/1998/namespace}space','preserve'); r.append(t); return r
def runs(markup,rpr0,deleted=False):
    out=[]
    for tok in TOK.findall(markup):
        if tok.startswith('**') and tok.endswith('**') and len(tok)>4: out.append(mk_run(tok[2:-2],rpr0,bold=True,deleted=deleted))
        elif tok.startswith('_{') and tok.endswith('}'): out.append(mk_run(tok[2:-1],rpr0,sub=True,deleted=deleted))
        else: out.append(mk_run(tok,rpr0,deleted=deleted))
    return out
def wrap(tag,rs):
    e=OxmlElement(tag); e.set(W('w:id'),nid()); e.set(W('w:author'),AUTHOR); e.set(W('w:date'),DATE)
    for r in rs: e.append(r)
    return e
def is_inserted_par(p):
    ppr=p.find(W('w:pPr')); rpr=ppr.find(W('w:rPr')) if ppr is not None else None
    return rpr is not None and rpr.find(W('w:ins')) is not None
def replace_inserted_par(p,markup):
    rpr0=base_rpr(p)
    for ch in list(p):
        if ch.tag!=W('w:pPr'): p.remove(ch)
    p.append(wrap('w:ins',runs(markup,rpr0)))
    ppr=p.find(W('w:pPr')); rpr=ppr.find(W('w:rPr'))
    if rpr is None: rpr=OxmlElement('w:rPr'); ppr.append(rpr)
    for e in list(rpr):
        if e.tag in (W('w:ins'),W('w:del')): rpr.remove(e)
    ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); rpr.append(ins)
def run_markup(r):
    t=r.find(W('w:t'))
    if t is None: return ''
    txt=t.text or ''; rpr=r.find(W('w:rPr'))
    bold=rpr is not None and rpr.find(W('w:b')) is not None
    sub=rpr is not None and rpr.find(W('w:vertAlign')) is not None and rpr.find(W('w:vertAlign')).get(W('w:val'))=='subscript'
    if sub: return '_{'+txt+'}'
    if bold and txt.strip(): return '**'+txt+'**'
    return txt
def tracked_edit_mixed(p,old_sub,new_sub):
    """Paragraph may contain prior tracked ins/del. Accept prior changes within this paragraph (same author), then diff."""
    import difflib
    for ins in list(p.findall(W('w:ins'))):
        idx=p.index(ins)
        for ch in list(ins): p.insert(idx,ch); idx+=1
        p.remove(ins)
    for d in list(p.findall(W('w:del'))): p.remove(d)
    old=''.join(run_markup(r) for r in p.findall(W('w:r'))); old=re.sub(r'\*\*(\s*)\*\*',r'\1',old).replace('**_{','_{').replace('}**','}')
    assert old_sub in old, 'substring not found: '+old_sub[:60]
    new=old.replace(old_sub,new_sub); rpr0=base_rpr(p)
    for r in list(p.findall(W('w:r'))): p.remove(r)
    a,b=TOK.findall(old),TOK.findall(new); sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
    for op,i1,i2,j1,j2 in sm.get_opcodes():
        if op=='equal':
            for r in runs(''.join(a[i1:i2]),rpr0): p.append(r)
        if op in ('delete','replace'): p.append(wrap('w:del',runs(''.join(a[i1:i2]),rpr0,deleted=True)))
        if op in ('insert','replace'): p.append(wrap('w:ins',runs(''.join(b[j1:j2]),rpr0)))
def set_pic(cap_prefix,png):
    cap=PE(cap_prefix); e=cap
    while e is not None:
        e=e.getnext()
        if e is not None and e.tag==W('w:p') and e.find('.//'+W('w:drawing')) is not None: break
    blip=e.find('.//'+W('a:blip')); part=doc.part.rels[blip.get(qn('r:embed'))].target_part; part._blob=open(png,'rb').read()
    w,h=Image.open(png).size
    for ext in [e.find('.//'+W('wp:extent')),e.find('.//'+W('a:ext'))]:
        cx=int(ext.get('cx')); ext.set('cy',str(int(cx*h/w)))
    return e
# ---- figures ----
pic9=set_pic('Figure 9.','newfig/Fig09_hall_boxplots.png'); pic10=set_pic('Figure 10.','newfig/Fig10_hall_KM.png')
# Figure 9 caption (original caption paragraph with prior tracked edits) -> accept-in-par + tracked replace
cap9=PE('Figure 9.')
tracked_edit_mixed(cap9,ptext(cap9).strip()[len('Figure 9. '):],'Single-Episode Hallucination Duration by Severity (A) and by Preferred Term (B)') if False else None
# simpler: rebuild caption as fresh tracked replacement of the whole text
def tracked_replace_whole(p,new):
    import difflib
    for ins in list(p.findall(W('w:ins'))):
        idx=p.index(ins)
        for ch in list(ins): p.insert(idx,ch); idx+=1
        p.remove(ins)
    for d in list(p.findall(W('w:del'))): p.remove(d)
    old=''.join(run_markup(r) for r in p.findall(W('w:r'))); rpr0=base_rpr(p)
    for r in list(p.findall(W('w:r'))): p.remove(r)
    a,b=TOK.findall(old),TOK.findall(new); sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
    for op,i1,i2,j1,j2 in sm.get_opcodes():
        if op=='equal':
            for r in runs(''.join(a[i1:i2]),rpr0): p.append(r)
        if op in ('delete','replace'): p.append(wrap('w:del',runs(''.join(a[i1:i2]),rpr0,deleted=True)))
        if op in ('insert','replace'): p.append(wrap('w:ins',runs(''.join(b[j1:j2]),rpr0)))
tracked_replace_whole(cap9,'Figure 9. Single-Episode Hallucination Duration by Severity (A) and by Preferred Term (B)')
note9=pic9.getnext(); replace_inserted_par(note9,'Boxes (unfilled) show the median and interquartile range; all individual episodes are plotted. In A, the four moderate events are shown in red.')
# Figure 10 note with event definitions
note10=pic10.getnext()
replace_inserted_par(note10,'Events: in A, the first onset of any hallucination/perceptual AE (time from dose to onset of the first episode); in B, the resolution of the last hallucination/perceptual episode (time from dose to final resolution). A: all 34 CYB003-dosed participants; the 4 participants without hallucination are censored at 48 h. B: the 30 participants with hallucination. Numbers at risk and cumulative events at each displayed timepoint are shown beneath the plots and in Table 10.')
# Table 10 note
noteT=PE('At risk = participants without the event'); replace_inserted_par(noteT,'Event: in A, first onset of any hallucination/perceptual AE; in B, resolution of the last hallucination/perceptual episode. At risk = participants without the event and still under observation at the timepoint; cumulative events = events occurring at or before the timepoint. In A, the 4 participants without hallucination are censored at 48 h.')
# ---- software statements: R only ----
p41=PE('Analyses were performed in R'); tracked_replace_whole(p41,'Analyses were performed in R version 4.3.3 (nlme 3.1 for mixed-effects models; ggplot2 for graphics and linear estimation).')
p45=PE('Model adequacy'); 
tracked_edit_mixed(p45,'; and by reproducing the estimates in both R and Python.','.')
# ---- LoF title for Figure 9 ----
lof=doc.tables[2]._tbl
for tr in lof.findall(W('w:tr')):
    tcs=tr.findall(W('w:tc'))
    if ptext(tcs[0]).strip()=='Figure 9':
        p=tcs[1].find(W('w:p')); tracked_replace_whole(p,'Single-Episode Hallucination Duration by Severity and by Preferred Term')
# ---- version/date ----
for row in doc.tables[0].rows:
    for c in row.cells:
        for x in c._tc.iter(W('w:t')):
            if x.text and 'Draft v0.4 / 13 October 2026' in x.text: x.text=x.text.replace('Draft v0.4 / 13 October 2026','Draft v0.5 / 20 October 2026')
            elif x.text and 'Draft v0.4' in x.text: x.text=x.text.replace('Draft v0.4','Draft v0.5')
            if x.text and '13 October 2026' in x.text: x.text=x.text.replace('13 October 2026','20 October 2026')
for p in doc.sections[0].header.paragraphs:
    for r in p.runs: r.text=r.text.replace('Draft v0.4, 13-Oct-2026','Draft v0.5, 20-Oct-2026').replace('Draft v0.4','Draft v0.5').replace('13-Oct-2026','20-Oct-2026')
doc.save(OUT); print("saved",OUT)
# ---- residual Python mentions? ----
t='\n'.join(ptext(p) for p in body.iter(W('w:p')))
import zipfile
root_t=t
for wd in ['Python','python','matplotlib','statsmodels','second software','two implementations']:
    print(f"  '{wd}': {root_t.count(wd)}")
