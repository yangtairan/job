# ==============================================================================
# BNT317-01 Exploratory PK Analysis (full EDA suite)
# ------------------------------------------------------------------------------
# Inputs (raw Medidata/IQVIA listings, xlsx):
#   1. EXT_IQVIA_PK : PK concentrations (header row 7 + 1 label row)
#   2. EX (CRF)     : dosing / infusion start-end (header row 7 + 1 label row)
#   3. Subjects     : cohort & demographics (header row 6 + 1 label row)
#
# Dose levels derived from Subjects$COHORT (planned dose):
#   DL1 = 70, DL2 = 200, DL3 = 600, DL4 = 1200, DL5 = 1800 mg
#   (verified 100% consistent with EXPLDOS in EX)
#
# Conventions:
#   - Time axis = time since each subject's first infusion start ("Time (days)")
#   - BLQ ("BLQ (<20.0)") plotted at LLOQ/2 with open symbols; LLOQ = 20 ng/mL
#   - TAD from rolling join to most recent infusion start (dplyr >= 1.1)
#
# Figures:
#   F1  conc vs time, faceted by dose level (semi-log + linear)
#   F2  Cycle 1 TAD profiles: individuals + geometric means (log 0-200 h,
#       linear 0-10 h)
#   F3  Cycle 1 dose-normalized geometric mean profiles
#   F4  Dose proportionality: C1 EOI and C1 168 h conc vs dose (power model)
#   F5  Pre-dose troughs across cycles by dose level
#   F6  BLQ fraction by nominal timepoint and dose
# Output: figures (png) + analysis-ready CSV in ./eda_output
# ==============================================================================

library(readxl)
library(dplyr)     # >= 1.1 for join_by(closest())
library(tidyr)
library(stringr)
library(lubridate)
library(ggplot2)
library(scales)

# ---- 0. Paths & constants ------------------------------------------------------
dir_in  <- "."     
dir_out <- "eda_output"
dir.create(dir_out, showWarnings = FALSE)

f_pk  <- file.path(dir_in, "BNT317-01-RawClinicalNonCRF-EXT_IQVIA_PK_biontech_20260812032845.xlsx")
f_ex  <- file.path(dir_in, "BNT317-01-RawClinicalCRF-EX_biontech_20260812033056.xlsx")
f_sub <- file.path(dir_in, "BNT317-01_Subjects_biontech_20260812032931.xlsx")

lloq      <- 20                                     # ng/mL
dose_map  <- c(`1` = 70, `2` = 200, `3` = 600, `4` = 1200, `5` = 1800)
dose_lvls <- paste(dose_map, "mg")
tpt_lvls  <- c("Pre-dose", "End of infusion", "2 h post-dose", "4 h post-dose",
               "72 h post-dose", "168 h post-dose", "Unscheduled")

gm  <- function(x) exp(mean(log(x), na.rm = TRUE))
gsd <- function(x) if (sum(!is.na(x)) > 1) exp(sd(log(x), na.rm = TRUE)) else NA_real_

theme_pk <- theme_bw(base_size = 11) +
  theme(legend.position = "bottom", panel.grid.minor = element_blank())
col_dose  <- scale_colour_viridis_d(name = "Planned dose", end = 0.9)
fill_dose <- scale_fill_viridis_d(name = "Planned dose", end = 0.9)
shp_blq   <- scale_shape_manual(values = c(`FALSE` = 16, `TRUE` = 1), name = "BLQ")

# ---- 1. Read raw listings (skip metadata; drop label row under header) ---------
read_listing <- function(path, skip) {
  read_excel(path, skip = skip, .name_repair = "unique_quiet") |> slice(-1)
}
pk_raw  <- read_listing(f_pk,  6)
ex_raw  <- read_listing(f_ex,  6)
sub_raw <- read_listing(f_sub, 5)

# ---- 2. Subjects: dose level from cohort ----------------------------------------
subj <- sub_raw |>
  transmute(
    ID     = Subject,
    COHORT = as.character(COHORT),
    SEX    = Gender,
    AGE    = as.numeric(AGE),
    DOSEMG = unname(dose_map[COHORT]),
    DOSEF  = factor(paste(DOSEMG, "mg"), levels = dose_lvls)
  ) |>
  filter(!is.na(DOSEMG))

# ---- 3. EX: dosing events --------------------------------------------------------
ex <- ex_raw |>
  transmute(
    ID      = Subject,
    EXYN    = EXYN_STD,
    CYCLE   = as.integer(str_match(InstanceName, "Cycle\\s*(\\d+)")[, 2]),
    DOSTDTC = mdy_hm(paste(EXSTDAT, EXSTTIM), quiet = TRUE),
    DOENDTC = mdy_hm(paste(EXENDAT, EXENTIM), quiet = TRUE),
    EXPLDOS = as.numeric(EXPLDOS),
    EXDOSE  = as.numeric(EXDOSE)
  ) |>
  filter(EXYN == "Y", !is.na(DOSTDTC)) |>
  arrange(ID, DOSTDTC)

first_dose <- ex |> group_by(ID) |> summarise(FIRSTDOSE = min(DOSTDTC), .groups = "drop")

# ---- 4. PK: clean, derive times ---------------------------------------------------
pk <- pk_raw |>
  transmute(
    ID      = SUBJECT_ID,
    SAMPLE  = SAMPLENUMBER,
    VISIT   = VISITNAME,
    TPT     = TIMEPOINT,
    ADTC    = dmy(COLLECTIONDATE) + hm(COLLECTIONTIME),
    RESULTC = RESULT
  ) |>
  filter(!is.na(RESULTC)) |>
  mutate(
    BLQ   = str_detect(RESULTC, "BLQ"),
    DV    = if_else(BLQ, lloq / 2, suppressWarnings(as.numeric(RESULTC))),
    CYCLE = as.integer(str_match(VISIT, "^C(\\d+)D")[, 2]),
    DAY   = as.integer(str_match(VISIT, "D(\\d+)$")[, 2]),
    TPTF  = factor(TPT, levels = tpt_lvls)
  ) |>
  left_join(subj,       by = "ID") |>
  left_join(first_dose, by = "ID") |>
  mutate(TIME_D = as.numeric(difftime(ADTC, FIRSTDOSE, units = "days"))) |>
  # TAD: rolling join to most recent infusion start <= sample time
  left_join(ex |> select(ID, DOSTDTC, EXDOSE, DOSE_CYCLE = CYCLE),
            by = join_by(ID, closest(ADTC >= DOSTDTC))) |>
  mutate(
    TAD_H = as.numeric(difftime(ADTC, DOSTDTC, units = "hours")),
    # C1D1 pre-dose draws precede first infusion -> anchor at TAD 0, Cycle 1
    TAD_H      = if_else(is.na(TAD_H) & TPT == "Pre-dose", 0, TAD_H),
    DOSE_CYCLE = if_else(is.na(DOSE_CYCLE) & TPT == "Pre-dose", CYCLE, DOSE_CYCLE)
  )

# ---- 5. Data checks ---------------------------------------------------------------
cat("Subjects with PK:", n_distinct(pk$ID), "\n")
print(count(distinct(pk, ID, DOSEF), DOSEF, name = "n_subjects"))
cat("\nSamples by timepoint x dose:\n"); print(with(pk, table(TPTF, DOSEF)))
cat("\nBLQ:", sum(pk$BLQ), "of", nrow(pk), sprintf("(%.1f%%)\n", 100 * mean(pk$BLQ)))
cat("\nRecords with actual dose deviating >1 mg from planned:\n")
print(pk |> filter(abs(EXDOSE - DOSEMG) > 1) |>
        distinct(ID, DOSE_CYCLE, DOSEMG, EXDOSE))
flag <- filter(pk, is.na(DV) | TIME_D < -0.25)
if (nrow(flag)) { cat("\nRecords to review:\n")
  print(select(flag, ID, VISIT, TPT, RESULTC, TIME_D)) }

# ---- F1. Conc vs time by dose level (semi-log + linear) -----------------------------
p_base <- pk |>
  filter(!is.na(DV)) |>
  ggplot(aes(TIME_D, DV, group = ID, colour = DOSEF)) +
  geom_line(alpha = 0.45) +
  geom_point(aes(shape = BLQ), size = 1.4) +
  geom_hline(yintercept = lloq, linetype = "dashed", colour = "grey40") +
  shp_blq + facet_wrap(~DOSEF, ncol = 2, scales = "free_x") +
  col_dose + guides(colour = "none") +
  labs(x = "Time (days)", y = "BNT317 concentration (ng/mL)",
       title = "BNT317 concentration vs. time by dose level",
       subtitle = "Time relative to first dose; BLQ at LLOQ/2 (open); dashed = LLOQ") +
  theme_pk

ggsave(file.path(dir_out, "f1_conc_time_by_dose_semilog.png"),
       p_base + scale_y_log10(labels = label_number()), width = 9, height = 7, dpi = 300)
ggsave(file.path(dir_out, "f1b_conc_time_by_dose_linear.png"),
       p_base, width = 9, height = 7, dpi = 300)

# ---- F2. Cycle 1 TAD profiles: individuals + geometric means ------------------------
pk_c1 <- pk |>
  filter(CYCLE == 1, TPT != "Unscheduled", !is.na(DV),
         !is.na(TAD_H), TAD_H >= 0, TAD_H <= 200)

gm_c1 <- pk_c1 |>
  group_by(DOSEF, TPTF) |>
  summarise(TAD_H = median(TAD_H), GMEAN = gm(DV), n = n(), .groups = "drop") |>
  filter(n >= 2)

p2core <- ggplot(pk_c1, aes(TAD_H, DV, colour = DOSEF)) +
  geom_line(aes(group = ID), alpha = 0.25, linewidth = 0.5) +
  geom_point(aes(shape = BLQ), size = 1.2, alpha = 0.5) +
  geom_line(data = gm_c1, aes(y = GMEAN), linewidth = 1.1) +
  geom_point(data = gm_c1, aes(y = GMEAN), size = 2.4) +
  geom_hline(yintercept = lloq, linetype = "dashed", colour = "grey40") +
  shp_blq + col_dose +
  labs(x = "Time after dose (h)", y = "BNT317 concentration (ng/mL)",
       title = "Cycle 1 concentration-time profiles",
       subtitle = "Thin = individuals; bold = geometric mean at nominal timepoints") +
  theme_pk
ggsave(file.path(dir_out, "f2_cycle1_semilog.png"),
       p2core + scale_y_log10(labels = label_number()), width = 8.5, height = 6, dpi = 300)
ggsave(file.path(dir_out, "f2b_cycle1_linear_0-10h.png"),
       p2core + coord_cartesian(xlim = c(0, 10)), width = 8.5, height = 6, dpi = 300)

# ---- F3. Cycle 1 dose-normalized geometric mean profiles ----------------------------
gm_dn <- pk_c1 |>
  mutate(DVN = DV / DOSEMG) |>
  group_by(DOSEF, TPTF) |>
  summarise(TAD_H = median(TAD_H), GMEAN = gm(DVN), n = n(), .groups = "drop") |>
  filter(n >= 2)

p3 <- ggplot(gm_dn, aes(TAD_H, GMEAN, colour = DOSEF)) +
  geom_line(linewidth = 1) + geom_point(size = 2.4) +
  scale_y_log10(labels = label_number()) + col_dose +
  labs(x = "Time after dose (h)", y = "Dose-normalized conc (ng/mL per mg)",
       title = "Cycle 1 geometric mean dose-normalized profiles",
       subtitle = "Superimposition across doses = dose-proportional PK") +
  theme_pk
ggsave(file.path(dir_out, "f3_dose_normalized_c1.png"), p3, width = 8, height = 5.5, dpi = 300)

# ---- F4. Dose proportionality (power model on C1 EOI and C1 168 h) ------------------
dp <- pk |>
  filter(CYCLE == 1, TPT %in% c("End of infusion", "168 h post-dose"), !BLQ, !is.na(DV)) |>
  mutate(METRIC = if_else(TPT == "End of infusion",
                          "C1 end-of-infusion", "C1 168 h post-dose"))

slopes <- dp |>
  group_by(METRIC) |>
  summarise(slope = coef(lm(log(DV) ~ log(DOSEMG)))[2],
            n = n(), .groups = "drop")
print(slopes)

p4 <- ggplot(dp, aes(DOSEMG, DV, colour = DOSEF)) +
  geom_point(alpha = 0.75, size = 2, position = position_jitter(width = 0.02)) +
  stat_summary(fun = gm, geom = "point", shape = 18, size = 4, colour = "black") +
  geom_smooth(aes(group = 1), method = "lm", se = TRUE,
              colour = "grey30", linewidth = 0.6, linetype = "dashed") +
  scale_x_log10(breaks = unname(dose_map)) +
  scale_y_log10(labels = label_number()) +
  facet_wrap(~METRIC, scales = "free_y") + col_dose +
  labs(x = "Dose (mg)", y = "Concentration (ng/mL)",
       title = "Dose proportionality, Cycle 1") +
  theme_pk
ggsave(file.path(dir_out, "f4_dose_proportionality.png"), p4, width = 10, height = 5.5, dpi = 300)

# ---- F5. Pre-dose troughs across cycles ---------------------------------------------
p5 <- pk |>
  filter(TPT == "Pre-dose", !is.na(DV), !is.na(CYCLE)) |>
  ggplot(aes(CYCLE, DV, colour = DOSEF)) +
  geom_line(aes(group = ID), alpha = 0.4) +
  geom_point(aes(shape = BLQ), size = 1.6) +
  geom_hline(yintercept = lloq, linetype = "dashed", colour = "grey40") +
  scale_y_log10(labels = label_number()) +
  scale_x_continuous(breaks = pretty_breaks()) +
  shp_blq + facet_wrap(~DOSEF, ncol = 2, scales = "free_x") +
  col_dose + guides(colour = "none") +
  labs(x = "Cycle", y = "Pre-dose concentration (ng/mL)",
       title = "Pre-dose (trough) concentrations across cycles",
       ) +
  theme_pk
ggsave(file.path(dir_out, "f5_troughs_by_cycle.png"), p5, width = 9, height = 7, dpi = 300)

# ---- F6. BLQ fraction by timepoint and dose ------------------------------------------
p6 <- pk |>
  filter(TPT != "Unscheduled") |>
  group_by(DOSEF, TPTF) |>
  summarise(pct_blq = 100 * mean(BLQ), n = n(), .groups = "drop") |>
  ggplot(aes(TPTF, pct_blq, fill = DOSEF)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.7) +
  fill_dose +
  labs(x = NULL, y = "% BLQ",
       title = "BLQ fraction by nominal timepoint and dose level (all cycles)") +
  theme_pk + theme(axis.text.x = element_text(angle = 20, hjust = 1))
ggsave(file.path(dir_out, "f6_blq_fraction.png"), p6, width = 9, height = 5.5, dpi = 300)

# ---- 7. Summary tables & analysis-ready dataset ---------------------------------------
sum_tab <- pk_c1 |>
  filter(!BLQ) |>
  group_by(DOSEF, TPTF) |>
  summarise(n = n(), gmean = gm(DV), gsd = gsd(DV),
            min = min(DV), max = max(DV), .groups = "drop")
readr::write_csv(sum_tab, file.path(dir_out, "cycle1_summary_stats.csv"))

readr::write_csv(
  pk |> select(ID, DOSEMG, DOSEF, VISIT, CYCLE, DAY, TPT, ADTC,
               TIME_D, TAD_H, DV, BLQ, EXDOSE, RESULTC, SAMPLE),
  file.path(dir_out, "bnt317_pk_eda_dataset.csv")
)

cat("\nDone. Output written to:", normalizePath(dir_out), "\n")
