################################################################################
## BNT211 CLDN6 CAR-T -- Table 1 (demographics & baseline covariates)
## Produces a publication Table 1 stratified by treatment arm and by dose level.
## Primary: gtsummary (clean, standard). CSVs always written.
## requires: dplyr, readr, gtsummary  (optional: gt, flextable for image/docx)
################################################################################
library(dplyr); library(readr)
OUT <- "bnt211_poppk"; TAB <- file.path(OUT,"output","tables")
dir.create(TAB, recursive=TRUE, showWarnings=FALSE)

d <- read_csv(file.path(OUT,"data","poppk_bnt211_carT.csv"), na=".", show_col_types=FALSE)
combo <- d %>% filter(ANALYTE=="RNALPX_DOSE") %>% distinct(USUBJID) %>% pull()
sub <- d %>% distinct(USUBJID, .keep_all=TRUE) %>%
  mutate(ARM   = if_else(USUBJID %in% combo, "Combo (+CARVac)", "Mono"),
         Female= if_else(SEXN==1,"Female","Male"),
         LD    = if_else(REDLDFL==1,"Reduced","Standard"),
         Process = if_else(PROCAUTO==1,"Automated","Manual"),
         Redosed = if_else(REDOSEFL==1,"Yes","No"),
         ECOG  = factor(ECOGN),
         DOSELVL = factor(DOSELVL, levels=c("DL0","DL1","DL1.5","DL2","DL3","DL7","DL8")))

vars <- c("AGE","Female","RACE","WEIGHT","HEIGHT","BMI","BSA","ECOG","TUMTYPE",
          "LD","Process","CARDOSE","Redosed")
labels_list <- list(AGE="Age, y", Female="Sex", RACE="Race", WEIGHT="Weight, kg",
  HEIGHT="Height, cm", BMI~"BMI, kg/m^2", BSA="BSA, m^2", ECOG="ECOG status",
  TUMTYPE="Tumor type", LD="Lymphodepletion", Process="Manufacturing process",
  CARDOSE="CAR-T cell dose", Redosed="Re-dosed")

## ---- gtsummary Table 1 (preferred) ----------------------------------------
make_tbl1 <- function(strat){
  gtsummary::tbl_summary(
    sub %>% select(all_of(c(vars, strat))),
    by = strat,
    statistic = list(gtsummary::all_continuous() ~ "{median} ({min}, {max})",
                     gtsummary::all_categorical() ~ "{n} ({p}%)"),
    digits = list(gtsummary::all_continuous() ~ 1)
  ) |>
    gtsummary::add_overall() |>
    gtsummary::modify_header(label = "**Characteristic**") |>
    gtsummary::bold_labels()
}

if (requireNamespace("gtsummary", quietly=TRUE)){
  t1_arm  <- make_tbl1("ARM")
  t1_dose <- make_tbl1("DOSELVL")
  # export to CSV
  readr::write_csv(gtsummary::as_tibble(t1_arm),  file.path(TAB,"Table1_by_arm.csv"))
  readr::write_csv(gtsummary::as_tibble(t1_dose), file.path(TAB,"Table1_by_doselevel.csv"))
  # optional polished outputs (uncomment if gt / flextable installed)
  # gt::gtsave(gtsummary::as_gt(t1_arm), file.path(OUT,"output","figures","final","Table1_by_arm.png"))
  # flextable::save_as_docx(gtsummary::as_flex_table(t1_arm), path=file.path(OUT,"output","Table1.docx"))
  print(t1_arm)
} else {
  ## ---- manual fallback (no gtsummary) -------------------------------------
  contin <- function(x) sprintf("%.1f (%.0f-%.0f)", median(x,na.rm=TRUE), min(x,na.rm=TRUE), max(x,na.rm=TRUE))
  pct <- function(v) sprintf("%d (%.0f%%)", sum(v,na.rm=TRUE), 100*mean(v,na.rm=TRUE))
  tab <- function(df){
    tibble(
      Characteristic=c("N","Age, y","Female","Weight, kg","Height, cm","BMI","BSA",
        "ECOG 0","ECOG 1","ECOG 2","Ovarian","GCT","Others",
        "Reduced LD","Automated process","Re-dosed"),
      Value=c(nrow(df), contin(df$AGE), pct(df$Female=="Female"),
        contin(df$WEIGHT), contin(df$HEIGHT), contin(df$BMI), contin(df$BSA),
        pct(df$ECOGN==0), pct(df$ECOGN==1), pct(df$ECOGN==2),
        pct(df$TUMTYPE=="Ovarian"), pct(df$TUMTYPE=="GCT"), pct(df$TUMTYPE=="Others"),
        pct(df$LD=="Reduced"), pct(df$Process=="Automated"), pct(df$Redosed=="Yes")))
  }
  out <- tab(sub) %>% rename(All=Value) %>%
    left_join(tab(filter(sub,ARM=="Mono")) %>% rename(Mono=Value), by="Characteristic") %>%
    left_join(tab(filter(sub,ARM!="Mono")) %>% rename(Combo=Value), by="Characteristic")
  write_csv(out, file.path(TAB,"Table1_by_arm.csv")); print(out)
}
cat("\nTable 1 written to", TAB, "\n")
