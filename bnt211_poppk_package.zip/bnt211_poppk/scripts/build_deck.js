const pptxgen = require("pptxgenjs");
const p = new pptxgen();
p.layout = "LAYOUT_WIDE";              // 13.33 x 7.5
p.author = "Pharmacometrics";
p.title  = "BNT211 CLDN6 CAR-T PopPK";

const DARK="0F3D4C", TEAL="2A9D8F", CORAL="E76F51", INK="22333B",
      MUTED="5A6B72", TINT="EEF4F4", WHITE="FFFFFF", GOLD="E9C46A";
const HF="Cambria", BF="Calibri";
const FIG="bnt211_poppk/output/figures/eda2/", ROOT="bnt211_poppk/output/figures/";
const SW=13.33, SH=7.5;
const shadow=()=>({type:"outer",color:"000000",blur:7,offset:3,angle:90,opacity:0.13});

function title(s, t){
  s.addShape(p.shapes.OVAL,{x:0.55,y:0.52,w:0.20,h:0.20,fill:{color:TEAL}});
  s.addText(t,{x:0.9,y:0.32,w:11.8,h:0.7,fontFace:HF,fontSize:28,bold:true,color:DARK,margin:0});
}
function takeaway(s,x,y,w,h,head,lines,accent=TEAL){
  s.addShape(p.shapes.ROUNDED_RECTANGLE,{x,y,w,h,rectRadius:0.08,fill:{color:TINT},shadow:shadow()});
  s.addText(head,{x:x+0.25,y:y+0.18,w:w-0.5,h:0.45,fontFace:HF,fontSize:15,bold:true,color:accent,margin:0});
  s.addText(lines.map((t,i)=>({text:t,options:{bullet:{indent:14},breakLine:true,
     paraSpaceAfter:6,color:INK,fontSize:12.5}})),
     {x:x+0.25,y:y+0.62,w:w-0.45,h:h-0.8,fontFace:BF,valign:"top",margin:0});
}
// preserve aspect: given height -> width
const W=(asp,h)=>h*asp;

/* 1 TITLE */
let s=p.addSlide(); s.background={color:DARK};
s.addShape(p.shapes.OVAL,{x:11.2,y:-1.4,w:3.6,h:3.6,fill:{color:TEAL,transparency:78}});
s.addShape(p.shapes.OVAL,{x:-1.0,y:5.4,w:3.2,h:3.2,fill:{color:CORAL,transparency:82}});
s.addText("BNT211 CLDN6 CAR-T",{x:0.8,y:2.0,w:11.7,h:0.9,fontFace:HF,fontSize:42,bold:true,color:WHITE});
s.addText("Population cellular kinetics — key findings, hypothesis tests, and proposed model roadmap",
  {x:0.8,y:3.0,w:11.4,h:0.9,fontFace:BF,fontSize:20,color:"CADCDC"});
s.addText("Autologous CLDN6 CAR-T  ±  CLDN6 RNA-LPX (CARVac)   ·   161 subjects   ·   transgene qPCR (copies/µg DNA)",
  {x:0.8,y:4.15,w:11.6,h:0.5,fontFace:BF,fontSize:13,color:TEAL,italic:true});

/* 2 BACKGROUND / OBJECTIVE */
s=p.addSlide(); s.background={color:WHITE}; title(s,"Background & objective");
s.addText([
  {text:"The combination design.  ",options:{bold:true,color:DARK}},
  {text:"BNT211 pairs an autologous CLDN6 CAR-T product with a repeated RNA-LPX vaccine (CARVac) intended to re-stimulate and expand CAR-T cells in vivo. Cellular kinetics are measured as transgene copies/µg DNA by qPCR.",options:{color:INK}}
],{x:0.6,y:1.4,w:7.2,h:1.4,fontFace:BF,fontSize:14,valign:"top",lineSpacingMultiple:1.05});
s.addText([
  {text:"Reframed question.  ",options:{bold:true,color:CORAL}},
  {text:"A prior expansion–contraction + vaccine-restimulation model showed the CARVac effect on PK is limited. So the goal shifts from \u201Cquantify the boost\u201D to: ",options:{color:INK}},
  {text:"what actually governs CLDN6 CAR-T kinetics in solid tumors, and how large (or small) is the CARVac PK effect once confounding is controlled?",options:{bold:true,color:DARK}}
],{x:0.6,y:2.95,w:7.2,h:1.9,fontFace:BF,fontSize:14,valign:"top",lineSpacingMultiple:1.05});
takeaway(s,8.2,1.5,4.5,4.2,"Why this still publishes",[
  "First popPK of a solid-tumor CLDN6 CAR-T",
  "Identifies the true exposure determinants",
  "A rigorous, confound-controlled bound on the CARVac PK effect",
  "Actionable message: optimize lymphodepletion, not vaccine, for exposure"],CORAL);

/* 3 DATA / ANALYSIS SET */
s=p.addSlide(); s.background={color:WHITE}; title(s,"Data & analysis set");
const stat=(x,big,lab,c)=>{ s.addText(big,{x,y:1.6,w:2.9,h:0.95,fontFace:HF,fontSize:40,bold:true,color:c,align:"center"});
  s.addText(lab,{x,y:2.55,w:2.9,h:0.7,fontFace:BF,fontSize:12.5,color:MUTED,align:"center"}); };
stat(0.6,"161","treated subjects",DARK);
stat(3.7,"2,194","transgene observations",TEAL);
stat(6.8,"762","dosing events (191 CAR-T / 571 CARVac)",DARK);
stat(9.9,"17%","BLQ (kept, CENS=1)",CORAL);
takeaway(s,0.6,3.55,5.8,3.3,"Analysis structure",[
  "Continuous timeline per subject; re-dosing handled (24 re-dosed)",
  "Mono (n=28) vs Combo +CARVac (n=133); overlap at DL1\u2013DL3",
  "7 flat dose levels: 1\u00D710\u2076 \u2013 2\u00D710\u2078 CAR+ cells",
  "Per-subject/cycle metrics: Cmax, Tmax, AUC0\u201328, \u03B2-slope, persistence"]);
takeaway(s,6.7,3.55,6.0,3.3,"Hypotheses tested",[
  "H1 dose\u2013exposure (saturation?)",
  "H2 lymphodepletion intensity",
  "H3 CARVac effect (event-aligned, confound-controlled)",
  "H4 manufacturing process  ·  H5 tumor type  ·  H6 re-dosing"],CORAL);

/* generic figure slide */
function figslide(ttl, img, asp, head, lines, accent, imgH=4.7){
  const sx=p.addSlide(); sx.background={color:WHITE}; title(sx,ttl);
  const w=W(asp,imgH); sx.addImage({path:img,x:0.55,y:1.45,w,h:imgH});
  takeaway(sx, 0.55+w+0.3, 1.7, Math.max(3.4, SW-(0.55+w+0.3)-0.45), 4.2, head, lines, accent);
  return sx;
}

/* 4 DRIVER RANKING */
figslide("Finding 1 \u2014 what governs CAR-T kinetics", FIG+"F1_driver_tornado.png", 2.40,
  "Dose & lymphodepletion lead",
  ["Cell dose and lymphodepletion are the largest effects on peak expansion",
   "+CARVac sits near zero on expansion",
   "Crude CARVac\u2013persistence bar is large but confounded (next slides)"], TEAL, 3.4);

/* 5 LYMPHODEPLETION */
figslide("Finding 2 \u2014 lymphodepletion is dominant", FIG+"F3_lymphodepletion.png", 2.40,
  "~3\u20134\u00D7 effect",
  ["Reduced-LD subjects expand ~3\u00D7 lower (Cmax) and persist ~3\u00D7 lower",
   "AUC0\u201328 ~4.5\u00D7 lower without full lymphodepletion",
   "Biology: LD creates the IL-7/IL-15 homeostatic niche for expansion"], TEAL, 3.4);

/* 6 DOSE SATURATION */
figslide("Finding 3 \u2014 dose\u2013exposure saturates", FIG+"F2_dose_saturation.png", 1.60,
  "Plateau \u2265 1\u00D710\u2078",
  ["Cmax/AUC rise then plateau above ~1\u00D710\u2078 cells (DL2 \u2248 DL3)",
   "\u201CLow\u201D DL7/DL8 cohorts are low because of reduced LD, not dose",
   "Implication: model dose with a saturable (Emax-type) term, not linear"], TEAL);

/* 7 CARVAC EVENT-ALIGNED */
figslide("Finding 4 \u2014 the rigorous CARVac PK test", FIG+"F4_perivaccine.png", 1.80,
  "Maintenance = no effect",
  ["Maintenance CARVac (\u2265d21): geomean fold 1.07, median 0.93",
   "26% of doses bump up, 29% drift down \u2014 symmetric around null",
   "The apparent \u201Cboost\u201D is only the day-4 dose riding the primary expansion"], CORAL);

/* 8 CONFOUNDING */
figslide("Finding 5 \u2014 arm comparison is confounded", FIG+"F5_carvac_matched.png", 2.444,
  "Interpret with care",
  ["Within standard-LD, dose-matched: no CARVac expansion gain",
   "All reduced-LD patients sit in the combo arm (built-in bias)",
   "Lower combo persistence is fragile \u2014 mono late samples are sparse"], CORAL, 3.4);

/* 9 SYNTHESIS */
s=p.addSlide(); s.background={color:DARK}; 
s.addShape(p.shapes.OVAL,{x:11.4,y:-1.2,w:3.2,h:3.2,fill:{color:TEAL,transparency:80}});
s.addText("Synthesis",{x:0.8,y:0.5,w:11,h:0.7,fontFace:HF,fontSize:30,bold:true,color:WHITE});
const syn=(y,n,h,b,c)=>{ s.addText(n,{x:0.8,y,w:0.7,h:0.9,fontFace:HF,fontSize:34,bold:true,color:c});
  s.addText([{text:h+"  ",options:{bold:true,color:WHITE}},{text:b,options:{color:"CADCDC"}}],
   {x:1.7,y:y+0.05,w:6.95,h:0.95,fontFace:BF,fontSize:14.5,valign:"top",lineSpacingMultiple:1.0}); };
syn(1.5,"1","Lymphodepletion is the master lever \u2014","the dominant determinant of both expansion and persistence.",TEAL);
syn(2.7,"2","Dose\u2013exposure saturates \u2265 1\u00D710\u2078 \u2014","weak dose-response above the plateau, as seen across CAR-T.",TEAL);
syn(3.9,"3","CARVac does not raise systemic exposure \u2014","maintenance doses give no re-expansion; effect is a bounded null.",CORAL);
syn(5.1,"4","Therefore \u2014","CARVac\u2019s benefit (if real) is likely functional/PD or tissue, not blood PK.",GOLD);
s.addImage({path:FIG+"F6_phenotype_map.png",x:8.95,y:1.75,w:W(1.231,3.45),h:3.45});
s.addText("Expansion\u2013persistence phenotypes",{x:8.95,y:5.3,w:4.2,h:0.4,fontFace:BF,fontSize:10.5,italic:true,color:"9FBFC4"});

/* 10 BASE MODEL */
s=p.addSlide(); s.background={color:WHITE}; title(s,"Proposed starting base model");
s.addImage({path:ROOT+"base_model_schematic.png",x:0.5,y:1.35,w:W(1.964,3.55),h:3.55});
s.addText([
  {text:"Effector\u2013memory cellular-kinetics ODE (drop the vaccine-on-proliferation term):",options:{bold:true,color:DARK,breakLine:true,fontSize:13}},
  {text:"E(t\u207A) = E + Fr\u00B7Dose      (seed at each CAR-T infusion)",options:{breakLine:true,color:INK,fontSize:12}},
  {text:"dE/dt = k_g\u00B7E\u00B7(1 \u2212 (E+M)/CC) \u2212 k_de\u00B7E \u2212 k_em\u00B7E",options:{breakLine:true,color:INK,fontSize:12}},
  {text:"dM/dt = k_em\u00B7E \u2212 k_dm\u00B7M",options:{breakLine:true,color:INK,fontSize:12}},
  {text:"ln(DV) = ln(E + M) + \u03B5        (M3 likelihood for 17% BLQ)",options:{color:INK,fontSize:12}}
],{x:0.55,y:5.05,w:7.1,h:1.9,fontFace:"Consolas",valign:"top",lineSpacingMultiple:1.15,
   fill:{color:TINT},margin:8});
takeaway(s,8.1,1.5,4.7,5.2,"Rationale & specification",[
  "Backbone trusted in CAR-T popPK (Stein 2019; liso-cel 2021)",
  "Homeostatic cap CC gives the peak/turnaround without tumor data",
  "Memory pool M carries the slow persistence tail",
  "ODE form ingests re-dosing & vaccine events natively",
  "Covariates: LD \u2192 k_g/CC; saturable dose \u2192 Fr; process, body size",
  "CARVac entered as a TESTED covariate \u2192 report bounded effect + CI"]);

/* 11 ROADMAP */
s=p.addSlide(); s.background={color:WHITE}; title(s,"Model development roadmap");
const steps=[
 ["1","Structural","Compare effector\u2013memory ODE vs piecewise growth\u2013biexponential; fit log-transgene"],
 ["2","Error + BLQ","Combined add+prop error; M3 (CENS) for ~17% BLQ in the persistence tail"],
 ["3","Stochastic","IIV on identifiable params (k_g, CC, k_de, k_dm, Fr); IOV across cycles"],
 ["4","Covariates","Pre-specified: LD (primary), saturable dose, process, body size; adjust era/follow-up"],
 ["5","CARVac test","Add on k_g / k_de / k_em; report bounded null + CI; check % -per-cell readout"],
 ["6","Evaluation","GOF, pcVPC stratified by arm/dose/LD, NPDE, bootstrap, identifiability"],
 ["7","Application","Counterfactual sims (LD / dose / CARVac); exposure metrics for E\u2013R & E\u2013safety"]
];
let yy=1.55;
steps.forEach((st,i)=>{
  const c = i<4?TEAL:(i<5?CORAL:DARK);
  s.addShape(p.shapes.OVAL,{x:0.6,y:yy,w:0.62,h:0.62,fill:{color:c}});
  s.addText(st[0],{x:0.6,y:yy,w:0.62,h:0.62,fontFace:HF,fontSize:20,bold:true,color:WHITE,align:"center",valign:"middle"});
  s.addText(st[1],{x:1.45,y:yy-0.02,w:2.6,h:0.66,fontFace:HF,fontSize:15,bold:true,color:DARK,valign:"middle",margin:0});
  s.addText(st[2],{x:4.15,y:yy-0.02,w:8.6,h:0.66,fontFace:BF,fontSize:12.5,color:INK,valign:"middle",margin:0});
  yy+=0.78;
});

/* 12 DELIVERABLES / NEXT */
s=p.addSlide(); s.background={color:DARK};
s.addShape(p.shapes.OVAL,{x:-1.1,y:5.2,w:3.4,h:3.4,fill:{color:CORAL,transparency:82}});
s.addText("Deliverables & next step",{x:0.8,y:0.6,w:11.5,h:0.8,fontFace:HF,fontSize:30,bold:true,color:WHITE});
s.addText([
 {text:"In hand:  ",options:{bold:true,color:TEAL}},
 {text:"NONMEM/Monolix-ready dataset + spec  ·  hypothesis-test metrics (R + Python)  ·  6-panel EDA  ·  this deck",options:{color:"CADCDC"}}
],{x:0.8,y:1.7,w:11.6,h:0.8,fontFace:BF,fontSize:15,valign:"top"});
s.addText([
 {text:"Recommended next:  ",options:{bold:true,color:GOLD}},
 {text:"adjusted multivariable driver analysis (turns the tornado into adjusted effects with CIs \u2014 the manuscript\u2019s central table), then the base-model control stream with the saturable-dose, lymphodepletion, and CARVac-as-covariate terms.",options:{color:WHITE}}
],{x:0.8,y:2.8,w:11.6,h:1.8,fontFace:BF,fontSize:15,valign:"top",lineSpacingMultiple:1.1});
s.addText("Proposed title:  \u201CPopulation cellular kinetics of CLDN6 CAR-T in solid tumors: lymphodepletion-gated, saturable expansion and a bounded null effect of an amplifying RNA vaccine.\u201D",
 {x:0.8,y:4.9,w:11.7,h:1.4,fontFace:BF,fontSize:14,italic:true,color:TEAL,valign:"top"});

p.writeFile({ fileName: "bnt211_poppk/output/BNT211_CART_PopPK_findings.pptx" })
 .then(f=>console.log("saved",f));
