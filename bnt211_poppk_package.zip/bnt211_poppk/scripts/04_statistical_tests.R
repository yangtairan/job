################################################################################
## BNT211 CLDN6 CAR-T -- Formal hypothesis testing (R)
## Group tests, Spearman correlations, multivariable adjusted-driver regression
## + forest plot, event-aligned CARVac test, two-readout concordance.
## NEGATIVE (pre-dose) TIME EXCLUDED.
## requires: dplyr, tidyr, ggplot2, readr, purrr, broom, patchwork, scales
## optional: car (VIF)
################################################################################
library(dplyr); library(tidyr); library(ggplot2); library(readr)
library(purrr); library(broom); library(patchwork); library(scales)

OUT <- "bnt211_poppk"; FIG <- file.path(OUT,"output","figures","final_R"); TAB <- file.path(OUT,"output","tables")
dir.create(FIG, recursive=TRUE, showWarnings=FALSE)
gmean <- function(x){x<-x[!is.na(x)&x>0]; if(length(x)) exp(mean(log(x))) else NA_real_}
NAVY<-"#0F3D4C"; RED<-"#d6604d"; GRY<-"#969696"; BLUE<-"#3182bd"; TEAL<-"#2A9D8F"
PAL <- c(DL0="#c6c6c6",DL1="#9ecae1",`DL1.5`="#6baed6",DL2="#3182bd",DL3="#08519c",DL7="#fb8072",DL8="#e6550d")
theme_set(theme_minimal(base_size=11)+theme(panel.grid.minor=element_blank(),plot.title=element_text(face="bold")))

d <- read_csv(file.path(OUT,"data","poppk_bnt211_carT.csv"), na=".", show_col_types=FALSE)
combo <- d %>% filter(ANALYTE=="RNALPX_DOSE") %>% distinct(USUBJID) %>% pull()
d <- d %>% mutate(ARM=if_else(USUBJID %in% combo,"Combo","Mono")) %>%
  filter(!(EVID==0 & TIME<0))                      # <<< exclude negative time
obs <- d %>% filter(EVID==0)
ord <- intersect(c("DL0","DL1","DL1.5","DL2","DL3","DL7","DL8"), unique(obs$DOSELVL))

## ---- cycle-1 metrics -------------------------------------------------------
slope_log <- function(t,y){m<-!is.na(t)&y>0; if(sum(m)>=3) coef(lm(log(y[m])~t[m]))[2] else NA_real_}
M <- obs %>% filter(!is.na(DOSENUM)) %>% group_by(USUBJID, CYCLE=DOSENUM) %>% group_modify(~{
  g<-.x; q<-filter(g,BLQ==0); if(nrow(q)==0) return(tibble())
  w<-g %>% filter(TAD>=0,TAD<=28) %>% arrange(TAD)
  auc<-if(nrow(w)>1) sum(diff(w$TAD)*(head(w$DV,-1)+tail(w$DV,-1))/2) else NA_real_
  tibble(Cmax=max(q$DV),Tmax=q$TAD[which.max(q$DV)],AUC0_28=auc,
         betaSlope=slope_log(filter(g,TAD>=21,TAD<=90)$TAD, filter(g,TAD>=21,TAD<=90)$DV),
         persist=gmean(filter(g,TAD>=60,TAD<=120)$DV))
}) %>% ungroup() %>%
  left_join(distinct(d,USUBJID,.keep_all=TRUE) %>%
    select(USUBJID,ARM,DOSELVL,CARDOSE,LCARDOSE,REDLDFL,PROCAUTO,TUMTYPE,
           AGE,WEIGHT,BSA,BMI,SEXN), by="USUBJID")
c1 <- filter(M, CYCLE==1)

## ===== group comparison tests (Mann-Whitney / Kruskal-Wallis) ==============
gt_rows <- list()
add_mw <- function(a,b,hyp,metric){a<-a[!is.na(a)];b<-b[!is.na(b)]
  if(length(a)>=3&length(b)>=3){p<-wilcox.test(a,b)$p.value
    gt_rows[[length(gt_rows)+1]]<<-tibble(Hypothesis=hyp,Metric=metric,n1=length(a),n2=length(b),
      GM_ratio=round(gmean(a)/gmean(b),2),Test="Mann-Whitney",p=round(p,4))}}
add_kw <- function(groups,hyp,metric){gs<-Filter(function(g) length(na.omit(g))>=3,groups)
  if(length(gs)>=2){p<-kruskal.test(gs)$p.value
    gt_rows[[length(gt_rows)+1]]<<-tibble(Hypothesis=hyp,Metric=metric,n1=sum(lengths(gs)),n2=NA,
      GM_ratio=NA,Test="Kruskal-Wallis",p=round(p,4))}}
for(m in c("Cmax","AUC0_28","persist")){
  add_mw(c1[[m]][c1$REDLDFL==0], c1[[m]][c1$REDLDFL==1],"LD: standard vs reduced",m)
  add_mw(c1[[m]][c1$PROCAUTO==1],c1[[m]][c1$PROCAUTO==0],"Process: automated vs manual",m)
  add_mw(c1[[m]][c1$SEXN==0],    c1[[m]][c1$SEXN==1],"Sex: male vs female",m)
  add_kw(lapply(c("Ovarian","GCT","Others"),function(t) c1[[m]][c1$TUMTYPE==t]),"Tumor type",m)
  s<-filter(c1,REDLDFL==0,DOSELVL %in% c("DL2","DL3"))
  add_mw(s[[m]][s$ARM=="Mono"], s[[m]][s$ARM=="Combo"],"CARVac mono vs combo (std-LD,DL2/3)",m)
  add_mw(c1[[m]][c1$DOSELVL=="DL2"], c1[[m]][c1$DOSELVL=="DL3"],"Dose saturation: DL2 vs DL3",m)
}
add_kw(lapply(ord, function(dl) c1$Tmax[c1$DOSELVL==dl]),"Tmax across dose levels","Tmax")
group_tests <- bind_rows(gt_rows); write_csv(group_tests, file.path(TAB,"HT_group_tests_R.csv"))

## ===== Spearman: exposure vs continuous covariates =========================
spear <- expand_grid(Metric=c("Cmax","AUC0_28","persist","Tmax"),
                     Covariate=c("AGE","WEIGHT","BMI","BSA","LCARDOSE")) %>%
  pmap_dfr(function(Metric,Covariate){
    x<-c1[[Covariate]]; y<-c1[[Metric]]; ok<-!is.na(x)&!is.na(y)&y>0
    ct<-suppressWarnings(cor.test(x[ok],y[ok],method="spearman"))
    tibble(Metric,Covariate,rho=round(unname(ct$estimate),2),n=sum(ok),p=round(ct$p.value,4))})
write_csv(spear, file.path(TAB,"HT_spearman_R.csv"))

## ===== event-aligned peri-vaccine test =====================================
peri <- map_dfr(split(d,d$USUBJID), function(g){
  vt<-g$TIME[g$ANALYTE=="RNALPX_DOSE"]; ob<-g %>% filter(EVID==0,BLQ==0) %>% select(TIME,DV) %>% arrange(TIME)
  if(length(vt)==0||nrow(ob)<2) return(tibble())
  map_dfr(vt, function(tv){pre<-filter(ob,TIME<tv,TIME>=tv-12); post<-filter(ob,TIME>tv,TIME<=tv+14)
    if(nrow(pre)&&nrow(post)) tibble(phase=if_else(tv<21,"Expansion (<d21)","Maintenance (>=d21)"),
                                     fold=max(post$DV)/tail(pre$DV,1)) else tibble()})})
mt <- filter(peri, phase=="Maintenance (>=d21)")
peri_tests <- tibble(
  Test=c("Maintenance log2FC vs 0 (Wilcoxon signed-rank)","Expansion vs maintenance (Mann-Whitney)"),
  n=c(nrow(mt), nrow(peri)),
  geomean_fold=c(round(gmean(mt$fold),2), round(gmean(filter(peri,phase!="Maintenance (>=d21)")$fold),2)),
  p=c(round(wilcox.test(log2(mt$fold))$p.value,4),
      round(wilcox.test(log2(fold)~phase, data=peri)$p.value,6)))
write_csv(peri_tests, file.path(TAB,"HT_perivaccine_tests_R.csv"))

## ===== multivariable adjusted-driver regression ============================
fit_mv <- function(metric){
  df <- c1 %>% filter(.data[[metric]]>0, !is.na(CARDOSE), !is.na(WEIGHT), !is.na(AGE)) %>%
    mutate(ldv=log(.data[[metric]]), ldose10=log10(CARDOSE), wt10=WEIGHT/10, age10=AGE/10,
           combo=as.integer(ARM=="Combo"), TUM=relevel(factor(TUMTYPE),"Ovarian"))
  m <- lm(ldv ~ ldose10+REDLDFL+PROCAUTO+combo+wt10+age10+SEXN+TUM, data=df)
  tidy(m, conf.int=TRUE) %>% filter(term!="(Intercept)") %>%
    transmute(metric, term, fold=exp(estimate), lo=exp(conf.low), hi=exp(conf.high), p=p.value, n=nrow(df))
}
mv <- bind_rows(fit_mv("Cmax"), fit_mv("persist"))
labs <- c(ldose10="Cell dose (per 10x)", REDLDFL="Reduced LD", PROCAUTO="Automated process",
  combo="+CARVac", wt10="Weight (+10 kg)", age10="Age (+10 y)", SEXN="Female",
  TUMGCT="GCT vs Ovarian", TUMOthers="Others vs Ovarian")
mv <- mv %>% mutate(Predictor=recode(term, !!!labs))
write_csv(mv %>% select(metric,Predictor,fold,lo,hi,p,n), file.path(TAB,"HT_multivariable_R.csv"))
if (requireNamespace("car", quietly=TRUE)){
  dfm <- c1 %>% filter(Cmax>0,!is.na(CARDOSE),!is.na(WEIGHT),!is.na(AGE)) %>%
    mutate(ldose10=log10(CARDOSE),wt10=WEIGHT/10,age10=AGE/10,combo=as.integer(ARM=="Combo"))
  v <- car::vif(lm(log(Cmax)~ldose10+REDLDFL+PROCAUTO+combo+wt10+age10+SEXN, data=dfm))
  write_csv(tibble(term=names(v),VIF=round(as.numeric(v),2)), file.path(TAB,"HT_mv_VIF_R.csv"))
}

## ===== FIGURES =============================================================
## H1 forest
fp <- function(metric){ r<-filter(mv,metric==!!metric) %>% mutate(sig=p<0.05)
  ggplot(r, aes(fold, reorder(Predictor,fold))) +
    geom_vline(xintercept=1, linetype=2) +
    geom_errorbarh(aes(xmin=lo,xmax=hi), height=.2, color=GRY) +
    geom_point(aes(color=sig), size=3) +
    scale_color_manual(values=c(`TRUE`=RED,`FALSE`=NAVY), guide="none") +
    scale_x_log10() + labs(title=paste0(metric," (n=",r$n[1],")"),
                           x="Adjusted fold-change (95% CI)", y=NULL) }
ggsave(file.path(FIG,"H1_forest_adjusted.png"), fp("Cmax")+fp("persist"), width=12, height=5.2, dpi=300)

## H2 spearman heatmap
f2 <- ggplot(spear, aes(Metric, Covariate, fill=rho)) + geom_tile() +
  geom_text(aes(label=paste0(sprintf("%.2f",rho), ifelse(p<0.05,"*","")))) +
  scale_fill_gradient2(low=RED, mid="white", high=BLUE, midpoint=0, limits=c(-.6,.6)) +
  labs(title="Exposure vs covariates (Spearman; * p<0.05)", x=NULL, y=NULL)
ggsave(file.path(FIG,"H2_spearman_heatmap.png"), f2, width=6.2, height=4.6, dpi=300)

## H3 analyte concordance
cc <- obs %>% filter(BLQ==0, PCELL>0) %>% select(DV,PCELL) %>% drop_na()
rho <- suppressWarnings(cor(log(cc$DV), log(cc$PCELL), method="spearman"))
f3 <- ggplot(cc, aes(DV, PCELL)) + geom_point(alpha=.2, color=TEAL, size=1) +
  scale_x_log10() + scale_y_log10() +
  labs(title=sprintf("Two-readout concordance (Spearman rho=%.2f, n=%d)", rho, nrow(cc)),
       x="Transgene (copies/µg DNA)", y="CAR-T per cell (% WPRE/total cells)")
ggsave(file.path(FIG,"H3_analyte_concordance.png"), f3, width=6.5, height=5.5, dpi=300)

## H4 Tmax by dose + expansion-persistence
p4a <- ggplot(c1 %>% mutate(DOSELVL=factor(DOSELVL,ord)), aes(DOSELVL,Tmax,fill=DOSELVL)) +
  geom_boxplot(outlier.shape=NA)+geom_jitter(width=.15,alpha=.4,size=1)+
  scale_fill_manual(values=PAL,guide="none")+labs(title="Time-to-peak by dose",x=NULL,y="Tmax (days)")
pp <- c1 %>% filter(!is.na(Cmax),!is.na(persist))
r2 <- suppressWarnings(cor.test(log(pp$Cmax),log(pp$persist),method="spearman"))
p4b <- ggplot(pp %>% mutate(LD=if_else(REDLDFL==1,"Reduced LD","Standard LD")),
              aes(Cmax,persist,color=LD)) + geom_point(size=2.4,alpha=.7) +
  scale_x_log10()+scale_y_log10()+scale_color_manual(values=c("Standard LD"=BLUE,"Reduced LD"=RED),name=NULL)+
  labs(title=sprintf("Expansion vs persistence (rho=%.2f, p=%.3f)",r2$estimate,r2$p.value),
       x="Cmax", y="Persistence (geo-mean d60-120)")
ggsave(file.path(FIG,"H4_tmax_phenotype.png"), p4a+p4b, width=12, height=5, dpi=300)

pdf(file.path(OUT,"output","Hypothesis_testing_final_R.pdf"), width=11, height=6)
print(fp("Cmax")+fp("persist")); print(f2); print(f3); print(p4a+p4b); dev.off()

print(group_tests); cat("\n"); print(mv %>% filter(metric=="Cmax") %>% select(Predictor,fold,lo,hi,p))
cat("\nDone. Tables in", TAB, "| figures in", FIG, "\n")
