################################################################################
## BNT211 CLDN6 CAR-T -- Hypothesis-driven EDA (R)
## Reproduces per-subject/per-cycle kinetic metrics, the competing-driver
## comparisons, the event-aligned CARVac test, and 6 figures.
## requires: dplyr, tidyr, ggplot2, readr, purrr, patchwork, scales
################################################################################
library(dplyr); library(tidyr); library(ggplot2)
library(readr); library(purrr); library(patchwork); library(scales)

OUT <- "bnt211_poppk"
FIG <- file.path(OUT,"output","figures","eda2_R"); TAB <- file.path(OUT,"output","tables")
dir.create(FIG, recursive=TRUE, showWarnings=FALSE)

gmean <- function(x){x<-x[!is.na(x)&x>0]; if(length(x)) exp(mean(log(x))) else NA_real_}
slope_log <- function(t,y){m<-!is.na(t)&y>0; if(sum(m)>=3) coef(lm(log(y[m])~t[m]))[2] else NA_real_}

## ---- load + define arm (combo = subject ever received RNA-LPX) -------------
d <- read_csv(file.path(OUT,"data","poppk_bnt211_carT.csv"), na=".", show_col_types=FALSE)
combo <- d %>% filter(ANALYTE=="RNALPX_DOSE") %>% distinct(USUBJID) %>% pull()
d  <- d %>% mutate(ARM = if_else(USUBJID %in% combo, "Combo", "Mono"))
obs <- d %>% filter(EVID==0, TIME >= 0)   # exclude negative (pre-dose) time

## ---- per-subject/per-cycle cellular-kinetics metrics ----------------------
M <- obs %>% filter(!is.na(DOSENUM)) %>%
  group_by(USUBJID, CYCLE = DOSENUM) %>% group_modify(~{
    g <- .x; q <- g %>% filter(BLQ==0)
    if(nrow(q)==0) return(tibble())
    w <- g %>% filter(TAD>=0, TAD<=28) %>% arrange(TAD)
    auc <- if(nrow(w)>1) sum(diff(w$TAD)*(head(w$DV,-1)+tail(w$DV,-1))/2) else NA_real_
    bb <- g %>% filter(TAD>=21, TAD<=90)
    pr <- g %>% filter(TAD>=60, TAD<=120)
    tibble(Cmax=max(q$DV), Tmax=q$TAD[which.max(q$DV)], AUC0_28=auc,
           betaSlope=slope_log(bb$TAD, bb$DV), persist=gmean(pr$DV), nq=nrow(q))
  }) %>% ungroup()

cov <- d %>% distinct(USUBJID, .keep_all=TRUE) %>%
  select(USUBJID, ARM, DOSELVL, CARDOSE, REDLDFL, PROCAUTO, TUMTYPE, REDOSEFL, AGE, SEXN)
M <- left_join(M, cov, by="USUBJID")
write_csv(M, file.path(TAB,"hypothesis_metrics_R.csv"))
c1 <- M %>% filter(CYCLE==1)

## ---- competing-driver comparisons (printed) -------------------------------
cat("\n== H1 dose-exposure saturation ==\n")
c1 %>% group_by(DOSELVL) %>%
  summarise(dose=median(CARDOSE), Cmax_gm=gmean(Cmax), AUC_gm=gmean(AUC0_28), n=n()) %>% print()
cat("\n== H2 lymphodepletion (standard=0 vs reduced=1) ==\n")
c1 %>% group_by(REDLDFL) %>%
  summarise(n=n(), Cmax_gm=gmean(Cmax), persist_gm=gmean(persist), AUC_gm=gmean(AUC0_28)) %>% print()
cat("\n== H3 CARVac mono vs combo within standard-LD, DL2/DL3 ==\n")
c1 %>% filter(REDLDFL==0, DOSELVL %in% c("DL2","DL3")) %>% group_by(ARM) %>%
  summarise(n=n(), Cmax_gm=gmean(Cmax), AUC_gm=gmean(AUC0_28), persist_gm=gmean(persist)) %>% print()

## ---- event-aligned peri-vaccine fold-change (early vs maintenance) --------
peri <- map_dfr(split(d, d$USUBJID), function(g){
  vt <- g$TIME[g$ANALYTE=="RNALPX_DOSE"]
  ob <- g %>% filter(EVID==0, BLQ==0) %>% select(TIME, DV) %>% arrange(TIME)
  if(length(vt)==0 || nrow(ob)<2) return(tibble())
  map_dfr(vt, function(tv){
    pre <- ob %>% filter(TIME<tv, TIME>=tv-12); post <- ob %>% filter(TIME>tv, TIME<=tv+14)
    if(nrow(pre)>0 && nrow(post)>0)
      tibble(phase=if_else(tv<21,"Expansion (<d21)","Maintenance (>=d21)"),
             fold=max(post$DV)/tail(pre$DV,1)) else tibble()
  })
})
cat("\n== Peri-vaccine fold-change ==\n")
peri %>% group_by(phase) %>%
  summarise(n=n(), geomean=gmean(fold), median=median(fold), pct_up=mean(fold>1.5)) %>% print()

## ============================ FIGURES ======================================
BLUE<-"#3182bd"; RED<-"#d6604d"; GRY<-"#969696"; PUR<-"#807dba"
theme_set(theme_minimal(base_size=11)+theme(panel.grid.minor=element_blank(),
          plot.title=element_text(face="bold")))

## F1 driver tornado
drivers <- tribble(~lab,~mask,
  "Dose >=1e8 vs <1e8", c1$CARDOSE>=1e8,
  "Standard vs reduced LD", c1$REDLDFL==0,
  "Automated vs manual process", c1$PROCAUTO==1,
  "+CARVac vs mono", c1$ARM=="Combo",
  "Ovarian/Other vs GCT", c1$TUMTYPE %in% c("Ovarian","Others"),
  "Female vs male", c1$SEXN==1,
  "Age <median vs >=median", c1$AGE<median(c1$AGE,na.rm=TRUE))
eff <- function(metric) drivers %>% rowwise() %>%
  mutate(l2=log2(gmean(c1[[metric]][mask])/gmean(c1[[metric]][!mask]))) %>% ungroup()
mk_tor <- function(metric,ttl){ e<-eff(metric) %>% arrange(desc(abs(l2)))
  ggplot(e, aes(reorder(lab,abs(l2)), l2,
               fill=cut(abs(l2),c(-1,.4,1,Inf),labels=c("g","b","r")))) +
    geom_col() + coord_flip() + geom_hline(yintercept=0) +
    scale_fill_manual(values=c(g=GRY,b=BLUE,r=RED), guide="none") +
    labs(title=ttl, x=NULL, y="log2 fold-change in geo-mean") }
f1 <- mk_tor("Cmax","Peak expansion (Cmax)") + mk_tor("persist","Persistence (d60-120)")
ggsave(file.path(FIG,"F1_driver_tornado.png"), f1, width=12, height=5, dpi=300)

## F2 dose-exposure saturation
f2dat <- c1 %>% mutate(LD=if_else(REDLDFL==1,"Reduced LD","Standard LD"))
med <- c1 %>% group_by(CARDOSE) %>% summarise(Cmax=gmean(Cmax), AUC0_28=gmean(AUC0_28))
f2 <- ggplot(f2dat, aes(CARDOSE, Cmax)) +
  geom_jitter(aes(color=LD), width=.05, height=0, size=2, alpha=.6) +
  geom_line(data=med, color="black") + geom_point(data=med, color="black") +
  geom_vline(xintercept=1e8, linetype=3, color=GRY) +
  scale_x_log10() + scale_y_log10(labels=label_number(scale_cut=cut_short_scale())) +
  scale_color_manual(values=c("Standard LD"=BLUE,"Reduced LD"=RED), name=NULL) +
  labs(title="Dose-exposure saturates above ~1e8 cells",
       x="CAR-T cell dose", y="Cmax (copies/µg DNA)")
ggsave(file.path(FIG,"F2_dose_saturation.png"), f2, width=8, height=5, dpi=300)

## F3 lymphodepletion profiles + box
prof <- obs %>% filter(DOSENUM==1) %>%
  mutate(LD=if_else(REDLDFL==1,"Reduced LD","Standard LD"),
         nb=cut(TAD,c(-1,2,4,8,15,22,30,45,60,90,135,200))) %>%
  group_by(LD,nb) %>% summarise(t=median(TAD), dv=gmean(DV), n=n(), .groups="drop") %>% filter(n>=3)
p3a <- ggplot(prof, aes(t,dv,color=LD)) + geom_line() + geom_point() +
  scale_y_log10() + geom_hline(yintercept=14,linetype=2) +
  scale_color_manual(values=c("Standard LD"=BLUE,"Reduced LD"=RED), name=NULL) +
  labs(title="Profile by lymphodepletion", x="Days since CAR-T", y="Geo-mean transgene")
p3b <- ggplot(c1 %>% mutate(LD=if_else(REDLDFL==1,"Reduced","Standard")),
              aes(LD,Cmax,fill=LD)) + geom_boxplot(outlier.shape=NA) +
  geom_jitter(width=.15,alpha=.4,size=1) + scale_y_log10() +
  scale_fill_manual(values=c("Standard"=BLUE,"Reduced"=RED), guide="none") +
  labs(title="Peak expansion by LD", x=NULL, y="Cmax")
ggsave(file.path(FIG,"F3_lymphodepletion.png"), p3a+p3b, width=12, height=5, dpi=300)

## F4 event-aligned CARVac (fold-change distributions)
f4 <- ggplot(peri, aes(log2(fold), fill=phase)) +
  geom_histogram(position="identity", alpha=.6, bins=25) +
  geom_vline(xintercept=0, linetype=2) +
  scale_fill_manual(values=c("Maintenance (>=d21)"=BLUE,"Expansion (<d21)"=RED), name=NULL) +
  labs(title="Event-aligned CARVac test: maintenance doses centre on no effect",
       x="log2(post-vaccine max / pre-vaccine)", y="events")
ggsave(file.path(FIG,"F4_perivaccine.png"), f4, width=9, height=5, dpi=300)

## F5 mono vs combo (standard-LD, dose-matched)
f5dat <- c1 %>% filter(REDLDFL==0, DOSELVL %in% c("DL2","DL3")) %>%
  select(ARM,Cmax,AUC0_28,persist) %>% pivot_longer(-ARM)
f5 <- ggplot(f5dat, aes(ARM,value,fill=ARM)) + geom_boxplot(outlier.shape=NA) +
  geom_jitter(width=.15,alpha=.4,size=1) + facet_wrap(~name, scales="free_y") +
  scale_y_log10() + scale_fill_manual(values=c("Mono"=GRY,"Combo"=PUR), guide="none") +
  labs(title="CARVac vs mono (standard-LD, DL2/DL3): no expansion gain; persistence confounded",
       x=NULL, y=NULL)
ggsave(file.path(FIG,"F5_carvac_matched.png"), f5, width=11, height=4.5, dpi=300)

## F6 expansion-persistence phenotype map
f6 <- ggplot(c1 %>% filter(!is.na(Cmax),!is.na(persist)) %>%
               mutate(LD=if_else(REDLDFL==1,"Reduced LD","Standard LD")),
             aes(Cmax,persist,color=LD)) +
  geom_point(size=2.6, alpha=.7) +
  geom_vline(xintercept=median(c1$Cmax,na.rm=T),linetype=3,color=GRY) +
  geom_hline(yintercept=median(c1$persist,na.rm=T),linetype=3,color=GRY) +
  scale_x_log10() + scale_y_log10() +
  scale_color_manual(values=c("Standard LD"=BLUE,"Reduced LD"=RED), name=NULL) +
  labs(title="Expansion-persistence phenotype map",
       x="Cmax (peak expansion)", y="Persistence (geo-mean d60-120)")
ggsave(file.path(FIG,"F6_phenotype_map.png"), f6, width=8, height=6.5, dpi=300)

pdf(file.path(OUT,"output","EDA2_hypothesis_tests_R.pdf"), width=11, height=6)
print(f1); print(f2); print(p3a+p3b); print(f4); print(f5); print(f6); dev.off()
cat("\nDone: figures in", FIG, "\n")
