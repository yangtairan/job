################################################################################
## BNT211 CLDN6 CAR-T  ---  PopPK / cellular-kinetics modeling dataset builder
##
## Reads SDTM/ADaM (dm, ex, adpc, adsl) -> NONMEM/Monolix-ready dataset.
## Design follows the CAR-T cellular-kinetics framework (Stein et al. 2019,
## CPT:PSP 8:285-295) adapted for the BNT211 CAR-T + CLDN6 RNA-LPX (CARVac)
## re-stimulation design:
##   - DV  = transgene WPRE copies / ug genomic DNA (qPCR)  [primary endpoint]
##   - CAR-T infusion  -> dosing event, CMT 1 (AMT = transduced CAR+ cells)
##   - RNA-LPX vaccine -> dosing event, CMT 2 (AMT = ug)    [drives re-expansion]
##   - BLQ kept with CENS=1, DV set to LLOQ (M3-ready)
##   - continuous TIME (days) from first CAR-T infusion; TAD, TPV, NVAC derived
##
## Author: (you)   |   requires: haven, dplyr, tidyr, stringr, lubridate, readr
################################################################################

library(haven); library(dplyr); library(tidyr)
library(stringr); library(lubridate); library(readr)

UP  <- "/mnt/user-data/uploads"          # <-- edit to your path
OUT <- "bnt211_poppk"
dir.create(file.path(OUT,"data"), recursive = TRUE, showWarnings = FALSE)

adsl <- read_sas(file.path(UP,"adsl.sas7bdat"))
adpc <- read_sas(file.path(UP,"adpc.sas7bdat"))
ex   <- read_sas(file.path(UP,"ex__1_.sas7bdat"))

## ---------------------------------------------------------------------------
## 1. Parse actual CAR-T cell dose from ACTDOS text ("1X10^8","2-5X10^8 (2X10^8)")
## ---------------------------------------------------------------------------
parse_cells <- function(txt){
  if (is.na(txt) || str_trim(txt)=="") return(NA_real_)
  t <- toupper(gsub(" ","",txt))
  m <- str_match(t,"\\(([^)]+)\\)"); core <- if(!is.na(m[,2])) m[,2] else t
  core <- gsub("OTHER:","",core)
  a <- str_match(core,"([0-9.]+)X10\\^?([0-9]+)")
  if (!is.na(a[,2])) return(as.numeric(a[,2])*10^as.numeric(a[,3]))
  b <- str_match(core,"([0-9.]+)E\\+?([0-9]+)")
  if (!is.na(b[,2])) return(as.numeric(b[,2])*10^as.numeric(b[,3]))
  NA_real_
}
DL_CELLS <- c(DL0=1e6,DL1=1e7,`DL1.5`=5e7,DL2=1e8,DL3=2e8,DL7=1e8,DL8=1e8)

## ---------------------------------------------------------------------------
## 2. Subject-level covariates (treated subjects = received CAR-T)
## ---------------------------------------------------------------------------
cov <- adsl %>% filter(!is.na(FCARTDT)) %>%
  transmute(USUBJID, STUDYID, AGE,
            SEX, SEXN = as.integer(SEX=="F"),
            RACE, WEIGHT, HEIGHT, BMI, BSA,
            ECOGN = suppressWarnings(as.numeric(ECOG)),
            TUMTYPE = na_if(TUMLCAT,""),
            DOSELVL, DOSELVLN,
            LDLVLN  = suppressWarnings(as.numeric(gsub("%","",LDPCTLVL))),
            REDLDFL = as.integer(PWRLYMP=="Y"),
            REDOSEFL= as.integer(R01DOSFL=="Y"),
            PROCAUTO= as.integer(MNFTPR1=="Automated Process"),
            VACSCHN = case_when(str_detect(VACCSCH,"SCHEDULE 1")~1,
                                str_detect(VACCSCH,"SCHEDULE 2")~2, TRUE~NA_real_),
            COUNTRY, SITEID,
            ACTDOS_1, ACTDOS_2, ACTDOS_3) %>%
  mutate(ID = as.integer(factor(USUBJID, levels=unique(USUBJID))))

## ---------------------------------------------------------------------------
## 3. Dosing events from EX  (CAR-T -> CMT 1 ; RNA-LPX -> CMT 2)
## ---------------------------------------------------------------------------
ex <- ex %>% filter(USUBJID %in% cov$USUBJID) %>%
  mutate(DTM = ymd_hm(EXSTDTC, quiet=TRUE))

t0 <- ex %>% filter(EXTRT=="CLDN6 CAR-T") %>%
  group_by(USUBJID) %>% summarise(T0 = min(DTM, na.rm=TRUE), .groups="drop")
cov <- left_join(cov, t0, by="USUBJID")

cart_doses <- ex %>% filter(EXTRT=="CLDN6 CAR-T") %>% arrange(USUBJID, DTM) %>%
  group_by(USUBJID) %>% mutate(seq=row_number()) %>% ungroup() %>%
  left_join(cov %>% select(USUBJID,DOSELVL,ACTDOS_1,ACTDOS_2,ACTDOS_3), by="USUBJID") %>%
  rowwise() %>%
  mutate(AMT = { a <- parse_cells(get(paste0("ACTDOS_",min(seq,3))))
                 if (is.na(a)) a <- unname(DL_CELLS[DOSELVL]); a }) %>%
  ungroup() %>%
  transmute(USUBJID, DTM, EVID=1L, CMT=1L, AMT, DOSENUM=seq, ANALYTE="CART_DOSE")

lpx_doses <- ex %>% filter(EXTRT=="CLDN6 RNA-LPX") %>% arrange(USUBJID, DTM) %>%
  transmute(USUBJID, DTM, EVID=1L, CMT=2L, AMT=EXDOSE,
            DOSENUM=NA_integer_, ANALYTE="RNALPX_DOSE")

dose <- bind_rows(cart_doses, lpx_doses)

## ---------------------------------------------------------------------------
## 4. Observation events from ADPC (transgene copies/ug DNA = primary DV)
## ---------------------------------------------------------------------------
nca <- adpc %>% filter(PARAMCD=="NCACONC")
perdna  <- nca %>% filter(ANALYT=="CAR-T Gene Per DNA")
percell <- nca %>% filter(ANALYT=="CAR-T Gene Per Cell") %>%
  transmute(USUBJID, AVISIT, DAFD, PCELL=AVAL, PCELL_LLOQ=PCLLOQ)

obs <- perdna %>%
  mutate(DTM = if_else(!is.na(PCDTC) & PCDTC!="",
                       ymd_hm(PCDTC, quiet=TRUE),
                       ymd_hms(paste(ADT, ATM), quiet=TRUE))) %>%
  filter(PCSTAT!="NOT DONE", !is.na(DTM), !is.na(AVAL)) %>%
  left_join(percell, by=c("USUBJID","AVISIT","DAFD")) %>%
  mutate(LLOQ = PCLLOQ,
         BLQ  = as.integer(AVAL==0 | (!is.na(LLOQ) & AVAL<LLOQ)),
         DV   = if_else(BLQ==1 & !is.na(LLOQ), LLOQ, AVAL)) %>%
  transmute(USUBJID, DTM, EVID=0L, CMT=1L, AMT=NA_real_, DV, LLOQ,
            BLQ, CENS=BLQ, DOSENUM, ANALYTE="TRANSGENE_perDNA",
            AVISIT, NDAY, PCELL, PCELL_LLOQ)

## ---------------------------------------------------------------------------
## 5. Combine + continuous TIME (days from first CAR-T) + TAD/TPV/NVAC
## ---------------------------------------------------------------------------
allev <- bind_rows(dose, obs) %>%
  inner_join(cov %>% select(USUBJID, ID, T0), by="USUBJID") %>%
  mutate(TIME = as.numeric(difftime(DTM, T0, units="days")),
         ord  = if_else(EVID==1L, 0L, 1L)) %>%
  arrange(ID, TIME, ord) %>%
  group_by(ID) %>%
  mutate(
    last_cart = { v <- if_else(EVID==1L & CMT==1L, TIME, NA_real_)
                  Reduce(function(a,b) if(is.na(b)) a else b, v, accumulate=TRUE) },
    last_vac  = { v <- if_else(EVID==1L & CMT==2L, TIME, NA_real_)
                  Reduce(function(a,b) if(is.na(b)) a else b, v, accumulate=TRUE) },
    NVAC      = cumsum(EVID==1L & CMT==2L),
    TAD       = TIME - last_cart,
    TPV       = TIME - last_vac) %>%
  ungroup() %>% select(-last_cart,-last_vac,-ord)

## ---------------------------------------------------------------------------
## 6. Merge covariates + housekeeping + write
## ---------------------------------------------------------------------------
cart_first <- dose %>% filter(CMT==1L) %>% arrange(USUBJID, DTM) %>%
  group_by(USUBJID) %>% summarise(CARDOSE=first(AMT), .groups="drop")

df <- allev %>%
  left_join(cov %>% select(-T0,-starts_with("ACTDOS")), by=c("USUBJID","ID")) %>%
  left_join(cart_first, by="USUBJID") %>%
  mutate(LCARDOSE = log10(CARDOSE),
         MDV  = if_else(EVID==1L, 1L, if_else(is.na(DV),1L,0L)),
         RATE = 0L,
         LNDV = if_else(EVID==0L & DV>0, log(DV), NA_real_),
         PREDOSE = as.integer(EVID==0L & TIME<0),
         C = if_else(PREDOSE==1L, "C", ".")) %>%
  mutate(across(c(TIME,TAD,TPV), ~round(.x,4)),
         DV=round(DV,4), LNDV=round(LNDV,5))

final_cols <- c("C","ID","USUBJID","STUDYID","TIME","TAD","NDAY","AVISIT",
  "DV","LNDV","LLOQ","BLQ","CENS","MDV","EVID","CMT","AMT","RATE",
  "DOSENUM","NVAC","TPV","ANALYTE","PCELL","PCELL_LLOQ",
  "CARDOSE","LCARDOSE","DOSELVL","DOSELVLN","VACSCHN",
  "AGE","SEXN","SEX","RACE","WEIGHT","HEIGHT","BMI","BSA","ECOGN",
  "TUMTYPE","LDLVLN","REDLDFL","REDOSEFL","PROCAUTO","COUNTRY","SITEID")

df <- df %>% select(all_of(final_cols))
write_csv(df, file.path(OUT,"data","poppk_bnt211_carT.csv"), na=".")

cat("Rows:", nrow(df), "| Subjects:", n_distinct(df$ID), "\n")
cat("Obs:", sum(df$EVID==0), "| CAR-T doses:", sum(df$EVID==1 & df$CMT==1),
    "| Vaccine doses:", sum(df$EVID==1 & df$CMT==2), "\n")
cat("BLQ obs:", sum(df$BLQ[df$EVID==0], na.rm=TRUE), "\n")
