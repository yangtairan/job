################################################################################
## BNT211 CLDN6 CAR-T  ---  Exploratory Data Analysis of the PopPK dataset
## Produces summary tables (CSV) and publication-style figures (PNG + PDF).
## requires: dplyr, tidyr, ggplot2, readr, scales, patchwork
################################################################################

library(dplyr); library(tidyr); library(ggplot2)
library(readr); library(scales); library(patchwork)

OUT <- "bnt211_poppk"
FIG <- file.path(OUT,"output","figures"); TAB <- file.path(OUT,"output","tables")
dir.create(FIG, recursive=TRUE, showWarnings=FALSE)
dir.create(TAB, recursive=TRUE, showWarnings=FALSE)

d   <- read_csv(file.path(OUT,"data","poppk_bnt211_carT.csv"), na=".",
                show_col_types=FALSE)
obs <- d %>% filter(EVID==0, TIME >= 0)   # exclude negative (pre-dose) time
sub <- d %>% distinct(ID, .keep_all=TRUE)
LLOQ <- 14

gmean <- function(x){x<-x[!is.na(x)&x>0]; if(length(x)) exp(mean(log(x))) else NA_real_}
PAL <- c(DL0="#c6c6c6",DL1="#9ecae1",`DL1.5`="#6baed6",DL2="#3182bd",
         DL3="#08519c",DL7="#fb8072",DL8="#e6550d")
ord <- intersect(c("DL0","DL1","DL1.5","DL2","DL3","DL7","DL8"), unique(sub$DOSELVL))
theme_set(theme_minimal(base_size=11) +
  theme(panel.grid.minor=element_blank(),
        plot.title=element_text(face="bold")))

## ============================ TABLES =======================================
## T1 data inventory
inv <- tibble(
  Metric=c("Subjects (treated)","CAR-T infusion events","RNA-LPX (CARVac) events",
           "Transgene observations (per-DNA)","  quantifiable (>=LLOQ)","  BLQ (CENS=1)",
           "Pre-dose obs (flagged C)","Re-dosed subjects","Dose levels"),
  Value=c(n_distinct(d$ID), sum(d$EVID==1&d$CMT==1), sum(d$EVID==1&d$CMT==2),
          nrow(obs), sum(obs$BLQ==0), sum(obs$BLQ==1),
          sum(d$C=="C"), sum(sub$REDOSEFL), n_distinct(sub$DOSELVL)))
write_csv(inv, file.path(TAB,"T1_data_inventory.csv"))

## T2 demographics by dose level
smry <- function(x){x<-as.numeric(x); sprintf("%.1f (%.1f-%.1f)",median(x,na.rm=T),
                     min(x,na.rm=T),max(x,na.rm=T))}
demo <- sub %>% group_by(DOSELVL) %>% summarise(
  N=n(), `Cell dose`=sprintf("%.2g",median(CARDOSE,na.rm=T)),
  `Age (y)`=smry(AGE), `Female n(%)`=sprintf("%d (%.0f)",sum(SEXN),100*mean(SEXN)),
  `Weight (kg)`=smry(WEIGHT), BMI=smry(BMI), BSA=smry(BSA),
  `ECOG med`=sprintf("%.0f",median(ECOGN,na.rm=T)),
  `Reduced LD n`=sum(REDLDFL,na.rm=T), .groups="drop")
write_csv(demo, file.path(TAB,"T2_demographics_by_doselevel.csv"))

## T3 obs/BLQ by time bin
obs <- obs %>% mutate(DAYBIN=cut(NDAY,c(-1,0,7,14,28,56,90,180,365,1000),
   labels=c("<=0","1-7","8-14","15-28","29-56","57-90","91-180","181-365",">365")))
t3 <- obs %>% group_by(DAYBIN) %>% summarise(N_obs=n(), N_BLQ=sum(BLQ),
   GeoMean_DV=gmean(DV), Median_DV=median(DV,na.rm=T), Max_DV=max(DV,na.rm=T),
   BLQ_pct=round(100*mean(BLQ),1), .groups="drop")
write_csv(t3, file.path(TAB,"T3_obs_blq_by_time.csv"))

## T4 per-subject cellular kinetics (cycle 1) + by-dose summary
nca <- obs %>% filter(DOSENUM==1) %>% group_by(ID) %>% group_modify(~{
  g<-.x; q<-g %>% filter(BLQ==0); if(nrow(q)==0) return(tibble())
  g28<-g %>% filter(TIME>=0,TIME<=28) %>% arrange(TIME)
  auc<-if(nrow(g28)>1) sum(diff(g28$TIME)*(head(g28$DV,-1)+tail(g28$DV,-1))/2) else NA_real_
  tibble(DOSELVL=g$DOSELVL[1], Cmax=max(q$DV), Tmax=q$TIME[which.max(q$DV)],
         Tlast=max(q$TIME), AUC0_28=auc, Npts=nrow(q))}) %>% ungroup()
write_csv(nca, file.path(TAB,"T4_cellkinetics_per_subject.csv"))
t4b <- nca %>% group_by(DOSELVL) %>% summarise(N=n(), Cmax_gm=gmean(Cmax),
   Tmax_med=median(Tmax,na.rm=T), AUC0_28_gm=gmean(AUC0_28),
   Tlast_med=median(Tlast,na.rm=T), .groups="drop")
write_csv(t4b, file.path(TAB,"T4b_cellkinetics_by_doselevel.csv"))

## ============================ FIGURES ======================================
obs <- obs %>% mutate(DOSELVL=factor(DOSELVL,levels=ord),
                      DVc=pmax(DV,LLOQ))

## F1 individual semi-log spaghetti
f1 <- ggplot(obs, aes(TIME, DVc, group=ID, color=DOSELVL)) +
  geom_line(alpha=0.5, linewidth=0.3) +
  geom_hline(yintercept=LLOQ, linetype=2) +
  scale_y_log10(labels=label_number(scale_cut=cut_short_scale())) +
  scale_color_manual(values=PAL, name="Dose level") +
  coord_cartesian(xlim=c(-5,200)) +
  labs(title="Individual CLDN6 CAR-T transgene profiles (semi-log)",
       x="Time since first CAR-T infusion (days)",
       y="Transgene (WPRE copies/µg DNA)")
ggsave(file.path(FIG,"F1_spaghetti_semilog.png"), f1, width=9, height=5.5, dpi=300)

## F2 geometric-mean expansion-contraction by dose
gm <- obs %>% mutate(NDB=cut(NDAY,c(-1,0,2,4,8,15,22,30,45,60,90,135,180,300))) %>%
  group_by(DOSELVL,NDB) %>% summarise(t=median(NDAY),dv=gmean(DV),n=n(),.groups="drop") %>%
  filter(n>=3)
f2 <- ggplot(gm, aes(t, dv, color=DOSELVL)) +
  geom_line() + geom_point(size=1.6) +
  geom_hline(yintercept=LLOQ, linetype=2) +
  scale_y_log10(labels=label_number(scale_cut=cut_short_scale())) +
  scale_color_manual(values=PAL, name="Dose level") +
  coord_cartesian(xlim=c(-5,150)) +
  labs(title="Mean transgene expansion–contraction by dose level",
       x="Nominal day", y="Geometric-mean transgene (copies/µg DNA)")
ggsave(file.path(FIG,"F2_geomean_by_dose.png"), f2, width=9, height=5.5, dpi=300)

## F3 BLQ fraction over time
b3 <- obs %>% group_by(DAYBIN) %>% summarise(pct=100*mean(BLQ), n=n(), .groups="drop")
f3 <- ggplot(b3, aes(DAYBIN, pct)) +
  geom_col(fill="#3182bd") + geom_text(aes(label=paste0("n=",n)), vjust=-0.4, size=3) +
  labs(title="Below-quantification fraction over time", x="Nominal day bin", y="% BLQ") +
  theme(axis.text.x=element_text(angle=45, hjust=1))
ggsave(file.path(FIG,"F3_blq_over_time.png"), f3, width=9, height=4.5, dpi=300)

## F4 covariate distributions
covlong <- sub %>% select(AGE,WEIGHT,BMI,BSA,LCARDOSE,ECOGN) %>%
  pivot_longer(everything())
f4 <- ggplot(covlong, aes(value)) +
  geom_histogram(bins=15, fill="#6baed6", color="white") +
  facet_wrap(~name, scales="free") +
  labs(title="Baseline covariate distributions", x=NULL, y="subjects")
ggsave(file.path(FIG,"F4_covariate_distributions.png"), f4, width=11, height=6.5, dpi=300)

## F5 covariate correlation heatmap
cc <- c("AGE","WEIGHT","HEIGHT","BMI","BSA","LCARDOSE","ECOGN")
M <- cor(sub[cc], use="pairwise.complete.obs")
f5 <- as.data.frame(as.table(M)) %>%
  ggplot(aes(Var1,Var2,fill=Freq)) + geom_tile() +
  geom_text(aes(label=sprintf("%.2f",Freq)), size=3) +
  scale_fill_gradient2(low="#b2182b",mid="white",high="#2166ac",limits=c(-1,1),name="r") +
  labs(title="Continuous covariate correlations", x=NULL, y=NULL) +
  theme(axis.text.x=element_text(angle=45,hjust=1))
ggsave(file.path(FIG,"F5_covariate_correlation.png"), f5, width=6.5, height=5.5, dpi=300)

## F6 dose-exposure (Cmax, Tmax)
nca <- nca %>% mutate(DOSELVL=factor(DOSELVL,levels=ord))
f6a <- ggplot(nca, aes(DOSELVL,Cmax,fill=DOSELVL)) +
  geom_boxplot(outlier.shape=NA) + geom_jitter(width=0.15,size=1,alpha=0.5) +
  scale_y_log10(labels=label_number(scale_cut=cut_short_scale())) +
  scale_fill_manual(values=PAL,guide="none") +
  labs(title="Peak expansion (Cmax) by dose", x="Dose level", y="Cmax (copies/µg DNA)")
f6b <- ggplot(nca, aes(DOSELVL,Tmax,fill=DOSELVL)) +
  geom_boxplot(outlier.shape=NA) + geom_jitter(width=0.15,size=1,alpha=0.5) +
  scale_fill_manual(values=PAL,guide="none") +
  labs(title="Time to peak (Tmax) by dose", x="Dose level", y="Tmax (days)")
ggsave(file.path(FIG,"F6_dose_exposure.png"), f6a+f6b, width=11, height=5, dpi=300)

## F7 sampling map
sm <- obs %>% left_join(sub %>% select(ID,DOSELVLN), by="ID") %>%
  arrange(DOSELVLN,ID) %>% mutate(row=as.integer(factor(ID,levels=unique(ID))))
f7 <- ggplot(sm, aes(TIME,row,color=DOSELVL,shape=factor(BLQ))) +
  geom_point(size=0.8) +
  scale_color_manual(values=PAL,name="Dose level") +
  scale_shape_manual(values=c(`0`=16,`1`=4),name="BLQ") +
  coord_cartesian(xlim=c(-5,200)) +
  labs(title="Sampling map (× = BLQ)", x="Time since first CAR-T (days)",
       y="Subject (sorted by dose level)")
ggsave(file.path(FIG,"F7_sampling_map.png"), f7, width=9, height=7, dpi=300)

## combined PDF
pdf(file.path(OUT,"output","EDA_report_figures.pdf"), width=10, height=6.5)
print(f1); print(f2); print(f3); print(f4); print(f5); print(f6a+f6b); print(f7)
dev.off()

cat("EDA complete: tables in output/tables, figures in output/figures\n")
