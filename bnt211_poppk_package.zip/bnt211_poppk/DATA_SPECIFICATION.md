# BNT211 CLDN6 CAR-T — PopPK / Cellular-Kinetics Dataset Specification

**File:** `data/poppk_bnt211_carT.csv`
**Primary endpoint (DV):** CLDN6 CAR-T transgene = WPRE copies per µg genomic DNA (qPCR)
**Structure:** one row per dosing or observation event; missing = `.` (NONMEM-ready)
**Time unit:** days from each subject's first CAR-T infusion

## Design basis

This dataset supports an empirical **cellular-kinetics expansion–contraction** analysis rather
than a classical compartmental PK model, because the infused product expands *in vivo* to a peak
and then contracts biphasically. Variable conventions follow published CAR-T cellular-kinetics
models, adapted for the BNT211 CAR-T + CLDN6 RNA-LPX (CARVac) re-stimulation design:

- **Stein et al. 2019**, *CPT:PSP* 8:285–295 — tisagenlecleucel expansion–contraction model
  (parameters Cmax, Tmax, ρ, α, β, FB; DV = transgene copies/µg DNA; LLOQ-based BLQ handling).
- **Liu et al. 2020**, *Clin Pharmacol Ther* 109:716–727 — model-based CAR-T cellular kinetics in humans.
- **Singh et al. 2021**, *CPT:PSP* 10:362–376 — anti-BCMA multiscale CAR-T PK/PD.

## Event coding

| EVID | CMT | Meaning | AMT |
|------|-----|---------|-----|
| 1 | 1 | CAR-T infusion | transduced CAR+ cells |
| 1 | 2 | CLDN6 RNA-LPX (CARVac) vaccine dose | µg |
| 0 | 1 | Transgene observation (copies/µg DNA) | . |

## Column dictionary

| Variable | Type | Description |
|----------|------|-------------|
| C | char | `C` flags pre-first-dose observations to drop in estimation; else `.` |
| ID | num | Sequential numeric subject ID |
| USUBJID | char | Unique subject identifier |
| STUDYID | char | Study identifier |
| TIME | num | Time (days) from first CAR-T infusion (continuous across re-dose cycles) |
| TAD | num | Time (days) since most recent CAR-T infusion |
| NDAY | num | Nominal day after dose (from ADPC) |
| AVISIT | char | Analysis visit label |
| DV | num | Observed transgene (copies/µg DNA); BLQ set to LLOQ |
| LNDV | num | Natural log of DV (quantifiable records only) |
| LLOQ | num | Assay lower limit of quantitation for the record |
| BLQ | 0/1 | 1 = below limit of quantitation |
| CENS | 0/1 | Censoring flag for M3-type likelihood (= BLQ) |
| MDV | 0/1 | Missing dependent value (1 for doses / missing obs) |
| EVID | 0/1 | Event ID (0 = obs, 1 = dose) |
| CMT | int | Compartment (1 = CAR-T/transgene, 2 = RNA-LPX vaccine) |
| AMT | num | Dose amount (cells for CAR-T; µg for vaccine) |
| RATE | num | Infusion rate (0 = bolus default; set for zero-order input if modeled) |
| DOSENUM | int | CAR-T dose sequence number (1 = first infusion) |
| NVAC | int | Cumulative number of RNA-LPX vaccine doses to date |
| TPV | num | Time (days) since most recent vaccine dose (re-stimulation clock) |
| ANALYTE | char | Record type: TRANSGENE_perDNA / CART_DOSE / RNALPX_DOSE |
| PCELL | num | Paired flow readout (% WPRE copies per total cells), reference only |
| PCELL_LLOQ | num | LLOQ for the paired % readout |
| CARDOSE | num | First CAR-T cell dose (covariate, cells) |
| LCARDOSE | num | log10 of CARDOSE |
| DOSELVL / DOSELVLN | char/num | Dose-level cohort (DL0–DL8) |
| VACSCHN | num | Vaccination schedule (1 or 2) |
| AGE | num | Age (years) |
| SEXN / SEX | num/char | Sex (0 = M, 1 = F) / character |
| RACE | char | Race |
| WEIGHT, HEIGHT, BMI, BSA | num | Baseline body-size covariates |
| ECOGN | num | Baseline ECOG performance status |
| TUMTYPE | char | Tumor location category (Ovarian / GCT / Others) |
| LDLVLN | num | Lymphodepletion intensity (% of standard) |
| REDLDFL | 0/1 | Reduced / without lymphodepletion |
| REDOSEFL | 0/1 | Subject received ≥1 CAR-T re-dose |
| PROCAUTO | 0/1 | Manufacturing process automated (1) vs manual (0) |
| COUNTRY, SITEID | char | Country / site |

## Handling notes

- **Time origin & re-dosing:** TIME is anchored to each subject's first CAR-T infusion and is
  continuous; re-dose cycles produce additional EVID=1/CMT=1 records on the same timeline, with
  TAD resetting at each infusion.
- **BLQ:** retained (CENS=1, DV=LLOQ). Switch to M3 likelihood in the model, or filter `BLQ==0`
  for an M1 fit.
- **Vaccine input:** modeled either as discrete CMT=2 inputs or summarized via NVAC/TPV as
  time-varying covariates on the expansion rate, reflecting CARVac-driven secondary expansion.
- **Candidate covariates:** LCARDOSE, WEIGHT/BSA, AGE, SEXN, ECOGN, TUMTYPE, LDLVLN, REDLDFL,
  PROCAUTO, VACSCHN. Screen continuous-covariate collinearity (see EDA Figure 6) before inclusion.
