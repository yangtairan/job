#!/usr/bin/env Rscript
# =============================================================================
# Study CYB003-101
# Exploratory PK/PD (exposure-response) analysis of CYB003 on blood pressure,
# pulse rate and hallucination
#
# Purpose : Reproduces every analysis and Figures 1-13 of the PK/PD Analysis
#           Report (Draft v0.9, 17 November 2026), together with the numbers
#           behind Tables 2-11.
# Input   : ADaM datasets ADSL, ADPC, ADPP, ADVS, ADAE (.sas7bdat or .xpt)
# Output  : <out_dir>/figures/Figure01 ... Figure13 (.png, 300 dpi)
#           <out_dir>/tables/*.csv  (model estimates and summary tables)
#           <out_dir>/check_against_report.csv (each estimate vs report value)
#
# Usage   : Rscript CYB003-101_PKPD_analysis.R <adam_dir> <out_dir>
#           or set adam_dir / out_dir below and source() the file.
#
# Software: R 4.3.3; nlme 3.1-164, survival 3.5-8, ggplot2 3.4.4,
#           patchwork 1.2.0, ggrepel, ragg, systemfonts, haven 2.5.4,
#           dplyr 1.1.4, tidyr 1.3.1
# =============================================================================

# ---- 0. Set-up --------------------------------------------------------------
pkgs <- c("haven", "dplyr", "tidyr", "nlme", "survival", "ggplot2",
          "patchwork", "ggrepel", "ragg", "systemfonts")
miss <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss))
  stop("Install the missing package(s) first: install.packages(c(",
       paste0('"', miss, '"', collapse = ", "), "))", call. = FALSE)
suppressPackageStartupMessages({
  library(haven); library(dplyr); library(tidyr); library(nlme)
  library(survival); library(ggplot2); library(patchwork); library(ggrepel)
})

args     <- commandArgs(trailingOnly = TRUE)
adam_dir <- if (length(args) >= 1) args[1] else "ADaM"
out_dir  <- if (length(args) >= 2) args[2] else "pkpd_output"
fig_dir  <- file.path(out_dir, "figures")
tab_dir  <- file.path(out_dir, "tables")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tab_dir, recursive = TRUE, showWarnings = FALSE)

Z90        <- qnorm(0.95)                 # two-sided 90% Wald interval
HLT_HALLUC <- "Hallucinations (excl sleep-related)"
N_BOOT     <- 10000                       # cluster-bootstrap resamples
SEED_BOOT  <- 101                         # seed for the bootstrap
XMAX       <- 46                          # x-axis limit for concentration (ng/mL)
ID_033     <- "CYB003-101-01-033"         # participant shown in Figure 13

NAVY <- "#1F3864"; RED <- "#C0392B"; BLUE <- "#0072B2"; ORANGE <- "#E69F00"
TEAL <- "#0E7C7B"; PURPLE <- "#8E44AD"; GREEN <- "#2E7D32"; GREY <- "#9AA0A6"
STEEL <- "#5B8DBF"

## Font: Arial where available (Windows, macOS); otherwise a metric-compatible
## or Unicode-complete sans-serif font, so that Greek letters and symbols render.
pick_font <- function() {
  fam <- unique(systemfonts::system_fonts()$family)
  hit <- intersect(c("Arial", "Liberation Sans", "Helvetica", "DejaVu Sans"), fam)
  if (length(hit)) hit[1] else "sans"
}
FONT <- pick_font()
for (g in c("text", "label", "text_repel")) update_geom_defaults(g, list(family = FONT))

theme_set(
  theme_bw(base_size = 11, base_family = FONT) +
    theme(panel.grid.minor = element_blank(),
          panel.grid.major = element_line(colour = "grey92", linewidth = 0.3),
          panel.border     = element_rect(colour = "grey40", fill = NA, linewidth = 0.5),
          axis.text        = element_text(colour = "black"),
          legend.title     = element_blank(),
          legend.key.width = unit(1.6, "lines"),
          plot.subtitle    = element_text(size = 9, colour = "grey15", lineheight = 1.05),
          plot.tag         = element_text(face = "bold", size = 14))
)
save_fig <- function(p, name, width, height) {
  ggsave(file.path(fig_dir, paste0(name, ".png")), p, width = width,
         height = height, dpi = 300, device = ragg::agg_png, bg = "white")
  message("  written: ", name, ".png")
}
note_box <- function(label) labs(subtitle = label)   # estimates shown above the panel
fmt  <- function(x, d = 3) formatC(x, format = "f", digits = d)
fmts <- function(x, d = 3) formatC(x, format = "f", digits = d, flag = "+")
fmtp <- function(p) ifelse(p < 0.001, "< 0.001", formatC(p, format = "f", digits = 2))

# ---- 1. Read ADaM -----------------------------------------------------------
read_adam <- function(name) {
  f <- list.files(adam_dir, pattern = paste0("^", name, "\\.(sas7bdat|xpt)$"),
                  ignore.case = TRUE, recursive = TRUE, full.names = TRUE)
  if (!length(f)) stop("Dataset not found in ", adam_dir, ": ", name, call. = FALSE)
  f <- f[order(!grepl("sas7bdat$", f, ignore.case = TRUE))][1]   # prefer .sas7bdat
  d <- if (grepl("xpt$", f, ignore.case = TRUE)) read_xpt(f) else read_sas(f)
  d <- as.data.frame(zap_formats(zap_labels(d)), stringsAsFactors = FALSE)
  names(d) <- toupper(names(d))
  chr <- vapply(d, is.character, logical(1))
  d[chr] <- lapply(d[chr], trimws)
  d
}
adsl <- read_adam("adsl"); adpc <- read_adam("adpc"); adpp <- read_adam("adpp")
advs <- read_adam("advs"); adae <- read_adam("adae")

# Nominal post-dose hour from the analysis timepoint label (ATPT).
# ATPTN is not used: it is not harmonised across domains (actual hours in ADPC,
# ordinal index in ADVS).
hrs <- function(x) {
  s   <- tolower(as.character(x))
  out <- rep(NA_real_, length(s))
  hh  <- grepl("[0-9.]+\\s*(hours?|hrs?|h)\\b", s)
  out[hh] <- as.numeric(sub(".*?([0-9.]+)\\s*(hours?|hrs?|h)\\b.*", "\\1", s[hh], perl = TRUE))
  mm  <- !hh & grepl("[0-9.]+\\s*min", s)
  out[mm] <- as.numeric(sub(".*?([0-9.]+)\\s*min.*", "\\1", s[mm], perl = TRUE)) / 60
  out[grepl("pre", s)] <- 0
  out
}
# Date-time from a SAS datetime (POSIXct or numeric) or an ISO 8601 character
# value. Character values without a time part return NA.
as_dtm <- function(x) {
  if (inherits(x, "POSIXct")) return(x)
  if (is.numeric(x)) return(as.POSIXct(x, origin = "1960-01-01", tz = "UTC"))
  x <- trimws(as.character(x)); x[x == ""] <- NA
  x <- sub("T", " ", x, fixed = TRUE)
  out <- as.POSIXct(x, tz = "UTC", format = "%Y-%m-%d %H:%M:%S")
  nas <- is.na(out) & !is.na(x)
  out[nas] <- as.POSIXct(x[nas], tz = "UTC", format = "%Y-%m-%d %H:%M")
  out
}

# ---- 2. Analysis datasets ---------------------------------------------------
## 2.1 CYB003 concentrations (Day 8). ADPC AVAL already carries the CSR BLQ
##     convention: pre-dose and BLQ before the first quantifiable value = 0,
##     BLQ after the first quantifiable value = missing. Participants flagged
##     PKSUMXFL = "Y" are excluded, as in the PK summary tables.
pc <- adpc %>%
  filter(PARAMCD == "CYB003", APERIODC == "PERIOD 2") %>%
  mutate(H = hrs(ATPT))
if (!"PKSUMXFL" %in% names(pc)) pc$PKSUMXFL <- NA_character_
if (anyNA(pc$H)) {
  warning("ADPC records dropped (no nominal hour in ATPT): ",
          paste(unique(pc$ATPT[is.na(pc$H)]), collapse = "; "))
  pc <- pc[!is.na(pc$H), ]
}
excl_pk <- sort(unique(pc$USUBJID[!is.na(pc$PKSUMXFL) & pc$PKSUMXFL == "Y"]))
conc <- pc %>%
  filter(is.na(PKSUMXFL) | PKSUMXFL != "Y") %>%
  group_by(USUBJID, H) %>%
  summarise(CONC = mean(AVAL, na.rm = TRUE), .groups = "drop") %>%
  filter(!is.na(CONC)) %>%
  arrange(USUBJID, H)
conc_time <- conc %>% group_by(H) %>%
  summarise(n = n(), n_quant = sum(CONC > 0), CONC = mean(CONC),
            .groups = "drop")
conc_p90 <- conc %>% group_by(H) %>%
  summarise(mean = mean(CONC), p90 = quantile(CONC, 0.9, type = 7), .groups = "drop")

## 2.2 Non-compartmental PK parameters (ADPP). Terminal t1/2 is used only when
##     the lambda-z acceptance criteria are met (adjusted R2 >= 0.8, span >= 2).
expo <- adpp %>%
  filter(PPCAT == "CYB003 Concentration",
         PARAMCD %in% c("CMAX", "AUCIFO", "LAMZHL", "TMAX", "R2ADJ", "LAMZSPN")) %>%
  group_by(USUBJID, PARAMCD) %>% summarise(AVAL = mean(AVAL, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = PARAMCD, values_from = AVAL) %>%
  rename(AUC = AUCIFO, THALF = LAMZHL, SPAN = LAMZSPN) %>%
  as.data.frame()
bad_thalf <- which(expo$R2ADJ < 0.8 | expo$SPAN < 2)
excl_thalf <- expo$USUBJID[bad_thalf]
expo$THALF[bad_thalf] <- NA
gm_cmax  <- exp(mean(log(expo$CMAX), na.rm = TRUE)); max_cmax <- max(expo$CMAX, na.rm = TRUE)
gm_auc   <- exp(mean(log(expo$AUC),  na.rm = TRUE))

## 2.3 Vital signs: supine SBP, DBP, pulse. Records with the same participant,
##     parameter, period and nominal hour are averaged.
ENDPT <- c(SBP = "SYSBPSU", DBP = "DIABPSU", HR = "PULSESU")
nan2na <- function(x) ifelse(is.nan(x), NA_real_, x)
vs <- advs %>%
  filter(PARAMCD %in% ENDPT, APERIODC %in% c("PERIOD 1", "PERIOD 2")) %>%
  mutate(H = hrs(ATPT), ENDPT = names(ENDPT)[match(PARAMCD, ENDPT)]) %>%
  filter(!is.na(H)) %>%
  group_by(USUBJID, ENDPT, APERIODC, H) %>%
  summarise(AVAL = nan2na(mean(AVAL, na.rm = TRUE)), BASE = nan2na(mean(BASE, na.rm = TRUE)),
            CHG  = nan2na(mean(CHG,  na.rm = TRUE)), .groups = "drop")

## 2.4 Reference-corrected change: ddY = (Day 8 change from baseline) -
##     (Day 1 change from baseline) at the same nominal hour, matched to the
##     Day 8 CYB003 concentration at that hour.
make_dd <- function(k) {
  d8 <- vs %>% filter(ENDPT == k, APERIODC == "PERIOD 2") %>%
    transmute(USUBJID, H, d8 = CHG, aval8 = AVAL, base8 = BASE)
  d1 <- vs %>% filter(ENDPT == k, APERIODC == "PERIOD 1") %>%
    transmute(USUBJID, H, d1 = CHG)
  inner_join(d8, d1, by = c("USUBJID", "H")) %>%
    mutate(dd = d8 - d1) %>%
    inner_join(conc, by = c("USUBJID", "H")) %>%
    filter(!is.na(dd), !is.na(CONC)) %>%
    arrange(USUBJID, H) %>% as.data.frame()
}
DD <- lapply(setNames(names(ENDPT), names(ENDPT)), make_dd)

## 2.5 Hallucination adverse events: MedDRA HLT Hallucinations (excl
##     sleep-related); onset and resolution in hours from the Day 8 CYB003 dose.
dose_dtm <- adsl %>% transmute(USUBJID, dose = as_dtm(AP02SDTM))
dosed    <- sort(dose_dtm$USUBJID[!is.na(dose_dtm$dose)])
ae_rel <- function(d) {
  d %>% left_join(dose_dtm, by = "USUBJID") %>%
    mutate(start = as_dtm(ASTDTM), end = as_dtm(AEENDTC),
           onset  = as.numeric(difftime(start, dose, units = "hours")),
           offset = as.numeric(difftime(end,   dose, units = "hours")),
           dur    = offset - onset)
}
hall_all <- adae %>% filter(AEHLT == HLT_HALLUC)
if ("TRTEMFL" %in% names(hall_all)) hall_all <- hall_all %>% filter(TRTEMFL == "Y")
hall_all <- ae_rel(hall_all)
n_hall_untimed <- sum(is.na(hall_all$onset) | is.na(hall_all$offset))
hall <- hall_all %>% filter(!is.na(onset), !is.na(offset)) %>%
  mutate(PT = recode(AEDECOD,
                     "Hallucination, visual"   = "Visual hallucination",
                     "Hallucination, auditory" = "Auditory hallucination",
                     "Hallucination, tactile"  = "Tactile hallucination",
                     "Hallucination"           = "Hallucination (unspecified)"),
         SEV = tools::toTitleCase(tolower(AESEV))) %>%
  as.data.frame()

## per participant: first onset, final resolution, longest episode, total duration
hall_subj <- hall %>% group_by(USUBJID) %>%
  summarise(first_on = min(onset), last_off = max(offset), longest = max(dur),
            n_ep = n(), .groups = "drop") %>%
  mutate(total = last_off - first_on) %>%
  left_join(expo, by = "USUBJID") %>% as.data.frame()
subj <- data.frame(USUBJID = dosed, stringsAsFactors = FALSE) %>%
  mutate(hall = as.integer(USUBJID %in% hall$USUBJID)) %>%
  left_join(expo, by = "USUBJID")

## hallucination status (present/absent) at each PK sampling time
ep <- split(hall[, c("onset", "offset")], hall$USUBJID)
tm <- conc %>% rowwise() %>%
  mutate(hall = {e <- ep[[USUBJID]]
                 as.integer(!is.null(e) && any(e$onset <= H & e$offset >= H))}) %>%
  ungroup() %>% as.data.frame()
prev <- tm %>% group_by(H) %>%
  summarise(n = n(), n_hall = sum(hall), pct = 100 * mean(hall), .groups = "drop") %>%
  left_join(conc_time[, c("H", "CONC")], by = "H")

# ---- 3. Analyses ------------------------------------------------------------
## 3.1 Linear mixed-effects model (REML, random intercept, centred concentration)
fit_lme <- function(d, y) {
  d$Y  <- d[[y]]; cb <- mean(d$CONC); d$xc <- d$CONC - cb
  f <- lme(Y ~ xc, random = ~ 1 | USUBJID, data = d, method = "REML")
  b <- fixef(f); V <- vcov(f); se <- sqrt(V["xc", "xc"])
  pred <- function(x) {
    X <- cbind(1, x - cb); fit <- as.numeric(X %*% b)
    s <- sqrt(rowSums((X %*% V) * X))
    data.frame(x = x, fit = fit, lo = fit - Z90 * s, hi = fit + Z90 * s)
  }
  list(fit = f, slope = unname(b["xc"]), lo = unname(b["xc"] - Z90 * se),
       hi = unname(b["xc"] + Z90 * se), p = summary(f)$tTable["xc", "p-value"],
       b0 = unname(b[1]), cb = cb, pred = pred, n = nrow(d),
       ns = length(unique(d$USUBJID)))
}
W  <- lapply(DD, fit_lme, y = "dd")      # reference-corrected (ddY)
W1 <- lapply(DD, fit_lme, y = "d8")      # baseline-corrected (single delta)
obs_max <- lapply(DD, function(m) {
  a <- m %>% group_by(H) %>% summarise(n = n(), dd = mean(dd), .groups = "drop")
  a[which.max(a$dd), ]
})

lme_tab <- bind_rows(lapply(names(W), function(k) {
  g <- W[[k]]$pred(gm_cmax); x <- W[[k]]$pred(max_cmax)
  data.frame(endpoint = k, n_obs = W[[k]]$n, n_subj = W[[k]]$ns,
             slope = W[[k]]$slope, slope_lo = W[[k]]$lo, slope_hi = W[[k]]$hi, p = W[[k]]$p,
             pred_gm = g$fit, pred_gm_lo = g$lo, pred_gm_hi = g$hi,
             pred_max = x$fit, pred_max_lo = x$lo, pred_max_hi = x$hi,
             obs_max_mean = obs_max[[k]]$dd, obs_max_h = obs_max[[k]]$H,
             single_slope = W1[[k]]$slope, single_lo = W1[[k]]$lo, single_hi = W1[[k]]$hi)
}))

## 3.2 Model evaluation / sensitivity
sens <- bind_rows(lapply(names(DD), function(k) {
  d <- DD[[k]]; d$xc <- d$CONC - mean(d$CONC)
  f0 <- lme(dd ~ xc, random = ~ 1 | USUBJID, data = d, method = "REML")
  f1 <- tryCatch(lme(dd ~ xc, random = ~ xc | USUBJID, data = d, method = "REML",
                     control = lmeControl(opt = "optim", maxIter = 200, msMaxIter = 200)),
                 error = function(e) NULL)
  fo <- lme(dd ~ xc, random = ~ 1 | USUBJID, data = d, method = "REML",
            control = lmeControl(opt = "optim"))
  post <- fit_lme(d[d$H > 0, ], "dd")
  data.frame(endpoint = k,
             slope_nlminb = fixef(f0)[["xc"]], slope_optim = fixef(fo)[["xc"]],
             AIC_rint = AIC(f0), AIC_rslope = if (is.null(f1)) NA else AIC(f1),
             p_LRT_rslope = if (is.null(f1)) NA else anova(f0, f1)$`p-value`[2],
             slope_rslope = if (is.null(f1)) NA else fixef(f1)[["xc"]],
             se_rslope    = if (is.null(f1)) NA else sqrt(vcov(f1)["xc", "xc"]),
             n_predose = sum(d$H == 0), n_subj_predose = length(unique(d$USUBJID[d$H == 0])),
             slope_postdose_only = post$slope, lo_postdose_only = post$lo,
             hi_postdose_only = post$hi)
}))
## observed mean ddY by concentration quintile against the model prediction
linearity <- bind_rows(lapply(names(DD), function(k) {
  d <- DD[[k]]
  d$bin <- cut(d$CONC, unique(quantile(d$CONC, seq(0, 1, 0.2))), include.lowest = TRUE)
  d %>% group_by(bin) %>%
    summarise(n = n(), conc_mean = mean(CONC), observed = mean(dd), .groups = "drop") %>%
    mutate(endpoint = k, predicted = W[[k]]$pred(conc_mean)$fit, .before = 1)
}))

## 3.3 Between-subject: maximum ddY versus individual Cmax and AUC0-inf (OLS)
BS <- lapply(DD, function(m) m %>% group_by(USUBJID) %>%
               summarise(mx = max(dd), mn = mean(dd), .groups = "drop") %>%
               inner_join(expo, by = "USUBJID") %>% as.data.frame())
between_tab <- bind_rows(lapply(names(BS), function(k)
  bind_rows(lapply(c("CMAX", "AUC"), function(xv)
    bind_rows(lapply(c(mx = "maximum", mn = "mean"), function(yl) {
      yv <- if (yl == "maximum") "mx" else "mn"
      d <- BS[[k]][!is.na(BS[[k]][[xv]]), ]; o <- lm(d[[yv]] ~ d[[xv]])
      data.frame(endpoint = k, response = yl, exposure = xv, slope = coef(o)[[2]],
                 r = cor(d[[yv]], d[[xv]]), p = summary(o)$coefficients[2, 4], n = nrow(d))
    }))))))
## sensitivity: maximum over post-dose records only
between_post <- bind_rows(lapply(names(DD), function(k) {
  s <- DD[[k]] %>% filter(H > 0) %>% group_by(USUBJID) %>%
    summarise(mx = max(dd), .groups = "drop") %>% inner_join(expo, by = "USUBJID")
  bind_rows(lapply(c("CMAX", "AUC"), function(xv) {
    o <- lm(s$mx ~ s[[xv]])
    data.frame(endpoint = k, exposure = xv, slope = coef(o)[[2]],
               r = cor(s$mx, s[[xv]]), p = summary(o)$coefficients[2, 4], n = nrow(s))
  }))
}))

## 3.4 Between- and within-subject slopes estimated separately (SBP, DBP)
WB <- lapply(DD[c("SBP", "DBP")], function(m) {
  m <- m %>% group_by(USUBJID) %>% mutate(cbar = mean(CONC), cw = CONC - cbar) %>%
    ungroup() %>% as.data.frame()
  f <- lme(dd ~ cw + cbar, random = ~ 1 | USUBJID, data = m, method = "REML")
  bw <- fixef(f)[["cw"]]; sew <- sqrt(vcov(f)["cw", "cw"])
  pm <- m %>% group_by(USUBJID) %>% summarise(cb = mean(CONC), db = mean(dd), .groups = "drop")
  ob <- lm(db ~ cb, pm); cib <- confint(ob, "cb", level = 0.90)
  ind <- m %>% group_by(USUBJID) %>% filter(n() >= 4, sd(CONC) > 0) %>%
    summarise(n = n(), slope = coef(lm(dd ~ CONC))[[2]],
              int = coef(lm(dd ~ CONC))[[1]], xmin = min(CONC), xmax = max(CONC),
              .groups = "drop")
  list(within = bw, w_lo = bw - Z90 * sew, w_hi = bw + Z90 * sew,
       between = coef(ob)[["cb"]], b_lo = cib[1], b_hi = cib[2], n = nrow(pm),
       npos = sum(ind$slope > 0), ntot = nrow(ind), ind = ind, pm = pm,
       nobs_range = range(ind$n))
})
wb_tab <- bind_rows(lapply(names(WB), function(k) with(WB[[k]], data.frame(
  endpoint = k, between = between, b_lo = b_lo, b_hi = b_hi, within = within,
  w_lo = w_lo, w_hi = w_hi, n_positive = npos, n_slopes = ntot))))

## 3.5 Return of Day 8 blood pressure to within 20% of the Day 8 baseline
ret20 <- bind_rows(lapply(c("SBP", "DBP"), function(k) {
  d <- vs %>% filter(ENDPT == k, APERIODC == "PERIOD 2", !is.na(AVAL), !is.na(BASE))
  bind_rows(lapply(split(d, d$USUBJID), function(g) {
    post <- g[g$H > 0, ]; post <- post[order(post$H), ]
    b    <- post$BASE[1]                 # Day 8 baseline carried on the post-dose records
    pct  <- 100 * (post$AVAL - post$BASE) / post$BASE
    exceeded <- any(pct > 20); t_max <- NA; t_ret <- NA
    if (exceeded) {
      t_max <- post$H[which.max(pct)]
      ok <- post$H > t_max & pct <= 20
      if (any(ok)) t_ret <- min(post$H[ok])
    }
    data.frame(USUBJID = g$USUBJID[1], ENDPT = k, base = b, max_pct = max(pct),
               exceeded = exceeded, t_max = t_max, t_return = t_ret,
               above_2h = if (any(post$H == 2)) pct[post$H == 2] > 20 else NA,
               below_late = any(pct[post$H %in% c(12, 24)] < -20))
  }))
}))
ret_sum <- ret20 %>% group_by(ENDPT) %>%
  summarise(N = n(), n_exceed = sum(exceeded), pct_exceed = 100 * mean(exceeded),
            t_max_median = median(t_max, na.rm = TRUE),
            t_return_median = median(t_return, na.rm = TRUE),
            t_return_min = min(t_return, na.rm = TRUE), t_return_max = max(t_return, na.rm = TRUE),
            pct_above_2h = 100 * mean(above_2h, na.rm = TRUE), n_2h = sum(!is.na(above_2h)),
            n_below_late = sum(below_late), .groups = "drop")
ret_cum <- bind_rows(lapply(c(2, 4, 6, 8), function(t) ret20 %>% filter(exceeded) %>%
  group_by(ENDPT) %>% summarise(by_h = t, n = sum(t_return <= t, na.rm = TRUE), N = n(),
                                pct = 100 * n / N, .groups = "drop")))

## 3.6 Hallucination: descriptive summaries
q <- function(x, p) unname(quantile(x, p, type = 7))
hall_desc <- data.frame(
  n_dosed = length(dosed), n_with = length(unique(hall$USUBJID)), n_episodes = nrow(hall),
  onset_med = median(hall$onset), onset_q1 = q(hall$onset, .25), onset_q3 = q(hall$onset, .75),
  dur_med = median(hall$dur), dur_q1 = q(hall$dur, .25), dur_q3 = q(hall$dur, .75),
  off_med = median(hall$offset), off_q1 = q(hall$offset, .25), off_q3 = q(hall$offset, .75),
  off_max = max(hall$offset),
  total_med = median(hall_subj$total), total_q1 = q(hall_subj$total, .25),
  total_q3 = q(hall_subj$total, .75), longest_med = median(hall_subj$longest),
  n_mild = sum(hall$AESEV == "MILD"), n_moderate = sum(hall$AESEV == "MODERATE"),
  n_severe = sum(hall$AESEV == "SEVERE"), n_onset_at_dose = sum(hall_subj$first_on <= 0),
  first_on_med = median(hall_subj$first_on), last_off_med = median(hall_subj$last_off),
  last_off_q1 = q(hall_subj$last_off, .25), last_off_q3 = q(hall_subj$last_off, .75))
hall_pt <- hall %>% group_by(AEDECOD) %>%
  summarise(episodes = n(), participants = n_distinct(USUBJID), dur_median = median(dur),
            .groups = "drop") %>% arrange(desc(episodes))

## 3.7 Hallucination: incidence versus Cmax / AUC; participants without an event
inc <- lapply(c(CMAX = "CMAX", AUC = "AUC"), function(xv) {
  f <- glm(reformulate(xv, "hall"), binomial, subj[!is.na(subj[[xv]]), ])
  c(OR_per_unit = exp(coef(f)[[2]]), p = summary(f)$coefficients[2, 4])
})
nh <- subj[subj$hall == 0, ]; yh <- subj[subj$hall == 1, ]
nonhall <- list(cmax = sort(nh$CMAX), cmax_med_nh = median(nh$CMAX, na.rm = TRUE),
                cmax_med_h = median(yh$CMAX, na.rm = TRUE),
                auc_med_nh = median(nh$AUC, na.rm = TRUE), auc_med_h = median(yh$AUC, na.rm = TRUE),
                p_cmax = suppressWarnings(wilcox.test(nh$CMAX, yh$CMAX)$p.value),
                p_auc  = suppressWarnings(wilcox.test(nh$AUC,  yh$AUC)$p.value))

## 3.8 Probability of hallucination versus concentration at the sampling time
lg <- glm(hall ~ CONC, binomial, tm); a <- coef(lg)[[1]]; b <- coef(lg)[[2]]
ecx <- function(p, a, b) (qlogis(p) - a) / b
logit <- list(a = a, b = b, n = nrow(tm), or10 = exp(10 * b),
              p = summary(lg)$coefficients[2, 4], p0 = plogis(a),
              p_gm = plogis(a + b * gm_cmax), EC20 = ecx(0.2, a, b), EC50 = ecx(0.5, a, b))
set.seed(SEED_BOOT)
ids <- unique(tm$USUBJID); tm_split <- split(tm, tm$USUBJID)
boot <- t(replicate(N_BOOT, {
  d  <- bind_rows(tm_split[sample(ids, replace = TRUE)])
  cf <- tryCatch(coef(suppressWarnings(glm(hall ~ CONC, binomial, d))),
                 error = function(e) c(NA, NA))
  c(EC20 = ecx(0.2, cf[[1]], cf[[2]]), EC50 = ecx(0.5, cf[[1]], cf[[2]]))
}))
logit$EC20_ci <- unname(quantile(boot[, "EC20"], c(0.05, 0.95), na.rm = TRUE, type = 7))
logit$EC50_ci <- unname(quantile(boot[, "EC50"], c(0.05, 0.95), na.rm = TRUE, type = 7))
t_below <- function(col, thr) { x <- conc_p90[conc_p90$H >= 4 & conc_p90[[col]] < thr, ]
                                if (nrow(x)) min(x$H) else NA }
below <- c(EC50_mean = t_below("mean", logit$EC50), EC20_mean = t_below("mean", logit$EC20),
           EC50_p90  = t_below("p90",  logit$EC50), EC20_p90  = t_below("p90",  logit$EC20))

## 3.9 Kaplan-Meier: time to first onset (non-hallucinators censored at 48 h)
##     and time to final resolution (participants with hallucination)
km_on <- subj %>% left_join(hall_subj[, c("USUBJID", "first_on")], by = "USUBJID") %>%
  transmute(USUBJID, time = ifelse(is.na(first_on), 48, first_on), event = hall)
km_off <- hall_subj %>% transmute(USUBJID, time = last_off, event = 1L)
km_fit   <- function(d) survfit(Surv(time, event) ~ 1, data = d)
km_curve <- function(s) data.frame(time = c(0, s$time), surv = c(1, s$surv))
km_table <- function(d, times) data.frame(
  time = times,
  at_risk = vapply(times, function(t) sum(d$time >= t), numeric(1)),
  events  = vapply(times, function(t) sum(d$time <= t & d$event == 1), numeric(1)),
  N = nrow(d)) %>% mutate(cum_pct = 100 * events / N)
SF <- list(on = km_fit(km_on), off = km_fit(km_off))
KM <- lapply(SF, km_curve)
KM_tab <- list(on  = km_table(km_on,  c(0, 0.5, 1, 1.5, 2, 3, 4)),
               off = km_table(km_off, c(0, 2, 4, 6, 8, 10, 12)))
KM_tab$on$km  <- summary(SF$on,  times = KM_tab$on$time,  extend = TRUE)$surv
KM_tab$off$km <- summary(SF$off, times = KM_tab$off$time, extend = TRUE)$surv
## Kaplan-Meier median (survfit convention: where the estimate equals 0.50 over
## an interval, the midpoint of that interval)
km_med <- c(onset      = unname(quantile(SF$on,  0.5)$quantile),
            resolution = unname(quantile(SF$off, 0.5)$quantile))

## 3.10 Duration of hallucination versus exposure (Spearman; partial Spearman)
sp <- function(x, y) { ok <- !is.na(x) & !is.na(y)
  ct <- suppressWarnings(cor.test(x[ok], y[ok], method = "spearman", exact = FALSE))
  data.frame(rho = unname(ct$estimate), p = ct$p.value, n = sum(ok)) }
dur_tab <- bind_rows(lapply(c("last_off", "total", "longest"), function(yv)
  bind_rows(lapply(c("THALF", "CMAX", "AUC"), function(xv)
    cbind(measure = yv, exposure = xv, sp(hall_subj[[xv]], hall_subj[[yv]]))))))
dp <- hall_subj[complete.cases(hall_subj[, c("AUC", "THALF", "total", "CMAX")]), ]
## partial Spearman: Pearson correlation of rank residuals; t test on n - 3 df
partial_sp <- function(y, x, z) {
  ex <- resid(lm(rank(x) ~ rank(z))); ey <- resid(lm(rank(y) ~ rank(z)))
  r <- cor(ex, ey); n <- length(y); t <- r * sqrt((n - 3) / (1 - r^2))
  c(rho = r, p = 2 * pt(-abs(t), n - 3), n = n)
}
partial <- rbind(thalf_given_auc = partial_sp(dp$total, dp$THALF, dp$AUC),
                 auc_given_thalf = partial_sp(dp$total, dp$AUC, dp$THALF))
rho_thalf_auc <- cor(dp$THALF, dp$AUC, method = "spearman")

## 3.11 Participant 01-033
p33 <- list(
  conc  = conc[conc$USUBJID == ID_033, ],
  bp    = vs %>% filter(USUBJID == ID_033, APERIODC == "PERIOD 2", ENDPT %in% c("SBP", "DBP")),
  d1    = vs %>% filter(USUBJID == ID_033, APERIODC == "PERIOD 1", ENDPT %in% c("SBP", "DBP")),
  hall  = hall[hall$USUBJID == ID_033, ],
  euph  = ae_rel(adae %>% filter(USUBJID == ID_033, AEDECOD == "Euphoric mood")),
  pk    = expo[expo$USUBJID == ID_033, ],
  pop_med = conc %>% filter(H %in% c(8, 12)) %>% group_by(H) %>%
    summarise(median = median(CONC), .groups = "drop"))

# ---- 4. Figures -------------------------------------------------------------
message("Figures:")
lab_conc <- "Time-matched CYB003 concentration (ng/mL)"
dd_lab   <- c(SBP = "\u0394\u0394 SBP (mmHg)", DBP = "\u0394\u0394 DBP (mmHg)",
              HR = "\u0394\u0394 pulse rate (bpm)")
zero_line <- geom_hline(yintercept = 0, linetype = "dotted", colour = "grey45", linewidth = 0.4)
gm_line   <- geom_vline(xintercept = gm_cmax, linetype = "dashed", colour = "grey60", linewidth = 0.4)

## Figure 1: ddSBP and ddDBP versus time-matched concentration ----------------
cr_panel <- function(k, col, single = TRUE) {
  xs <- seq(0, XMAX, length.out = 200)
  pr <- W[[k]]$pred(xs); pr1 <- W1[[k]]$pred(xs)
  lines <- rbind(cbind(pr[, c("x", "fit")],  type = "Day 1 corrected (\u0394\u0394)"),
                 cbind(pr1[, c("x", "fit")], type = "Baseline corrected (\u0394)"))
  lines$type <- factor(lines$type, levels = unique(lines$type))
  if (!single) lines <- lines[lines$type == levels(lines$type)[1], ]
  lab <- sprintf("\u0394\u0394 slope %s (90%% CI %s, %s)", fmt(W[[k]]$slope), fmt(W[[k]]$lo), fmt(W[[k]]$hi))
  if (single) lab <- paste0(lab, sprintf("\n\u0394 slope %s (90%% CI %s, %s)",
                                         fmt(W1[[k]]$slope), fmt(W1[[k]]$lo), fmt(W1[[k]]$hi)))
  ggplot(DD[[k]], aes(CONC, dd)) + zero_line + gm_line +
    geom_point(colour = col, alpha = 0.40, size = 1.4, stroke = 0) +
    geom_ribbon(data = pr, aes(x = x, ymin = lo, ymax = hi), inherit.aes = FALSE,
                fill = col, alpha = 0.15) +
    geom_line(data = lines, aes(x, fit, colour = type, linetype = type), linewidth = 0.9) +
    scale_colour_manual(values = c(col, ORANGE)) +
    scale_linetype_manual(values = c("solid", "dashed")) +
    coord_cartesian(xlim = c(0, XMAX)) + note_box(lab) +
    labs(x = lab_conc, y = dd_lab[[k]]) +
    theme(legend.position = if (single) "bottom" else "none")
}
fig1 <- (cr_panel("SBP", BLUE) | cr_panel("DBP", BLUE)) +
  plot_layout(guides = "collect") + plot_annotation(tag_levels = "A") &
  theme(legend.position = "bottom")
save_fig(fig1, "Figure01_ddBP_vs_concentration", 10, 4.8)

## Figures 2 and 3: maximum ddY versus individual Cmax / AUC0-inf ------------
between_panel <- function(k, xv, xlab) {
  d <- BS[[k]][!is.na(BS[[k]][[xv]]), ]; d$x <- d[[xv]]
  r <- between_tab %>% filter(endpoint == k, response == "maximum", exposure == xv)
  ggplot(d, aes(x, mx)) + zero_line +
    geom_smooth(method = "lm", formula = y ~ x, level = 0.90, colour = RED, fill = RED,
                alpha = 0.12, linewidth = 0.9) +
    geom_point(colour = NAVY, alpha = 0.85, size = 1.9) +
    note_box(sprintf("slope %s\nr = %s, p = %s, n = %d", fmts(r$slope), fmts(r$r, 2), fmt(r$p, 2), r$n)) +
    labs(x = xlab, y = paste("Maximum", dd_lab[[k]]))
}
between_fig <- function(xv, xlab) {
  (between_panel("SBP", xv, xlab) | between_panel("DBP", xv, xlab) | between_panel("HR", xv, xlab)) +
    plot_annotation(tag_levels = "A")
}
save_fig(between_fig("CMAX", expression("Individual CYB003 " * C[max] * " (ng/mL)")),
         "Figure02_max_dd_vs_Cmax", 11.5, 3.9)
save_fig(between_fig("AUC", expression("Individual CYB003 " * AUC[0 - infinity] * " (h" %.% "ng/mL)")),
         "Figure03_max_dd_vs_AUC", 11.5, 3.9)

## Figure 4: between-subject (A, C) and within-subject (B, D), SBP and DBP ----
wb_panels <- function(k) {
  w <- WB[[k]]
  pa <- ggplot(w$pm, aes(cb, db)) + zero_line +
    geom_smooth(method = "lm", formula = y ~ x, level = 0.90, colour = RED, fill = RED,
                alpha = 0.12, linewidth = 0.9) +
    geom_point(colour = NAVY, alpha = 0.85, size = 1.9) +
    note_box(sprintf("between-subject slope %s\n(90%% CI %s, %s), n = %d",
                     fmts(w$between), fmts(w$b_lo), fmts(w$b_hi), w$n)) +
    labs(x = "Participant mean CYB003 concentration (ng/mL)",
         y = paste("Participant mean", dd_lab[[k]]))
  seg <- w$ind %>% mutate(y0 = int + slope * xmin, y1 = int + slope * xmax)
  pooled <- data.frame(x = c(0, XMAX))
  pooled$y <- W[[k]]$b0 + w$within * (pooled$x - W[[k]]$cb)
  pb <- ggplot() + zero_line +
    geom_segment(data = seg, aes(x = xmin, xend = xmax, y = y0, yend = y1),
                 colour = GREY, linewidth = 0.4, alpha = 0.85) +
    geom_line(data = pooled, aes(x, y), colour = GREEN, linewidth = 1.2) +
    coord_cartesian(xlim = c(0, XMAX)) +
    note_box(sprintf("within-subject slope %s\n(90%% CI %s, %s)\n%d/%d individual slopes > 0",
                     fmts(w$within), fmts(w$w_lo), fmts(w$w_hi), w$npos, w$ntot)) +
    labs(x = lab_conc, y = dd_lab[[k]])
  list(pa, pb)
}
p4 <- c(wb_panels("SBP"), wb_panels("DBP"))
fig4 <- (p4[[1]] | p4[[2]]) / (p4[[3]] | p4[[4]]) + plot_annotation(tag_levels = "A")
save_fig(fig4, "Figure04_between_within_SBP_DBP", 10, 7.8)

## Figure 5: cumulative % returned to within 20% of the Day 8 baseline -------
rc <- ret_cum %>% mutate(bin = factor(paste0("\u2264 ", by_h, " h"), levels = paste0("\u2264 ", c(2, 4, 6, 8), " h")),
                         grp = factor(sprintf("%s (n = %d)", ENDPT, N),
                                      levels = sprintf("%s (n = %d)", c("SBP", "DBP"),
                                                       N[match(c("SBP", "DBP"), ENDPT)])))
fig5 <- ggplot(rc, aes(bin, pct, fill = grp)) +
  geom_col(position = position_dodge(width = 0.74), width = 0.72) +
  geom_text(aes(label = sprintf("%.0f%%\n(%d/%d)", pct, n, N)),
            position = position_dodge(width = 0.74), vjust = -0.25, size = 3, lineheight = 0.95) +
  scale_fill_manual(values = c(NAVY, STEEL)) +
  scale_y_continuous(limits = c(0, 118), breaks = seq(0, 100, 20), expand = c(0, 0)) +
  labs(x = "Time of return to \u2264 20% above Day 8 baseline",
       y = "Cumulative % of participants returned") +
  theme(legend.position = "bottom", panel.grid.major.x = element_blank())
save_fig(fig5, "Figure05_BP_return_within_20pct", 6.8, 4.6)

## Figure 6: dd pulse rate versus time-matched concentration ------------------
save_fig(cr_panel("HR", TEAL, single = FALSE), "Figure06_ddHR_vs_concentration", 6, 4.4)

## Figure 7: time-ordered mean effect versus mean concentration ---------------
loop_panel <- function(g, ylab, col) {
  g <- g[order(g$H), ]; n <- nrow(g)
  seg <- data.frame(x = g$CONC[-n], y = g$y[-n], xend = g$CONC[-1], yend = g$y[-1])
  ggplot(g, aes(CONC, y)) + zero_line +
    geom_segment(data = seg, aes(x = x, y = y, xend = xend, yend = yend), colour = col,
                 linewidth = 0.6, arrow = arrow(length = unit(0.07, "inches"), type = "closed")) +
    geom_point(colour = NAVY, size = 2) +
    geom_text_repel(aes(label = paste0(format(H, drop0trailing = TRUE, trim = TRUE), " h")),
                    size = 3, colour = "grey20", seed = 1, min.segment.length = 0.3,
                    segment.colour = "grey60", segment.size = 0.25, box.padding = 0.3) +
    labs(x = "Arithmetic mean CYB003 concentration (ng/mL)", y = ylab)
}
hyst <- lapply(DD, function(m) m %>% group_by(H) %>% summarise(n = n(), y = mean(dd), .groups = "drop") %>%
                 inner_join(conc_time[, c("H", "CONC")], by = "H"))
hyst$HALL <- prev %>% filter(H <= 24) %>% transmute(H, n, y = pct, CONC)
fig7 <- (loop_panel(hyst$SBP, "Mean \u0394\u0394 SBP (mmHg)", ORANGE) |
         loop_panel(hyst$DBP, "Mean \u0394\u0394 DBP (mmHg)", ORANGE)) /
        (loop_panel(hyst$HR, "Mean \u0394\u0394 pulse rate (bpm)", ORANGE) |
         loop_panel(hyst$HALL, "Participants with hallucination (%)", PURPLE)) +
  plot_annotation(tag_levels = "A")
save_fig(fig7, "Figure07_time_ordered_mean_effect", 10, 7.8)

## Figure 8: hallucination episode timelines (A) and episode duration (B) -----
pt_cols <- c("Visual hallucination" = "#A58BE2", "Auditory hallucination" = "#F08A8A",
             "Tactile hallucination" = "#4CB8E8", "Somatic hallucination" = "#2BB5A0",
             "Hallucination (unspecified)" = "#C9A227")
ord <- hall_subj$USUBJID[order(hall_subj$first_on, hall_subj$USUBJID)]
h8  <- hall %>% mutate(row = match(USUBJID, ord), PT = factor(PT, levels = names(pt_cols)))
f8a <- ggplot(h8) +
  geom_vline(xintercept = 0, colour = RED, linewidth = 0.6) +
  geom_segment(aes(x = onset, xend = offset, y = row, yend = row, colour = PT),
               linewidth = 2.1, lineend = "round", alpha = 0.9) +
  annotate("text", x = 0.15, y = length(ord) + 0.9, label = "CYB003 dose (t = 0)",
           colour = RED, hjust = 0, size = 3.3) +
  scale_colour_manual(values = pt_cols, drop = FALSE) +
  scale_x_continuous(breaks = seq(0, 12, 2)) +
  scale_y_continuous(breaks = NULL, limits = c(0.3, length(ord) + 1.3)) +
  coord_cartesian(xlim = c(-0.3, 12.3)) +
  labs(x = "Time since CYB003 dose (h)", y = "Participants (one row each, ordered by first onset)") +
  guides(colour = guide_legend(nrow = 2, override.aes = list(linewidth = 2.5))) +
  theme(legend.position = "bottom")
f8b <- ggplot(hall, aes(dur)) +
  geom_histogram(breaks = seq(0, 11, 0.5), closed = "left", fill = NAVY, colour = "white") +
  geom_vline(xintercept = median(hall$dur), colour = ORANGE, linetype = "dashed", linewidth = 0.8) +
  annotate("text", x = median(hall$dur) + 0.15, y = Inf, vjust = 1.6, hjust = 0, colour = ORANGE,
           size = 3.4, label = sprintf("median %.1f h", median(hall$dur))) +
  scale_x_continuous(breaks = seq(0, 10, 2)) + scale_y_continuous(expand = expansion(c(0, 0.08))) +
  labs(x = "Single-episode duration (h)", y = "Episodes")
fig8 <- f8a / f8b + plot_layout(heights = c(1.6, 1)) + plot_annotation(tag_levels = "A")
save_fig(fig8, "Figure08_hallucination_timelines", 8.2, 8.4)

## Figure 9: single-episode duration by severity (A) and preferred term (B) ---
h9 <- hall %>% group_by(SEV) %>% mutate(sev_lab = sprintf("%s (n=%d)", SEV, n())) %>%
  group_by(PT) %>% mutate(pt_lab = sprintf("%s (n=%d)", PT, n())) %>% ungroup()
h9$pt_lab <- reorder(h9$pt_lab, h9$dur, FUN = median)
set.seed(3)
f9a <- ggplot(h9, aes(sev_lab, dur)) +
  geom_boxplot(outlier.shape = NA, fill = NA, colour = NAVY, width = 0.5) +
  geom_jitter(aes(colour = SEV), width = 0.15, height = 0, size = 1.8, alpha = 0.8) +
  scale_colour_manual(values = c(Mild = NAVY, Moderate = RED, Severe = RED), guide = "none") +
  labs(x = NULL, y = "Single-episode duration (h)")
f9b <- ggplot(h9, aes(dur, pt_lab)) +
  geom_boxplot(outlier.shape = NA, fill = NA, colour = NAVY, width = 0.55) +
  geom_jitter(width = 0, height = 0.13, size = 1.6, alpha = 0.65, colour = NAVY) +
  labs(x = "Single-episode duration (h)", y = NULL)
fig9 <- (f9a | f9b) + plot_layout(widths = c(1, 1.9)) + plot_annotation(tag_levels = "A")
save_fig(fig9, "Figure09_duration_by_severity_and_PT", 10.5, 4.2)

## Figures 10 and 11: Kaplan-Meier curves with numbers at risk and events -----
km_panel <- function(k, tab, xlim, ylab, col, med, cumulative = FALSE) {
  k <- k[k$time <= xlim[2], ]
  k <- rbind(k, data.frame(time = xlim[2], surv = tail(k$surv, 1)))   # extend to the axis limit
  k$y <- if (cumulative) 100 * (1 - k$surv) else k$surv
  top <- if (cumulative) 100 else 1
  p <- ggplot(k, aes(time, y)) +
    geom_hline(yintercept = top / 2, linetype = "dotted", colour = "grey45", linewidth = 0.4) +
    geom_vline(xintercept = med, linetype = "dashed", colour = ORANGE, linewidth = 0.6) +
    geom_step(colour = col, linewidth = 0.9) +
    annotate("text", x = med + diff(xlim) * 0.015, y = if (cumulative) 8 else 0.93, hjust = 0,
             colour = ORANGE, size = 3.3, label = sprintf("median %.1f h", med)) +
    scale_x_continuous(breaks = tab$time, expand = expansion(c(0.06, 0.04))) +
    scale_y_continuous(breaks = seq(0, top, top / 5), expand = expansion(c(0.02, 0.09))) +
    coord_cartesian(xlim = xlim, ylim = c(0, top)) +
    labs(x = "Time since CYB003 dose (h)", y = ylab)
  if (cumulative)
    p <- p + geom_point(data = tab, aes(time, 100 * (1 - km)), colour = col, size = 1.8) +
      geom_text(data = tab, aes(time, 100 * (1 - km), label = sprintf("%.0f%%", 100 * (1 - km))),
                hjust = 1.15, vjust = -0.6, size = 2.9, colour = "grey15")
  tl <- tab %>% select(time, `At risk` = at_risk, Events = events) %>%
    pivot_longer(-time) %>% mutate(name = factor(name, levels = c("Events", "At risk")))
  tb <- ggplot(tl, aes(time, name, label = value)) + geom_text(size = 3.1) +
    scale_x_continuous(breaks = tab$time, expand = expansion(c(0.06, 0.04))) +
    coord_cartesian(xlim = xlim, clip = "off") +
    labs(x = NULL, y = NULL) +
    theme(panel.grid = element_blank(), panel.border = element_blank(),
          axis.text.x = element_blank(), axis.ticks = element_blank(),
          axis.text.y = element_text(face = "bold", size = 9))
  p / tb + plot_layout(heights = c(5, 1))
}
fig10 <- wrap_elements(km_panel(KM$on, KM_tab$on, c(0, 4),
                                "Proportion of participants without\nhallucination onset",
                                PURPLE, km_med[["onset"]])) |
         wrap_elements(km_panel(KM$off, KM_tab$off, c(0, 12),
                                "Proportion of participants with\nhallucination not yet resolved",
                                PURPLE, km_med[["resolution"]]))
fig10 <- fig10 + plot_annotation(tag_levels = "A")
save_fig(fig10, "Figure10_KM_onset_resolution", 10.5, 4.8)
fig11 <- wrap_elements(km_panel(KM$on, KM_tab$on, c(0, 4),
                                "Cumulative % of participants\nwith hallucination onset",
                                PURPLE, km_med[["onset"]], cumulative = TRUE)) |
         wrap_elements(km_panel(KM$off, KM_tab$off, c(0, 12),
                                "Cumulative % of participants\nwith hallucination resolved",
                                STEEL, km_med[["resolution"]], cumulative = TRUE))
fig11 <- fig11 + plot_annotation(tag_levels = "A")
save_fig(fig11, "Figure11_KM_cumulative_percentage", 10.5, 4.8)

## Figure 12: hallucination exposure-response ---------------------------------
kk <- 90 / 28                                       # right-axis scaling (ng/mL -> %)
f12a <- ggplot(prev, aes(H)) +
  geom_line(aes(y = CONC * kk), colour = RED, linetype = "dashed", linewidth = 0.6) +
  geom_point(aes(y = CONC * kk), colour = RED, shape = 15, size = 1.6) +
  geom_line(aes(y = pct), colour = PURPLE, linewidth = 0.9) +
  geom_point(aes(y = pct), colour = PURPLE, size = 2.2) +
  scale_x_continuous(breaks = c(0, 2, 4, 6, 8, 12, 16, 24)) +
  scale_y_continuous(name = "Participants with hallucination (%)", limits = c(0, 92),
                     breaks = seq(0, 80, 20),
                     sec.axis = sec_axis(~ . / kk, name = "Arithmetic mean CYB003 concentration (ng/mL)",
                                         breaks = seq(0, 25, 5))) +
  labs(x = "Time since CYB003 dose (h)") +
  theme(axis.title.y.left = element_text(colour = PURPLE), axis.title.y.right = element_text(colour = RED))
set.seed(2)
tmj <- tm %>% mutate(yj = hall + runif(n(), -0.03, 0.03))
cur <- data.frame(x = seq(0, XMAX, length.out = 300)); cur$p <- plogis(a + b * cur$x)
ecd <- data.frame(ec = c(logit$EC20, logit$EC50), p = c(0.2, 0.5), lab = c("EC20", "EC50"))
f12b <- ggplot() + gm_line +
  geom_point(data = tmj, aes(CONC, yj), colour = NAVY, alpha = 0.30, size = 1.3, stroke = 0) +
  geom_line(data = cur, aes(x, p), colour = PURPLE, linewidth = 1) +
  geom_segment(data = ecd, aes(x = ec, xend = ec, y = 0, yend = p), colour = ORANGE, linetype = "dashed", linewidth = 0.6) +
  geom_segment(data = ecd, aes(x = 0, xend = ec, y = p, yend = p), colour = ORANGE, linetype = "dashed", linewidth = 0.6) +
  geom_text(data = ecd, aes(0.4, p + 0.04, label = sprintf("%s = %.1f", lab, ec)),
            colour = "#B9770E", hjust = 0, size = 3.1) +
  scale_y_continuous(breaks = seq(0, 1, 0.2)) + coord_cartesian(xlim = c(0, XMAX)) +
  labs(x = "CYB003 plasma concentration at the sampling time (ng/mL)",
       y = "Probability of hallucination\nat the sampling time")
dur_panel <- function(xv, xlab) {
  d <- hall_subj[!is.na(hall_subj[[xv]]), ]; d$x <- d[[xv]]; s <- sp(d$x, d$total)
  ggplot(d, aes(x, total)) +
    geom_smooth(method = "lm", formula = y ~ x, se = FALSE, colour = RED, linewidth = 0.9) +
    geom_point(colour = NAVY, alpha = 0.85, size = 1.9) +
    note_box(sprintf("Spearman \u03C1 = %s, p = %s, n = %d", fmts(s$rho, 2), fmt(s$p, 3), s$n)) +
    scale_y_continuous(expand = expansion(c(0.05, 0.14))) +
    labs(x = xlab, y = "Total hallucination duration (h)")
}
fig12 <- (f12a | f12b) / (dur_panel("THALF", expression("CYB003 terminal " * t[1/2] * " (h)")) |
                          dur_panel("AUC", expression("CYB003 " * AUC[0 - infinity] * " (h" %.% "ng/mL)"))) +
  plot_annotation(tag_levels = "A")
save_fig(fig12, "Figure12_hallucination_exposure_response", 10.5, 8)

## Figure 13: participant 01-033 ----------------------------------------------
k13 <- 130 / 28                                     # right axis: 0-28 ng/mL on 30-160 mmHg
bp13 <- p33$bp %>% mutate(lab = ifelse(ENDPT == "SBP", "Supine SBP", "Supine DBP"))
c13  <- p33$conc %>% mutate(lab = "CYB003 concentration", y = 30 + CONC * k13)
hv   <- p33$hall[which.max(p33$hall$dur), ]; eu <- p33$euph[1, ]
lv   <- c("Supine SBP", "Supine DBP", "CYB003 concentration")
fig13 <- ggplot() +
  annotate("rect", xmin = hv$onset, xmax = hv$offset, ymin = -Inf, ymax = Inf, fill = PURPLE, alpha = 0.08) +
  annotate("rect", xmin = eu$onset, xmax = eu$offset, ymin = -Inf, ymax = Inf, fill = ORANGE, alpha = 0.14) +
  annotate("text", x = 8.4, y = 151, colour = PURPLE, size = 3.2, lineheight = 0.95,
           label = sprintf("Visual hallucination\n(%.1f\u2013%.1f h, %s)", hv$onset, hv$offset, tolower(hv$AESEV))) +
  annotate("text", x = (eu$onset + eu$offset) / 2, y = 41, colour = "#B9770E", size = 3.1, lineheight = 0.95,
           label = sprintf("Euphoric mood\n(%.1f\u2013%.1f h, %s)", eu$onset, eu$offset, tolower(eu$AESEV))) +
  geom_line(data = bp13, aes(H, AVAL, colour = factor(lab, lv), linetype = factor(lab, lv)), linewidth = 0.9) +
  geom_point(data = bp13, aes(H, AVAL, colour = factor(lab, lv), shape = factor(lab, lv)), size = 2.3) +
  geom_line(data = c13, aes(H, y, colour = factor(lab, lv), linetype = factor(lab, lv)), linewidth = 0.7) +
  geom_point(data = c13, aes(H, y, colour = factor(lab, lv), shape = factor(lab, lv)), size = 1.8) +
  scale_colour_manual(values = setNames(c(NAVY, "#3A7CA5", RED), lv), drop = FALSE) +
  scale_linetype_manual(values = setNames(c("solid", "solid", "dashed"), lv), drop = FALSE) +
  scale_shape_manual(values = setNames(c(16, 16, 15), lv), drop = FALSE) +
  scale_x_continuous(breaks = c(0, 2, 4, 6, 8, 12, 16, 24)) +
  scale_y_continuous(name = "Blood pressure (mmHg)", limits = c(30, 160), breaks = seq(40, 160, 20),
                     sec.axis = sec_axis(~ (. - 30) / k13, name = "CYB003 concentration (ng/mL)",
                                         breaks = seq(0, 25, 5))) +
  labs(x = "Time since CYB003 dose (h)") +
  theme(legend.position = "bottom", axis.title.y.right = element_text(colour = RED))
save_fig(fig13, "Figure13_participant_01-033", 8.6, 4.9)

# ---- 5. Tables and check against the report ---------------------------------
wcsv <- function(x, name) write.csv(x, file.path(tab_dir, paste0(name, ".csv")), row.names = FALSE)
wcsv(lme_tab, "Table04_Table08_LME_estimates")
wcsv(between_tab, "Table05_between_subject_regression")
wcsv(between_post, "Sensitivity_between_subject_postdose_only")
wcsv(wb_tab, "Table06_between_within_slopes")
wcsv(ret_sum, "Table07_BP_return20_summary"); wcsv(ret_cum, "Table07_BP_return20_cumulative")
wcsv(ret20, "Table07_BP_return20_by_participant")
wcsv(cbind(hall_desc, KM_median_onset = km_med[["onset"]], KM_median_resolution = km_med[["resolution"]]),
     "Table09_hallucination_timing")
wcsv(hall_pt, "Table09_hallucination_by_preferred_term")
wcsv(bind_rows(cbind(analysis = "onset", KM_tab$on), cbind(analysis = "resolution", KM_tab$off)),
     "Table10_KM_at_risk_events")
wcsv(dur_tab, "Table11_duration_vs_exposure_spearman")
wcsv(data.frame(analysis = rownames(partial), partial), "Table11_partial_spearman")
wcsv(prev, "Table11_hallucination_prevalence_by_time")
wcsv(conc_time, "Table03_concentration_n_by_time")
wcsv(vs %>% filter(ENDPT == "SBP") %>% count(APERIODC, H), "Table03_vitals_n_by_time")
wcsv(sens, "Sensitivity_LME"); wcsv(linearity, "Linearity_check_by_concentration_quintile")

pk_sum <- c(Cmax_gm = gm_cmax, Cmax_min = min(expo$CMAX, na.rm = TRUE), Cmax_max = max_cmax,
            AUC_gm = gm_auc, Tmax_median = median(expo$TMAX, na.rm = TRUE),
            thalf_mean = mean(expo$THALF, na.rm = TRUE), thalf_n = sum(!is.na(expo$THALF)))

## Report values (PK/PD Analysis Report, Draft v0.9). 'tol' is half a unit in the
## last reported decimal place.
L <- function(k, col) lme_tab[lme_tab$endpoint == k, col]
B <- function(k, x, col) between_tab[between_tab$endpoint == k & between_tab$response == "maximum" &
                                       between_tab$exposure == x, col]
D <- function(m, x, col) dur_tab[dur_tab$measure == m & dur_tab$exposure == x, col]
chk <- function(item, value, report, tol) data.frame(item, value, report, tol)
check <- rbind(
  chk("Participants dosed with CYB003", length(dosed), 34, 0),
  chk("Participants with concentration data", length(unique(conc$USUBJID)), 33, 0),
  chk("Cmax geometric mean (ng/mL)", pk_sum[["Cmax_gm"]], 26.9, 0.05),
  chk("Cmax maximum (ng/mL)", pk_sum[["Cmax_max"]], 43.0, 0.05),
  chk("AUC0-inf geometric mean (h*ng/mL)", pk_sum[["AUC_gm"]], 205, 0.5),
  chk("Tmax median (h)", pk_sum[["Tmax_median"]], 2.93, 0.005),
  chk("t1/2 mean (h)", pk_sum[["thalf_mean"]], 4.61, 0.005),
  chk("t1/2 n", pk_sum[["thalf_n"]], 31, 0),
  chk("ddY observations", L("SBP", "n_obs"), 215, 0),
  chk("SBP dd slope", L("SBP", "slope"), 1.029, 0.0005),
  chk("SBP dd slope lower", L("SBP", "slope_lo"), 0.882, 0.0005),
  chk("SBP dd slope upper", L("SBP", "slope_hi"), 1.176, 0.0005),
  chk("SBP predicted at GM Cmax", L("SBP", "pred_gm"), 24.7, 0.05),
  chk("SBP predicted at max Cmax", L("SBP", "pred_max"), 41.3, 0.05),
  chk("SBP single-delta slope", L("SBP", "single_slope"), 0.918, 0.0005),
  chk("SBP observed max mean dd", L("SBP", "obs_max_mean"), 22.1, 0.05),
  chk("DBP dd slope", L("DBP", "slope"), 0.575, 0.0005),
  chk("DBP dd slope lower", L("DBP", "slope_lo"), 0.481, 0.0005),
  chk("DBP dd slope upper", L("DBP", "slope_hi"), 0.669, 0.0005),
  chk("DBP predicted at GM Cmax", L("DBP", "pred_gm"), 13.4, 0.05),
  chk("DBP predicted at max Cmax", L("DBP", "pred_max"), 22.6, 0.05),
  chk("DBP single-delta slope", L("DBP", "single_slope"), 0.666, 0.0005),
  chk("DBP observed max mean dd", L("DBP", "obs_max_mean"), 11.4, 0.05),
  chk("HR dd slope", L("HR", "slope"), 0.525, 0.0005),
  chk("HR dd slope lower", L("HR", "slope_lo"), 0.400, 0.0005),
  chk("HR dd slope upper", L("HR", "slope_hi"), 0.650, 0.0005),
  chk("HR predicted at GM Cmax", L("HR", "pred_gm"), 13.9, 0.05),
  chk("HR predicted at max Cmax", L("HR", "pred_max"), 22.3, 0.05),
  chk("HR single-delta slope", L("HR", "single_slope"), 0.224, 0.0005),
  chk("HR observed max mean dd", L("HR", "obs_max_mean"), 15.8, 0.05),
  chk("Max ddSBP vs Cmax slope", B("SBP", "CMAX", "slope"), -0.304, 0.0005),
  chk("Max ddSBP vs Cmax p", B("SBP", "CMAX", "p"), 0.37, 0.005),
  chk("Max ddDBP vs Cmax slope", B("DBP", "CMAX", "slope"), 0.290, 0.0005),
  chk("Max ddDBP vs AUC r", B("DBP", "AUC", "r"), 0.36, 0.005),
  chk("Max ddDBP vs AUC p", B("DBP", "AUC", "p"), 0.04, 0.005),
  chk("Max ddHR vs Cmax slope", B("HR", "CMAX", "slope"), -0.165, 0.0005),
  chk("SBP between-subject slope", WB$SBP$between, 0.870, 0.0005),
  chk("SBP between-subject lower", WB$SBP$b_lo, -0.321, 0.0005),
  chk("SBP between-subject upper", WB$SBP$b_hi, 2.060, 0.0005),
  chk("SBP within-subject slope", WB$SBP$within, 1.032, 0.0005),
  chk("SBP individual slopes > 0", WB$SBP$npos, 31, 0),
  chk("DBP between-subject slope", WB$DBP$between, 1.193, 0.0005),
  chk("DBP within-subject slope", WB$DBP$within, 0.563, 0.0005),
  chk("DBP individual slopes > 0", WB$DBP$npos, 30, 0),
  chk("SBP >20% above baseline, n", ret_sum$n_exceed[ret_sum$ENDPT == "SBP"], 14, 0),
  chk("DBP >20% above baseline, n", ret_sum$n_exceed[ret_sum$ENDPT == "DBP"], 14, 0),
  chk("SBP returned by 4 h, n", ret_cum$n[ret_cum$ENDPT == "SBP" & ret_cum$by_h == 4], 9, 0),
  chk("DBP returned by 4 h, n", ret_cum$n[ret_cum$ENDPT == "DBP" & ret_cum$by_h == 4], 10, 0),
  chk("EC20 lower 90% limit", logit$EC20_ci[1], 5.5, 0.05),
  chk("EC20 upper 90% limit", logit$EC20_ci[2], 10.1, 0.05),
  chk("EC50 lower 90% limit", logit$EC50_ci[1], 13.4, 0.05),
  chk("EC50 upper 90% limit", logit$EC50_ci[2], 18.4, 0.05),
  chk("SBP returned by 6 h, n", ret_cum$n[ret_cum$ENDPT == "SBP" & ret_cum$by_h == 6], 13, 0),
  chk("Hallucination participants", hall_desc$n_with, 28, 0),
  chk("Hallucination episodes", hall_desc$n_episodes, 37, 0),
  chk("Onset median (h)", hall_desc$onset_med, 0.93, 0.005),
  chk("Single-episode duration median (h)", hall_desc$dur_med, 5.10, 0.005),
  chk("Final resolution median (h)", hall_desc$off_med, 6.12, 0.005),
  chk("Final resolution maximum (h)", hall_desc$off_max, 11.3, 0.05),
  chk("Total duration median (h)", hall_desc$total_med, 5.5, 0.05),
  chk("KM median onset (h)", km_med[["onset"]], 1.0, 0.05),
  chk("KM median resolution (h)", km_med[["resolution"]], 6.6, 0.05),
  chk("Logistic observations", logit$n, 377, 0),
  chk("OR per 10 ng/mL", logit$or10, 5.58, 0.005),
  chk("P(hallucination) at 0 ng/mL", logit$p0, 0.06, 0.005),
  chk("P(hallucination) at GM Cmax", logit$p_gm, 0.87, 0.005),
  chk("EC20 (ng/mL)", logit$EC20, 7.7, 0.05),
  chk("EC50 (ng/mL)", logit$EC50, 15.7, 0.05),
  chk("Final resolution vs t1/2 rho", D("last_off", "THALF", "rho"), 0.41, 0.005),
  chk("Final resolution vs t1/2 p", D("last_off", "THALF", "p"), 0.042, 0.0005),
  chk("Total duration vs t1/2 rho", D("total", "THALF", "rho"), 0.37, 0.005),
  chk("Total duration vs t1/2 p", D("total", "THALF", "p"), 0.068, 0.0005),
  chk("Partial rho, t1/2 given AUC", partial["thalf_given_auc", "rho"], 0.43, 0.005),
  chk("Partial rho, AUC given t1/2", partial["auc_given_thalf", "rho"], -0.23, 0.005))
check$agrees <- abs(check$value - check$report) <= check$tol + 1e-9
write.csv(check, file.path(out_dir, "check_against_report.csv"), row.names = FALSE)

cat("\n================ Key results ================\n")
cat(sprintf("Excluded from concentration analyses (PKSUMXFL = Y): %s\n", paste(excl_pk, collapse = ", ")))
cat(sprintf("t1/2 excluded (lambda-z criteria): %s\n", paste(excl_thalf, collapse = ", ")))
cat(sprintf("Hallucination events without onset/resolution time: %d\n", n_hall_untimed))
print(format(lme_tab, digits = 4), row.names = FALSE)
cat(sprintf("\nEC20 %.1f (90%% CI %.1f, %.1f); EC50 %.1f (90%% CI %.1f, %.1f); %d bootstrap resamples\n",
            logit$EC20, logit$EC20_ci[1], logit$EC20_ci[2], logit$EC50, logit$EC50_ci[1],
            logit$EC50_ci[2], N_BOOT))
cat(sprintf("Concentration below EC50/EC20: mean by %g/%g h; 90th percentile by %g/%g h\n",
            below[["EC50_mean"]], below[["EC20_mean"]], below[["EC50_p90"]], below[["EC20_p90"]]))
cat(sprintf("\nCheck against report: %d of %d values agree.\n", sum(check$agrees), nrow(check)))
if (any(!check$agrees)) print(check[!check$agrees, ], row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(out_dir, "sessionInfo.txt"))

RES <- list(pk_sum = pk_sum, lme_tab = lme_tab, sens = sens, linearity = linearity,
            between_tab = between_tab, between_post = between_post, wb_tab = wb_tab, WB = WB,
            ret_sum = ret_sum, ret_cum = ret_cum, hall_desc = hall_desc, hall_pt = hall_pt,
            inc = inc, nonhall = nonhall, logit = logit, below = below, KM_tab = KM_tab,
            km_med = km_med, dur_tab = dur_tab, partial = partial, rho_thalf_auc = rho_thalf_auc,
            prev = prev, conc_time = conc_time, p33 = p33, hyst = hyst, check = check)
saveRDS(RES, file.path(out_dir, "results.rds"))
