# HLP003-103 ADME study – change log (03 Nov 2026)

Both files are redlined under **Tairan Yang** on top of the versions received; all ICON/Navita comments are kept and each thread has a short reply stating what was done.

## 1. Synopsis (HLP003-103 v0.6) – changes made

| Topic | Change | Source |
|---|---|---|
| Follow-up call | Day 10 (±2) → **Day 11 (±2 days)** throughout (text, schematic, SoA header/footnote); discharge in the morning of Day 10 after the final collections, Day 9-10 results communicated on the Day 11 call | Stam 27 / Navita 28 |
| Collection stop | Excreta collection stops after the Day 24-25 re-admission at the latest, no further re-admissions; final-sampling paragraph aligned ("Day 25 at the latest irrespective of criteria") | Mohse 24, 48 / Navita 25, 49 |
| Meals | "Standardized meals" → **standard meals** | Stam 32 / Navita 33 |
| Dosing room / group dosing | Dosing in the dedicated [¹⁴C] room, immediate transfer to the dosing session room on the ward; groups of up to 4; ≥2 SMs in room (1 Lead), minimum 4 SMs onsite (2 Leads), extra SMs via live video; group pre-dose check-in on Day 1; alternative room if distressed; 24 h post-dose session onsite, group setting, up to 75 min (aligned with Zelah's protocol text) | Stam 36 / Zelah 35, 38 |
| Vital signs | Only supine BP and pulse rate in triplicate at baseline; respiratory rate and temperature singly; "oral temperature" → **body temperature** (site method, e.g. temporal) | Stam 40, 43 / Navita 41, 44 |
| Debrief timing | Body text aligned to **4 h** post-dose (footnote already changed by Navita) | Stam 134 / Navita 135 |
| Screening visits | May be split over more than one visit (clinic procedures, psychiatric interview, pre-dose psych support), all within Day -28 to -2; pre-dose session explicitly in the Screening period | Stam 118, 129 / Mohse 119 / Navita 120-121 / Zelah 122, 130 |
| Time windows | ICON windows adopted (no infusion text): pre-dose any time between waking and dosing; safety ≤2.5 h ±15 min, otherwise ±10 %; PK ±5 %; urine/feces intervals ±5 % | Stam 131 / Navita 132 |
| Inclusion 7 | "condom and spermicide" → **male condom**; examples of highly effective methods added; **sperm-donation restriction moved here** (3 months) | Han 54 / Navita 55 / Zelah 91 |
| Inclusion 9 | "no history of constipation" → **no recent history (within 3 months)** | Han 61 / Navita 62 |
| Exclusion 4 | "(based on participant self-report)" added – no lab test for psychedelics | Stam 67 / Zelah 69 |
| Exclusion 5 | **Antacids (H2 blockers, PPIs) within 2 weeks** prohibited | Mohse 71 / Navita 72 |
| Exclusion 8 | eGFR threshold **<90** mL/min/1.73 m² (note: "≤ 90" corrected to "<90") | Mohse 75 / Navita 76 |
| Exclusion 22 | Alcohol **breath → urine** test (criterion, SoA row, footnote); **cannabinoid exception deleted** (site no-tolerance policy) | Stam 77, 80, 125 / Navita 78, 81 / Zelah 82, 127 |
| Exclusion 23 | Alcohol **>21 units/week** (per Navita) | Mohse 83 / Navita 84 |
| Exclusion 25 | Minor fruit/nut reactions acceptable at Investigator's discretion | Han 87 / Navita 88 |
| Exclusion 29 | **Deleted** (duplicate; requirement moved to inclusion 7) | Navita 90 / Zelah 91 |
| Exclusion 34 | Rephrased to ICON radiation wording (diagnostic/occupational/study exposure in past year + graded mSv look-back); "**estimated** total effective dose" added; 5 mSv/10 mSv limits kept | Mohse 100 / Han 103 / Navita 101, 104 |
| Typo | "where possible,," fixed | – |

## 2. Synopsis – open items (flagged in comment replies, no text change)

1. **[¹²C]/[¹⁴C] mg split** (x mg / y mg) – placeholders kept; CMC/BioA to supply from the specific activity of the batch (comments 22/23, 106/107).
2. **Blood sampling beyond Day 4** – Matthias asks whether these samples also serve metabolite work; Navita asked you. Suggested wording is in the reply to comment 47.
3. **Lactose intolerance** exclusion – pending Navita (comment 97/98).
4. **Alcohol 14 vs 21 units** – set to 21 per Navita; Zelah notes 14 is the US standard definition – please confirm.
5. **Cannabinoid exception** – removed; ICON to confirm database is sufficient (deletion can be rejected if an exemption is granted).
6. **Contraception wording** – ICON to confirm EC acceptability of "male condom" without spermicide.
7. Final dosing-room/ward arrangement to be confirmed at the onsite visit.

## 3. ICON protocol template – what was populated

* Synopsis section: title, short title, study code, sponsor, objectives/endpoints (mass balance, metabolites, PK primary; safety secondary), design and treatments, study schedule, participants, main inclusion criteria, study drug table, assessments, statistical methods, SoA note and footnotes a-d.
* Sections 1.2 (risk-benefit), 1.3 (rationale), 2 (objectives/endpoints), 3.1.1-3.1.5 (design, screening, treatment period, follow-up, duration), 3.2 (discussion), 3.3.1/3.3.2 (full inclusion and exclusion criteria from the updated synopsis), 3.3.3 (lifestyle), 3.3.4 (replacement), 3.4.1/3.4.2 (treatment, IP identity), 3.4.4 (dose selection – answers ICON comment 161), 3.4.5/3.4.6/3.4.8 (timing, meals, concomitant medication), 3.5.1.1 (blood, urine, feces, vomit), 3.5.1.3 (AEs/SMREs, laboratory, vital signs, ECG, physical examination, debrief/End of Session and Discharge Checklists), 3.5.3 (bioanalysis), 3.6.2.1 (PK evaluation and excretion parameters), 3.6.3 (sample size), 8.1 (dose preparation).
* All **absolute bioavailability** alternatives, the **expired air** section and breath (Ae/fe) parameters, and the "choose one" guidance text were deleted (tracked).
* Replies to ICON's @Sponsor comments: 38 (introduction), 161 (dose selection), 211 (placement of psychological assessments).

## 4. Template – items for ICON / Sponsor to complete

* Effective radiation dose (mSv) and the radioactive-dose calculation (Sections 1.2 and 3.4.4) – Matthias/ICON Clinical Pharmacology.
* Dosage form (oral solution?) and dose preparation at ICON – CMC to confirm.
* Transfer of the full SoA (synopsis Table 4-1) into the ICON format.
* Introduction refers to "Cybin IRL" and "CYB003" – harmonize with Helus Pharma / HLP003.
