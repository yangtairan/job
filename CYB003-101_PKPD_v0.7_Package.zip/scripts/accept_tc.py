from docx.oxml.ns import qn
def accept_all(body):
    W=qn
    # unwrap insertions
    for ins in list(body.iter(W('w:ins'))):
        par=ins.getparent()
        if par.tag==W('w:rPr'):   # paragraph-mark insertion marker
            par.remove(ins); continue
        if par.tag==W('w:trPr'): par.remove(ins); continue
        idx=par.index(ins)
        for ch in list(ins): par.insert(idx,ch); idx+=1
        par.remove(ins)
    # remove deletions
    for d in list(body.iter(W('w:del'))):
        par=d.getparent()
        if par.tag==W('w:rPr'):   # paragraph mark deleted -> merge this paragraph with next
            p=par.getparent().getparent(); par.remove(d)
            nxt=p.getnext()
            if nxt is not None and nxt.tag==W('w:p'):
                for ch in list(nxt):
                    if ch.tag!=W('w:pPr'): p.append(ch)
                nxt.getparent().remove(nxt)
            continue
        if par.tag==W('w:trPr'):  # deleted row
            tr=par.getparent(); tr.getparent().remove(tr); continue
        par.remove(d)
    for tag in ['w:moveFrom','w:moveTo']:
        for e in list(body.iter(W(tag))):
            par=e.getparent(); idx=par.index(e)
            if tag=='w:moveTo':
                for ch in list(e): par.insert(idx,ch); idx+=1
            par.remove(e)
    for tag in ['w:moveFromRangeStart','w:moveFromRangeEnd','w:moveToRangeStart','w:moveToRangeEnd']:
        for e in list(body.iter(W(tag))): e.getparent().remove(e)

def clean_empty(body):
    """remove empty body-level paragraphs left by accepted deletions; never touch table cells"""
    from docx.oxml.ns import qn
    W=qn
    for p in list(body.iter(W('w:p'))):
        if p.getparent().tag==W('w:tc'): continue
        if ''.join(t.text or '' for t in p.iter(W('w:t'))).strip() or p.find('.//'+W('w:drawing')) is not None: continue
        ppr=p.find(W('w:pPr'))
        if p.find(W('w:r')) is None and ppr is not None and ppr.find(W('w:numPr')) is None and ppr.find(W('w:pStyle')) is None: p.getparent().remove(p)
