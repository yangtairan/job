import copy, re, json, difflib
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt, Inches
from PIL import Image
SRC='CYB003-101_PKPD_Exploratory_ER_review_v0.5.docx'; OUT='CYB003-101_PKPD_Exploratory_ER_review_v0.6.docx'
AUTHOR='Tairan Yang'; DATE='2026-10-27T09:00:00Z'
R=json.load(open('results_v06.json')); w=R['within']; wb=R['wb']; H=R['hall']; L=H['logit']; dur=H['dur']; pc=H['partial']; s33=R['s033']
doc=Document(SRC); body=doc.element.body; W=qn; _id=[50000]
def nid(): _id[0]+=1; return str(_id[0])
def ptext(p): return ''.join(t.text or '' for t in p.iter(W('w:t')))
def PE(prefix):
    for p in body.iter(W('w:p')):
        if ptext(p).strip().startswith(prefix): return p
    raise KeyError(prefix)
TOK=re.compile(r'\*\*.*?\*\*|_\{.*?\}|\s+|[^\s_*]+|[_*]')
def base_rpr(p):
    for r in p.iter(W('w:r')):
        rpr=r.find(W('w:rPr'))
        if rpr is not None:
            c=copy.deepcopy(rpr)
            for tag in ['w:b','w:vertAlign']:
                for e in c.findall(W(tag)): c.remove(e)
            return c
    return OxmlElement('w:rPr')
def mk_run(txt,rpr0,bold=False,sub=False,deleted=False):
    r=OxmlElement('w:r'); rpr=copy.deepcopy(rpr0)
    if bold: rpr.insert(0,OxmlElement('w:b'))
    if sub: v=OxmlElement('w:vertAlign'); v.set(W('w:val'),'subscript'); rpr.append(v)
    r.append(rpr); t=OxmlElement('w:delText' if deleted else 'w:t'); t.text=txt; t.set('{http://www.w3.org/XML/1998/namespace}space','preserve'); r.append(t); return r
def runs(markup,rpr0,deleted=False):
    out=[]
    for tok in TOK.findall(markup):
        if tok.startswith('**') and tok.endswith('**') and len(tok)>4: out.append(mk_run(tok[2:-2],rpr0,bold=True,deleted=deleted))
        elif tok.startswith('_{') and tok.endswith('}'): out.append(mk_run(tok[2:-1],rpr0,sub=True,deleted=deleted))
        else: out.append(mk_run(tok,rpr0,deleted=deleted))
    return out
def wrap(tag,rs):
    e=OxmlElement(tag); e.set(W('w:id'),nid()); e.set(W('w:author'),AUTHOR); e.set(W('w:date'),DATE)
    for r in rs: e.append(r)
    return e
def run_markup(r):
    t=r.find(W('w:t'))
    if t is None: return ''
    txt=t.text or ''; rpr=r.find(W('w:rPr'))
    bold=rpr is not None and rpr.find(W('w:b')) is not None
    sub=rpr is not None and rpr.find(W('w:vertAlign')) is not None and rpr.find(W('w:vertAlign')).get(W('w:val'))=='subscript'
    if sub: return '_{'+txt+'}'
    if bold and txt.strip(): return '**'+txt+'**'
    return txt
def accept_in(p):
    for ins in list(p.findall(W('w:ins'))):
        idx=p.index(ins)
        for ch in list(ins): p.insert(idx,ch); idx+=1
        p.remove(ins)
    for d in list(p.findall(W('w:del'))): p.remove(d)
def par_markup(p):
    s=''.join(run_markup(r) for r in p.findall(W('w:r'))); return re.sub(r'\*\*(\s*)\*\*',r'\1',s).replace('**_{','_{').replace('}**','}')
def tracked_set(p,new):
    accept_in(p); old=par_markup(p); rpr0=base_rpr(p)
    for r in list(p.findall(W('w:r'))): p.remove(r)
    a,b=TOK.findall(old),TOK.findall(new); sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
    for op,i1,i2,j1,j2 in sm.get_opcodes():
        if op=='equal':
            for r in runs(''.join(a[i1:i2]),rpr0): p.append(r)
        if op in ('delete','replace'): p.append(wrap('w:del',runs(''.join(a[i1:i2]),rpr0,deleted=True)))
        if op in ('insert','replace'): p.append(wrap('w:ins',runs(''.join(b[j1:j2]),rpr0)))
def tracked_sub(p,old_sub,new_sub):
    accept_in(p); old=par_markup(p); assert old_sub in old,'not found: '+old_sub[:70]; tracked_set(p,old.replace(old_sub,new_sub))
def mark_inserted(p):
    ppr=p.find(W('w:pPr'))
    if ppr is None: ppr=OxmlElement('w:pPr'); p.insert(0,ppr)
    rpr=ppr.find(W('w:rPr'))
    if rpr is None: rpr=OxmlElement('w:rPr'); ppr.append(rpr)
    for e in list(rpr):
        if e.tag in (W('w:ins'),W('w:del')): rpr.remove(e)
    ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); rpr.append(ins)
def new_par_like(tpl,markup):
    p=copy.deepcopy(tpl)
    for ch in list(p):
        if ch.tag!=W('w:pPr'): p.remove(ch)
    p.append(wrap('w:ins',runs(markup,base_rpr(tpl)))); mark_inserted(p); return p
def set_pic(cap_prefix,png):
    cap=PE(cap_prefix); e=cap
    while e is not None:
        e=e.getnext()
        if e is not None and e.tag==W('w:p') and e.find('.//'+W('w:drawing')) is not None: break
    blip=e.find('.//'+W('a:blip')); part=doc.part.rels[blip.get(qn('r:embed'))].target_part; part._blob=open(png,'rb').read()
    wd,ht=Image.open(png).size
    for ext in [e.find('.//'+W('wp:extent')),e.find('.//'+W('a:ext'))]:
        cx=int(ext.get('cx')); ext.set('cy',str(int(cx*ht/wd)))
    return e
def tbl_after(p):
    e=p
    while e is not None:
        e=e.getnext()
        if e is not None and e.tag==W('w:tbl'): return e
def rows(t): return t.findall(W('w:tr'))
def rowtext(tr): return ' | '.join(ptext(tc) for tc in tr.findall(W('w:tc')))
def find_row(t,sub):
    for tr in rows(t):
        if sub in rowtext(tr): return tr
    raise KeyError(sub)
def cell_set(tr,j,new): tracked_set(tr.findall(W('w:tc'))[j].find(W('w:p')),new)
def add_row_after(t,tr_ref,vals):
    tr=copy.deepcopy(tr_ref)
    for tc,v in zip(tr.findall(W('w:tc')),vals):
        p=tc.find(W('w:p')); rpr0=base_rpr(p)
        for ch in list(p):
            if ch.tag!=W('w:pPr'): p.remove(ch)
        p.append(wrap('w:ins',runs(v,rpr0)))
    trPr=tr.find(W('w:trPr'))
    if trPr is None: trPr=OxmlElement('w:trPr'); tr.insert(0,trPr)
    for e in trPr.findall(W('w:ins')): trPr.remove(e)
    ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); trPr.append(ins)
    tr_ref.addnext(tr); return tr
f3=lambda x:f"{x:.3f}"; f1=lambda x:f"{x:.1f}"
TPL_NOTE=PE('The smaller numbers'); TPL_BODY=PE('Analyses were based on'); TPL_H2=PE('3.1 Source Data'); TPL_H1=PE('1. Introduction'); TPL_TCAP=PE('Table 1.')
def SRC_after(el,text):
    n=new_par_like(TPL_NOTE,text); el.addnext(n); return n
def after_fig(cap_prefix):
    """return the last note paragraph following the figure picture (or the picture itself)"""
    cap=PE(cap_prefix); e=cap
    while True:
        e=e.getnext()
        if e.tag==W('w:p') and e.find('.//'+W('w:drawing')) is not None: break
    nxt=e.getnext()
    return nxt if (nxt is not None and nxt.tag==W('w:p') and ptext(nxt).strip() and not re.match(r'^\d|^Table|^Figure|^[A-Z0-9.]+ ',ptext(nxt).strip()) and len(ptext(nxt))<700 and 'Source:' not in ptext(nxt) and ptext(nxt).strip()[0:1].islower()==False and ptext(nxt).strip()[:1] in 'PABOETS') else e
# ======== figures: swap ========
for cap,png in [('Figure 1.','newfig/Fig01_BP_within.png'),('Figure 4.','newfig/Fig04_between_within_SBP_DBP.png'),('Figure 6.','newfig/Fig06_HR_within.png'),('Figure 7.','newfig/Fig05_hysteresis_all.png'),('Figure 11.','newfig/Fig11_hall_ER.png')]: set_pic(cap,png)
# ======== 3.2 baseline wording; new consistency bullet ========
tracked_sub(PE('Baseline and reference correction.') if any(ptext(p).strip().startswith('Baseline and reference correction.') for p in body.iter(W('w:p'))) else PE('Reference correction.'),
  'where baseline is the pre-dose measurement obtained on the morning of the dosing day in each period (Day 1 for Period 1 and Day 8 for Period 2), before administration of the probe cocktail and, on Day 8, before CYB003.',
  'where baseline is the last available pre-dose measurement in each period (obtained on the morning of the dosing day: Day 1 for Period 1 and Day 8 for Period 2, before administration of the probe cocktail and, on Day 8, before CYB003), consistent with the definition used in Table 14.3.5.1.')
pc_bul=PE('Concentrations.')
tracked_sub(pc_bul,'time-matched records with a missing concentration were excluded.','time-matched records with a missing concentration were excluded. Consistent with the PK summary tables, concentration data for one participant flagged for exclusion from PK summaries (PKSUMXFL = Y; participant 01-038) were excluded from all concentration-based analyses, giving 33 participants with CYB003 concentration data (Table 14.2.1.1.1).')
newb=new_par_like(PE('Missing data.'),'**Pharmacokinetic parameters.** Individual C_{max}, AUC_{0–∞}, and terminal t½ were taken from the non-compartmental analysis (ADPP). Terminal t½ values were used only where the λz acceptance criteria applied in the PK summary tables were met (adjusted R² ≥ 0.8 and span ≥ 2 half-lives); two estimates (participants 01-058 and 01-068) did not meet the span criterion and were excluded, leaving 31 participants with an evaluable t½, consistent with Table 14.2.1.2.1.')
PE('Missing data.').addnext(newb)
# ======== Table 2 ========
t2=tbl_after(PE('Table 2.'))
cell_set(find_row(t2,'ΔΔ SBP/DBP versus concentration'),1,'215'); cell_set(find_row(t2,'ΔΔ SBP/DBP versus concentration'),2,'33')
cell_set(find_row(t2,'ΔΔ pulse rate versus concentration'),1,'215'); cell_set(find_row(t2,'ΔΔ pulse rate versus concentration'),2,'33')
cell_set(find_row(t2,'Hallucination status versus concentration'),1,'377'); cell_set(find_row(t2,'Hallucination status versus concentration'),2,'33')
SRC_after(t2,'Concentration-based analyses exclude participant 01-038 (PKSUMXFL = Y). Source: ADaM ADPC, ADVS, ADAE, ADPP; cf. Tables 14.1.1.3, 14.2.1.1.1, 14.3.5.1.')
# ======== Table 3 ========
t3=tbl_after(PE('Table 3.')); trs=rows(t3)
cell_set(trs[0],1,'CYB003 concentration, quantifiable (available)')
vals={'0 (pre-dose)':'0 (33)','1':'31 (33)','2':'33 (33)','3':'32 (32)','4':'30 (30)','6':'32 (32)','8':'33 (33)','12':'33 (33)','16':'32 (32)','24':'20 (33)','48':'0 (33)'}
for tr in trs[1:]:
    k=ptext(tr.findall(W('w:tc'))[0]).strip()
    if k in vals: cell_set(tr,1,vals[k])
n3=PE('The smaller numbers'); tracked_set(n3,'Concentration column: number of participants with a quantifiable CYB003 concentration used in the time-matched analyses, with the number of participants with a sample available in parentheses (Table 14.2.1.1.1); pre-dose values are set to zero and BLQ values after the first quantifiable concentration are treated as missing (Section 3.2). The smaller numbers of Day 8 vital-sign observations at 2–4 h (30–31) coincide with the highest concentrations (Table 14.3.5.1). Source: ADaM ADPC, ADVS.')
# ======== 4.1 reference to biostats conventions (no change) ========
# ======== Table 4 ========
t4=tbl_after(PE('Table 4.')); S,D=w['SBP'],w['DBP']
def set_lme_rows(t,r,endpoint_label,unit):
    tr=find_row(t,f'{endpoint_label} | Slope'); cell_set(tr,2,f3(r['slope'])); cell_set(tr,3,f"{f3(r['lo'])}, {f3(r['hi'])}")
    found=0
    for tr in rows(t):
        txt=rowtext(tr)
        if 'geometric mean' in txt and (found==0 if endpoint_label=='ΔΔ SBP' else found>=0):
            pass
    return
trs=rows(t4)
# SBP block: rows 1..5 ; DBP block after. Identify by sequence of labels
def fill_block(t,start_idx,r,unit):
    trs=rows(t); i=start_idx
    labels=[ptext(trs[j].findall(W('w:tc'))[1]) for j in range(i,i+5)]
    for j in range(i,i+5):
        lab=ptext(trs[j].findall(W('w:tc'))[1])
        if lab.startswith('Slope'): cell_set(trs[j],2,f3(r['slope'])); cell_set(trs[j],3,f"{f3(r['lo'])}, {f3(r['hi'])}")
        elif 'geometric mean' in lab: cell_set(trs[j],2,f1(r['pred_gm'][0])); cell_set(trs[j],3,f"{f1(r['pred_gm'][1])}, {f1(r['pred_gm'][2])}")
        elif 'maximum C' in lab: cell_set(trs[j],2,f1(r['pred_max'][0])); cell_set(trs[j],3,f"{f1(r['pred_max'][1])}, {f1(r['pred_max'][2])}")
        elif 'Observed maximum' in lab: cell_set(trs[j],2,f1(r['obs_max_mean']))
        elif 'Baseline-corrected' in lab: cell_set(trs[j],2,f3(r['single_slope'])); cell_set(trs[j],3,f"{f3(r['single_lo'])}, {f3(r['single_hi'])}")
fill_block(t4,1,S,'mmHg'); fill_block(t4,6,D,'mmHg')
n4=PE('N = 222 observations from 34 participants. REML'); tracked_sub(n4,'N = 222 observations from 34 participants.','N = 215 observations from 33 participants.')
tracked_sub(n4,'(upper bound of observed exposure).','(upper bound of observed exposure). Source: ADaM ADVS, ADPC; C_{max} from Table 14.2.1.2.1.')
# text 5.1.1
tracked_sub(PE('Reference-corrected SBP and DBP increased'),f'(SBP 21.1 mmHg; DBP 10.9 mmHg)',f'(SBP {S["obs_max_mean"]:.1f} mmHg; DBP {D["obs_max_mean"]:.1f} mmHg)')
# Figure 1 source
SRC_after(after_fig('Figure 1.'),'Source: ADaM ADVS (Table 14.3.5.1; Listing 16.2.9.1) and ADPC (Table 14.2.1.1.1; Listing 16.2.6.1).')
# ======== 5.1.2 figures 2, 3 and Table 5 sources ========
SRC_after(after_fig('Figure 2.'),'Source: ADaM ADVS (Table 14.3.5.1) and ADPP (Table 14.2.1.2.1; Listing 16.2.6.3).')
SRC_after(after_fig('Figure 3.'),'Source: ADaM ADVS (Table 14.3.5.1) and ADPP (Table 14.2.1.2.1; Listing 16.2.6.3).')
t5=tbl_after(PE('Table 5.')); n5=t5.getnext(); tracked_sub(n5,'Response = maximum reference-corrected increase at any post-dose timepoint.','Response = maximum reference-corrected increase at any post-dose timepoint. Source: ADaM ADVS, ADPP (Table 14.2.1.2.1).')
# ======== 5.1.3 / Table 6 ========
tracked_sub(PE('When the between-subject and within-subject slopes'),'with confidence intervals approximately five- to six-fold wider','with confidence intervals approximately seven- to eight-fold wider')
t6=tbl_after(PE('Table 6.')); trs=rows(t6)
cell_set(trs[1],2,'0.870'); cell_set(trs[1],3,'−0.321, 2.060')
cell_set(trs[2],2,f3(wb['SBP']['within'])); cell_set(trs[2],3,f"{f3(wb['SBP']['w_lo'])}, {f3(wb['SBP']['w_hi'])}")
cell_set(trs[3],2,'1.193'); cell_set(trs[3],3,'0.509, 1.876')
cell_set(trs[4],2,f3(wb['DBP']['within'])); cell_set(trs[4],3,f"{f3(wb['DBP']['w_lo'])}, {f3(wb['DBP']['w_hi'])}")
n6=t6.getnext(); tracked_set(n6,'Between-subject slope: OLS of participant mean ΔΔ on participant mean time-matched concentration (n = 33). Within-subject slope: mixed-effects model with participant mean concentration as an additional covariate (215 observations). Source: ADaM ADVS, ADPC.')
SRC_after(after_fig('Figure 4.'),'Source: ADaM ADVS (Table 14.3.5.1) and ADPC (Table 14.2.1.1.1).')
# ======== 5.1.4 ========
t7=tbl_after(PE('Table 7.')); SRC_after(t7,'Source: ADaM ADVS (Table 14.3.5.1; Listing 16.2.9.1). Baseline as defined in Table 14.3.5.1.')
SRC_after(after_fig('Figure 5.'),'Source: ADaM ADVS (Table 14.3.5.1; Listing 16.2.9.1).')
# ======== 5.2 HR ========
hr=w['HR']
tracked_sub(PE('Reference-corrected pulse rate increased'),'The largest observed mean ΔΔ (14.8 bpm) occurred at 4 h.',f'The largest observed mean ΔΔ ({hr["obs_max_mean"]:.1f} bpm) occurred at {hr["obs_max_mean_h"]:.0f} h.')
t8=tbl_after(PE('Table 8.')); trs=rows(t8)
cell_set(trs[1],1,f3(hr['slope'])); cell_set(trs[1],2,f"{f3(hr['lo'])}, {f3(hr['hi'])}")
cell_set(trs[2],1,f1(hr['pred_gm'][0])); cell_set(trs[2],2,f"{f1(hr['pred_gm'][1])}, {f1(hr['pred_gm'][2])}")
cell_set(trs[3],1,f1(hr['pred_max'][0])); cell_set(trs[3],2,f"{f1(hr['pred_max'][1])}, {f1(hr['pred_max'][2])}")
for tr in trs[4:]:
    lab=ptext(tr.findall(W('w:tc'))[0])
    if lab.startswith('Observed maximum'): cell_set(tr,0,f'Observed maximum mean ΔΔ (bpm), at {hr["obs_max_mean_h"]:.0f} h'); cell_set(tr,1,f1(hr['obs_max_mean']))
    if lab.startswith('Baseline-corrected'): cell_set(tr,1,f3(hr['single_slope'])); cell_set(tr,2,f"{f3(hr['single_lo'])}, {f3(hr['single_hi'])}")
n8=t8.getnext(); tracked_set(n8,'N = 215 observations from 33 participants. Geometric mean and maximum C_{max} as defined in Section 4.2. Source: ADaM ADVS (Table 14.3.5.1), ADPC (Table 14.2.1.1.1).')
SRC_after(after_fig('Figure 6.'),'Source: ADaM ADVS (Table 14.3.5.1) and ADPC (Table 14.2.1.1.1).')
# ======== 5.3 hysteresis ========
n7=after_fig('Figure 7.'); tracked_sub(n7,'connected in time order.','connected in time order. Arithmetic mean concentrations by timepoint correspond to those in Table 14.2.1.1.1. Source: ADaM ADVS (Table 14.3.5.1), ADPC (Table 14.2.1.1.1), ADAE (Table 14.3.1.2).')
# ======== 5.4.1 ========
t9=tbl_after(PE('Table 9.')); SRC_after(t9,'Source: ADaM ADAE (Tables 14.3.1.2 and 14.3.1.3; Listing 16.2.7.1), ADPP (Table 14.2.1.2.1). Event counts by preferred term and intensity correspond to Tables 14.3.1.2 and 14.3.1.3 (CYB003 + CYP probe period, N = 34).')
tracked_sub(PE('The four participants without a hallucination'),'Three of the four had C_{max} values among the lowest observed','Three of the four had C_{max} values among the lowest observed (Table 14.2.1.2.1: C_{max} range 16.7–43.0 ng/mL)')
SRC_after(after_fig('Figure 8.'),'Source: ADaM ADAE (Tables 14.3.1.2 and 14.3.1.3; Listing 16.2.7.1); dosing times from ADSL/ADEX.')
SRC_after(after_fig('Figure 9.'),'Source: ADaM ADAE (Table 14.3.1.3; Listing 16.2.7.1).')
n10=after_fig('Figure 10.'); tracked_sub(n10,'in Table 10.','in Table 10. Source: ADaM ADAE (Table 14.3.1.2; Listing 16.2.7.1).')
t10=tbl_after(PE('Table 10.')); n10t=t10.getnext(); tracked_sub(n10t,'censored at 48 h.','censored at 48 h. Source: ADaM ADAE (Listing 16.2.7.1).')
# ======== 5.4.2 ========
p542=PE('Because hallucination occurred in nearly all participants')
tracked_set(p542,f'Because hallucination occurred in nearly all participants at the 16 mg dose, there was little scope for incidence to vary with exposure, and no significant relationship between incidence and individual C_{{max}} or AUC_{{0–∞}} was identified (Table 11). The time-matched analysis addresses a different question: whether a participant is more likely to be hallucinating at times when their concentration is higher. This relationship was strong (Figure 11B): the model-predicted probability of hallucination was {L["p0"]:.2f} at 0 ng/mL and {L["pgm"]:.2f} at the geometric mean C_{{max}}, with EC20 = {L["EC20"]:.1f} ng/mL (90% CI {L["EC20_ci"][0]:.1f}, {L["EC20_ci"][1]:.1f}) and EC50 = {L["EC50"]:.1f} ng/mL (90% CI {L["EC50_ci"][0]:.1f}, {L["EC50_ci"][1]:.1f}). The proportion of participants with hallucination over time followed the mean concentration-time profile (Figure 11A), peaking at {100*H["prev_peak"]:.0f}% at {H["prev_peak_h"]:.0f} h and returning to 0% by 12 h. The arithmetic mean concentration fell below EC50 by {H["t_below"]["EC50_mean"]:.0f} h and below EC20 by {H["t_below"]["EC20_mean"]:.0f} h post-dose, and the 90th percentile concentration fell below EC20 by {H["t_below"]["EC20_p90"]:.0f} h. Concentrations below approximately 7 ng/mL (EC20) were therefore associated with a low probability of hallucination, and essentially all participants were below this level by 12–16 h after dosing, consistent with the observed absence of hallucination after 12 h.')
p543=PE('Duration of the perceptual experience was related')
tracked_set(p543,f'Duration of the perceptual experience was related to the rate of elimination rather than to peak or total exposure. Among the 27 participants with hallucination and an evaluable t½, time to final resolution (Spearman ρ = 0.49, p = 0.009), total hallucination duration (ρ = {dur["total_THALF"]["rho"]:.2f}, p = {dur["total_THALF"]["p"]:.3f}), and the longest single episode (ρ = {dur["longest_THALF"]["rho"]:.2f}, p = {dur["longest_THALF"]["p"]:.3f}) were each correlated with terminal t½, whereas none of the duration measures correlated with C_{{max}} or AUC_{{0–∞}} (Figure 11C, D). Terminal t½ and AUC_{{0–∞}} were themselves correlated (ρ = {H["thalf_auc_rho"]:.2f}). After adjustment for AUC_{{0–∞}}, the partial correlation of total duration with t½ was {pc["total_thalf_given_auc"][0]:.2f} (p = {pc["total_thalf_given_auc"][1]:.3f}), whereas after adjustment for t½ the partial correlation with AUC_{{0–∞}} was {pc["total_auc_given_thalf"][0]:.2f} (p = {pc["total_auc_given_thalf"][1]:.2f}), indicating that the association with duration is carried by the elimination half-life rather than by total exposure.')
t11=tbl_after(PE('Table 11.'))
for tr in rows(t11):
    lab=ptext(tr.findall(W('w:tc'))[0])
    if lab.startswith('Probability of hallucination versus'): cell_set(tr,1,f'{L["or10"]:.2f}'); cell_set(tr,3,f'{L["n"]}')
    elif lab.startswith('Predicted probability'): cell_set(tr,1,f'{L["p0"]:.2f} → {L["pgm"]:.2f}')
    elif lab.startswith('EC20'): cell_set(tr,1,f'{L["EC20"]:.1f} ({L["EC20_ci"][0]:.1f}, {L["EC20_ci"][1]:.1f})')
    elif lab.startswith('EC50'): cell_set(tr,1,f'{L["EC50"]:.1f} ({L["EC50_ci"][0]:.1f}, {L["EC50_ci"][1]:.1f})')
    elif lab.startswith('Time to final resolution versus'): cell_set(tr,1,'0.49'); cell_set(tr,2,'0.009'); cell_set(tr,3,'27')
    elif lab.startswith('Total hallucination duration versus'): cell_set(tr,1,f'{dur["total_THALF"]["rho"]:.2f}'); cell_set(tr,2,f'{dur["total_THALF"]["p"]:.3f}'); cell_set(tr,3,'27')
    elif lab.startswith('Longest single episode versus'): cell_set(tr,1,f'{dur["longest_THALF"]["rho"]:.2f}'); cell_set(tr,2,f'{dur["longest_THALF"]["p"]:.3f}'); cell_set(tr,3,'27')
    elif lab.startswith('Duration measures versus'): cell_set(tr,2,'> 0.4'); cell_set(tr,3,'29')
    elif lab.startswith('Partial ρ: total duration with t½'): cell_set(tr,1,f'{pc["total_thalf_given_auc"][0]:.2f}'); cell_set(tr,2,f'{pc["total_thalf_given_auc"][1]:.3f}'); cell_set(tr,3,'27')
    elif lab.startswith('Partial ρ: total duration with AUC'): cell_set(tr,1,f'{pc["total_auc_given_thalf"][0]:.2f}'); cell_set(tr,2,f'{pc["total_auc_given_thalf"][1]:.2f}'); cell_set(tr,3,'27')
n11=t11.getnext(); tracked_set(n11,'OR = odds ratio. EC20/EC50 and their 90% CIs from the pooled logistic model (cluster bootstrap by participant). Duration measures as defined in Section 3.2; t½ restricted to estimates meeting the λz acceptance criteria (n = 27 of 29 participants with hallucination and PK parameters). Source: ADaM ADAE (Listing 16.2.7.1), ADPC (Table 14.2.1.1.1), ADPP (Table 14.2.1.2.1; Listing 16.2.6.3).')
SRC_after(after_fig('Figure 11.'),'Source: ADaM ADAE (Listing 16.2.7.1), ADPC (Table 14.2.1.1.1), ADPP (Table 14.2.1.2.1).')
# ======== 5.5 ========
p55=PE('Participant 01-033 (55-year-old male')
tracked_sub(p55,'terminal t½ (5.9 h) was longer than the population mean (approximately 4.5 h)','terminal t½ (5.9 h) was longer than the population mean (4.6 h; Table 14.2.1.2.1)')
tracked_sub(p55,f'compared with population medians of 11.2 and 5.4 ng/mL',f'compared with population medians of {s33["c8"]["pop_median"]:.1f} and {s33["c12"]["pop_median"]:.1f} ng/mL')
SRC_after(after_fig('Figure 12.'),'Source: ADaM ADVS (Listing 16.2.9.1), ADPC (Listing 16.2.6.1), ADAE (Listing 16.2.7.1), ADSL (Table 14.1.2.1).')
# ======== Discussion: limitations metabolite statement ========
plim=PE('Limitations.')
tracked_sub(plim,'Only parent CYB003 was quantified and modeled, but this is reasonable given that the major metabolites are not active at the target sites for efficacy.','Only parent CYB003 was included in the exposure–response analyses; the metabolites psilocin-O-glucuronide and 4-HIAA were quantified (Table 14.2.1.1.1) but not analyzed, which is reasonable given that the major metabolites are not active at the target sites for efficacy.')
# ======== Conclusions ========
tracked_sub(PE('A single 16 mg oral dose of CYB003 produced transient'),'ΔΔ SBP +24.8 mmHg and ΔΔ DBP +13.5 mmHg',f'ΔΔ SBP +{S["pred_gm"][0]:.1f} mmHg and ΔΔ DBP +{D["pred_gm"][0]:.1f} mmHg')
tracked_sub(PE('A single 16 mg oral dose of CYB003 produced transient'),'pulse rate (+13.8 bpm)',f'pulse rate (+{hr["pred_gm"][0]:.1f} bpm)')
# Table 1 source
t1=tbl_after(PE('Table 1.')); SRC_after(t1,'Source: Tables 14.1.1.1 and 14.1.1.3 (Listings 16.2.1.1 and 16.2.3.1).')
# ======== Appendix A: cross-reference ========
last=body.findall(W('w:p'))[-1]
sect=body.find(W('w:sectPr'))
hA=new_par_like(TPL_H1,'Appendix A. Cross-Reference to Biostatistics Outputs'); sect.addprevious(hA)
pA=new_par_like(TPL_BODY,'All inputs to this report were cross-checked against the CYB003-101 production tables (Production Run Tables, 02 September 2026; EDC extraction date 2026-04-07). Table A-1 lists each check and the outcome. Two alignments were made as a result: concentration data for one participant flagged for exclusion from PK summaries (PKSUMXFL = Y) were removed from the concentration-based analyses, and two terminal t½ estimates that did not meet the λz span criterion were excluded from the duration analyses. After these alignments, participant counts, concentration summaries, PK parameters, adverse-event counts, and vital-sign summaries in this report correspond to the production tables.'); hA.addnext(pA)
cA=new_par_like(TPL_TCAP,'Table A-1. Cross-Reference of Report Inputs to Biostatistics Production Tables'); pA.addnext(cA)
tplT=tbl_after(PE('Table 3.'))
tA=copy.deepcopy(tplT); trs=rows(tA); hdr=trs[0]; brow=trs[1]
for tr in trs[1:]: tA.remove(tr)
def fill(tr,vals):
    for tc,v in zip(tr.findall(W('w:tc')),vals):
        p=tc.find(W('w:p')); rpr0=base_rpr(p)
        for ch in list(p):
            if ch.tag!=W('w:pPr'): p.remove(ch)
        p.append(wrap('w:ins',runs(v,rpr0)))
    trPr=tr.find(W('w:trPr'))
    if trPr is None: trPr=OxmlElement('w:trPr'); tr.insert(0,trPr)
    for e in trPr.findall(W('w:ins')): trPr.remove(e)
    ins=OxmlElement('w:ins'); ins.set(W('w:id'),nid()); ins.set(W('w:author'),AUTHOR); ins.set(W('w:date'),DATE); trPr.append(ins)
fill(hdr,['Report item','Biostatistics source','Outcome of cross-check'])
for vals in [
 ['Table 1: Safety 36; Day 1 dosed 36; Day 8 dosed 34; PK 35; DDI PK 33; completed 34','Tables 14.1.1.1, 14.1.1.3','Identical'],
 ['C_{max} geometric mean 26.9 ng/mL; range 16.7–43.0; n = 33','Table 14.2.1.2.1','Identical'],
 ['AUC_{0–∞} geometric mean 205 h·ng/mL; n = 33','Table 14.2.1.2.1','Identical'],
 ['T_{max} median 2.93 h; terminal t½ mean 4.61 h (n = 31)','Table 14.2.1.2.1','Identical after excluding two t½ values failing the span criterion (participants 01-058, 01-068)'],
 ['CYB003 concentration n by timepoint and arithmetic means (hysteresis plots)','Table 14.2.1.1.1','Identical after excluding participant 01-038 (PKSUMXFL = Y); e.g., 13.4, 21.7, 22.7, 16.4, 11.3, 5.6 ng/mL at 1, 2, 4, 6, 8, 12 h'],
 ['BLQ and pre-dose handling','Table 14.2.1.1.1 footnotes','Same convention'],
 ['Hallucination/perceptual events: 47 events (visual 24, illusion 9, unspecified 6, somatic 4, tactile 2, auditory 1, visual processing disorder 1); 43 mild, 4 moderate; denominator N = 34','Tables 14.3.1.2, 14.3.1.3','Identical'],
 ['Vital-sign n by timepoint (Day 1 / Day 8)','Table 14.3.5.1','Identical'],
 ['Day 8 change-from-baseline means (e.g., SBP +17.9 mmHg at 2 h, n = 31; pulse +8.8 bpm at 4 h)','Table 14.3.5.1','Consistent; report ΔΔ values are paired within-participant differences and therefore differ slightly from the difference of period means'],
 ['Baseline definition','Table 14.3.5.1 footnote','Aligned (last available pre-dose value in each period)'],
 ['Metabolites','Table 14.2.1.1.1','Psilocin-O-glucuronide and 4-HIAA quantified by biostatistics; not analyzed here (Section 6, Limitations corrected)']]:
    tr=copy.deepcopy(brow); fill(tr,vals); tA.append(tr)
cA.addnext(tA)
# widen appendix table columns
tw=[int(x*1440) for x in [2.9,1.6,2.9]]
grid=tA.find(W('w:tblGrid'))
if grid is not None:
    for gc,wv in zip(grid.findall(W('w:gridCol')),tw): gc.set(W('w:w'),str(wv))
for tr in rows(tA):
    for tc,wv in zip(tr.findall(W('w:tc')),tw):
        tcPr=tc.find(W('w:tcPr')); tcw=tcPr.find(W('w:tcW')) if tcPr is not None else None
        if tcw is not None: tcw.set(W('w:w'),str(wv)); tcw.set(W('w:type'),'dxa')
# LoT: add A-1 row
lot=doc.tables[1]._tbl; lr=rows(lot)[-1]; add_row_after(lot,lr,['Table A-1','Cross-Reference of Report Inputs to Biostatistics Production Tables'])
# version/date
for row in doc.tables[0].rows:
    for c in row.cells:
        for x in c._tc.iter(W('w:t')):
            if x.text and 'v0.5' in x.text: x.text=x.text.replace('v0.5','v0.6')
            if x.text and '20 October 2026' in x.text: x.text=x.text.replace('20 October 2026','27 October 2026')
for p in doc.sections[0].header.paragraphs:
    for r in p.runs: r.text=r.text.replace('v0.5','v0.6').replace('20-Oct-2026','27-Oct-2026')
doc.save(OUT); print("saved",OUT)
