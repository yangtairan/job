import copy, re, json, difflib
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt, Inches
from PIL import Image
exec(open('patch_v06.py').read().split("# ======== figures: swap ========")[0].replace("SRC='CYB003-101_PKPD_Exploratory_ER_review_v0.5.docx'; OUT='CYB003-101_PKPD_Exploratory_ER_review_v0.6.docx'","SRC='CYB003-101_PKPD_Exploratory_ER_review_v0.6.docx'; OUT='CYB003-101_PKPD_Exploratory_ER_review_v0.7.docx'").replace("DATE='2026-10-27T09:00:00Z'","DATE='2026-10-27T15:00:00Z'").replace("_id=[50000]","_id=[60000]").replace("TPL_NOTE=PE('The smaller numbers')","TPL_NOTE=PE('Concentration column:')"))
c=json.load(open('hall_cum.json'))
# ---- 1. renumber Figure 12 -> 13, 11 -> 12 (text, delText, LoF) before inserting new Figure 11 ----
for t in list(body.iter(W('w:t')))+list(body.iter(W('w:delText'))):
    if t.text and 'Figure 12' in t.text: t.text=t.text.replace('Figure 12','Figure 13')
for t in list(body.iter(W('w:t')))+list(body.iter(W('w:delText'))):
    if t.text and 'Figure 11' in t.text: t.text=t.text.replace('Figure 11','Figure 12')
# ---- 2. Figure 10 note: at risk / events definitions ----
n10=PE('Events: in A, the first onset')
tracked_sub(n10,'Numbers at risk and cumulative events at each displayed timepoint are shown beneath the plots and in Table 10.','Beneath each panel, “At risk” is the number of participants who had not yet experienced the event and were still under observation at that timepoint, and “Events” is the cumulative number of participants who had experienced the event by that timepoint; the same values, with the corresponding cumulative percentages, are given in Table 10.')
# ---- 3. Table 10: cumulative % in the at-risk/events cell ----
t10=tbl_after(PE('Table 10.')); trs=rows(t10); cell_set(trs[0],1,'At risk / cumulative events (cumulative % with event)')
block=None
for tr in trs[1:]:
    tcs=tr.findall(W('w:tc')); lab=ptext(tcs[0]).strip()
    if lab.startswith('A. Time to first'): block=('onset',c['N_on']); continue
    if lab.startswith('B. Time to final'): block=('resolution',c['N_off']); continue
    try: tval=float(lab)
    except: continue
    key=f"{tval:g}"; cum=None
    if block[0]=='onset':
        # events at displayed KM grid times: use at_risk/cum from existing text; cumulative % = cum events / 34
        txt=ptext(tcs[1]); m=re.match(r'\s*(\d+)\s*/\s*(\d+)',txt); 
        if m: cum=int(m.group(2)); cell_set(tr,1,f'{m.group(1)} / {m.group(2)} ({100*cum/block[1]:.0f}%)')
    else:
        txt=ptext(tcs[1]); m=re.match(r'\s*(\d+)\s*/\s*(\d+)',txt)
        if m: cum=int(m.group(2)); cell_set(tr,1,f'{m.group(1)} / {m.group(2)} ({100*cum/block[1]:.0f}%)')
n10t=t10.getnext()
tracked_sub(n10t,'At risk = participants without the event and still under observation at the timepoint; cumulative events = events occurring at or before the timepoint.','At risk = number of participants who had not yet experienced the event and were still under observation at the timepoint; cumulative events = number of participants who had experienced the event at or before the timepoint; cumulative % = cumulative events divided by the number of participants in the analysis (34 for onset; 30 for resolution).')
# ---- 4. insert new Figure 11 (cumulative %) after Table 10 note ----
TPL_FCAP=PE('Figure 10.')
cap11=new_par_like(TPL_FCAP,'Figure 11. Cumulative Percentage of Participants with Hallucination Onset (A) and with Hallucination Resolved (B) by Time Since CYB003 Dose'); n10t.addnext(cap11)
p=doc.add_paragraph(); p.alignment=1; p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(2); p.add_run().add_picture('newfig/Fig10b_hall_cumulative.png',width=Inches(6.3)); pic11=p._p; body.remove(pic11); mark_inserted(pic11); cap11.addnext(pic11)
n11=new_par_like(TPL_NOTE,'A: cumulative percentage of the 34 CYB003-dosed participants whose first hallucination/perceptual episode had begun by the stated time. B: cumulative percentage of the 30 participants with hallucination whose last episode had resolved by the stated time. Bars are cumulative (each includes all earlier events); percentages and counts (n/N) are shown above the bars. Source: ADaM ADAE (Table 14.3.1.2; Listing 16.2.7.1).'); pic11.addnext(n11)
# text reference in 5.4.1
p541=PE('Hallucination/perceptual AEs were reported by 30 of 34')
tracked_sub(p541,'after dosing (Figure 10).',f'after dosing (Figure 10). Hallucination had begun in {c["onset"]["1"]} of 34 participants ({100*c["onset"]["1"]/34:.0f}%) by 1 h and in {c["onset"]["1.5"]} of 34 ({100*c["onset"]["1.5"]/34:.0f}%) by 1.5 h post-dose, and had resolved in {c["resolution"]["8"]} of 30 participants ({100*c["resolution"]["8"]/30:.0f}%) by 8 h and in all 30 by 12 h (Figure 11).')
# ---- 5. logistic figure (now Figure 12): swap image, add explanatory footnote; Table 12 row label ----
set_pic('Figure 12.','newfig/Fig11_hall_ER.png')
n12=PE('Source: ADaM ADAE (Listing 16.2.7.1), ADPC (Table 14.2.1.1.1), ADPP (Table 14.2.1.2.1).')
tracked_sub(n12,'Source: ADaM ADAE','B: each point is one PK sampling time in one participant, plotted at 1 if a hallucination/perceptual episode was ongoing at that time and at 0 if not, against the CYB003 plasma concentration measured in that sample (points are jittered vertically for visibility). The curve is the logistic-regression estimate of the probability that a participant is experiencing hallucination at a given plasma concentration; EC20 and EC50 mark the concentrations at which this probability is 20% and 50%. Source: ADaM ADAE')
t12=tbl_after(PE('Table 11.'))
for tr in rows(t12):
    lab=ptext(tr.findall(W('w:tc'))[0])
    if lab.startswith('Probability of hallucination versus time-matched concentration'): cell_set(tr,0,'Probability of hallucination versus plasma concentration at the sampling time, OR per 10 ng/mL')
# LoF: renumber rows and add Figure 11
lof=doc.tables[2]._tbl
for tr in rows(lof)[1:]:
    tcs=tr.findall(W('w:tc')); k=ptext(tcs[0]).strip()
    if k=='Figure 10': add_row_after(lof,tr,['Figure 11','Cumulative Percentage of Participants with Hallucination Onset and with Hallucination Resolved'])
# version
for row in doc.tables[0].rows:
    for cc in row.cells:
        for x in cc._tc.iter(W('w:t')):
            if x.text and 'v0.6' in x.text: x.text=x.text.replace('v0.6','v0.7')
for p in doc.sections[0].header.paragraphs:
    for r in p.runs: r.text=r.text.replace('v0.6','v0.7')
doc.save(OUT); print("saved",OUT)
